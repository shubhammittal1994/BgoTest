package com.expert.healthkangaroodriver.ambulance_driver;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.EmergencyHistoryModel;
import com.expert.healthkangaroodriver.Model.ambulance_model.AmbulanceHistoryModel;
import com.expert.healthkangaroodriver.adapter_class.ambulance_adapter.EmergencyHistoryHVAdapter;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;


public class HistoryOrderFragment extends Fragment implements EmergencyHistoryHVAdapter.CliQ{
    View view;
    RecyclerView recyclerView;
    String strDriverId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view =  inflater.inflate(R.layout.fragment_history_order, container, false);

        recyclerView=  view.findViewById(R.id.rv_emergency_history);

        strDriverId = App.getSharedPref().getStringValue("DriverId");


        new ViewModelClass().ambulanceHistoryModelLiveData(requireActivity(), strDriverId).observe(requireActivity(), new Observer<AmbulanceHistoryModel>() {
            @Override
            public void onChanged(AmbulanceHistoryModel ambulanceHistoryModel) {
                if (ambulanceHistoryModel.getSuccess().equalsIgnoreCase("1"))
                {
                    EmergencyHistoryHVAdapter admissionHistoryHVAdapter = new EmergencyHistoryHVAdapter(requireContext(), ambulanceHistoryModel.getDetails(), HistoryOrderFragment.this);
                    recyclerView.setAdapter(admissionHistoryHVAdapter);

                } else {

                    Toast.makeText(requireContext(), "History Not Found", Toast.LENGTH_SHORT).show();

                }
            }
        });
        return view;
    }

    @Override
    public void onCLiQ(AmbulanceHistoryModel.Detail list) {

        Navigation.findNavController(view).navigate(R.id.ambulanceHistoryDetailsFragment);
        AmbulanceHistoryDetailsFragment.list = list;
    }
}