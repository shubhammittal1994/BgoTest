package com.expert.healthkangaroodriver.ambulance_driver;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.adapter_class.ambulance_adapter.OrderPagerAdapter;
import com.google.android.material.tabs.TabLayout;


public class OrderDetailsFragment extends Fragment {
    private ViewPager viewPager;
    private TabLayout tabLayout;
    private View view;
    private PagerAdapter pagerAdapter;
    private ImageView back;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view =  inflater.inflate(R.layout.fragment_order_details, container, false);

        findId();
        setAdapter();

        onClick();

        return view;
    }

    private void onClick() {
        back.setOnClickListener(v -> {

            Navigation.findNavController(view).navigate(R.id.homeAmbulanceDriverFragment);
        });
    }


    private void findId() {

        tabLayout=view.findViewById(R.id.tabLayout);
        viewPager=view.findViewById(R.id.viewPager);
        back = view.findViewById(R.id.back_arrow);
    }

    private void setAdapter() {
        pagerAdapter = new OrderPagerAdapter(getChildFragmentManager());
        viewPager.setAdapter(pagerAdapter);
        tabLayout.setupWithViewPager(viewPager);
    }
}