package com.expert.healthkangaroodriver.adapter_class.ambulance_adapter;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import com.expert.healthkangaroodriver.ambulance_driver.HistoryOrderFragment;
import com.expert.healthkangaroodriver.ambulance_driver.UpComingOrdersFragment;

public class OrderPagerAdapter extends FragmentPagerAdapter {

    public OrderPagerAdapter(@NonNull FragmentManager fm) {
        super(fm);
    }

    @NonNull
    @Override
    public Fragment getItem(int position) {
        switch (position) {
            case 0:
                UpComingOrdersFragment upComingOrdersFragment = new UpComingOrdersFragment();
                return upComingOrdersFragment;

            case 1:
                HistoryOrderFragment historyOrderFragment = new HistoryOrderFragment();
                return historyOrderFragment;

                default:

                return null;
        }
    }

    @Override
    public int getCount() {

        return 2;

    }
    public CharSequence getPageTitle(int position) {
        switch (position) {

            case 0:
                return "CURRENT ORDER";
            case 1:
                return "HISTORY ORDER";

            default:
                return null;
        }
    }

}
