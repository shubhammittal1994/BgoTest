package com.expert.healthkangaroodriver.phlebotomist_driver;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.ImageView;

import com.example.healthkangaroo.R;

public class AboutLabFragment extends Fragment {
    private View view;
    private ImageView back_img;
    private WebView webView;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view  =  inflater.inflate(R.layout.fragment_about_lab, container, false);

        webView = view.findViewById(R.id.webView_lab);
        back_img = view.findViewById(R.id.img_back_about_lab);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("https://www.jsonschema2pojo.org/");

        back_img.setOnClickListener(v -> {

            Navigation.findNavController(view).navigate(R.id.mapscreenDrawerLayout);

        });

        return view;
    }

}