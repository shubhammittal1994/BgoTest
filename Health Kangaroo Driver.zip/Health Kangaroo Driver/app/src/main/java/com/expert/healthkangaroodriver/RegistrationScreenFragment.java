package com.expert.healthkangaroodriver;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.healthkangaroo.R;
import com.github.angads25.toggle.widget.LabeledSwitch;

public class RegistrationScreenFragment extends Fragment {
    private View view;
    int num_password = 2, num_confirm_password = 2;
    Button register;
    LabeledSwitch switch_reg_nurs;
    TextView sign_in_text;
    ImageView eye_image_password, eye_image_confirm_password;
    EditText email_edit_text, name_edit_text, phone_edit_text, surname_edit_text, password_edit_text, confirm_password_edit_text, address_edit_text, postCode_edit_text, city_edit_text, state_edit_text, idDocument_edit_text;
    String get_name, get_surname,  get_phone, get_address, get_post_code, get_city, get_state, get_id_document;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_registration_screen, container, false);


        findId();
        Onclicks();


        return view;
    }


    private void findId() {

        switch_reg_nurs = view.findViewById(R.id.switch_terms_registr_nurs);
        eye_image_password = view.findViewById(R.id.img_eye);
        eye_image_confirm_password = view.findViewById(R.id.img_eye_2);
        sign_in_text = view.findViewById(R.id.sign_in_txt);
        register = view.findViewById(R.id.regstr_btn);
        email_edit_text = view.findViewById(R.id.edtx_email);
        phone_edit_text = view.findViewById(R.id.edtx_phone_regstr);
        name_edit_text = view.findViewById(R.id.edtx_name);
        surname_edit_text = view.findViewById(R.id.edtx_surname);
        password_edit_text = view.findViewById(R.id.edtx_password);
        confirm_password_edit_text = view.findViewById(R.id.edtx_password_confirm);
        address_edit_text = view.findViewById(R.id.edtx_address);
        postCode_edit_text = view.findViewById(R.id.edtx_postcode);
        city_edit_text = view.findViewById(R.id.edtx_city);
        state_edit_text = view.findViewById(R.id.edtx_state);
        idDocument_edit_text = view.findViewById(R.id.edtx_id_document);

    }

    private void getdata() {

//        get_email=email_edit_text.getText().toString();
        get_name = name_edit_text.getText().toString();
        get_surname = surname_edit_text.getText().toString();
//        get_password=password_edit_text.getText().toString();
//        get_confirm_password=confirm_password_edit_text.getText().toString();
        get_phone = phone_edit_text.getText().toString();
        get_address = address_edit_text.getText().toString();
        get_post_code = postCode_edit_text.getText().toString();
        get_city = city_edit_text.getText().toString();
        get_state = state_edit_text.getText().toString();
        get_id_document = idDocument_edit_text.getText().toString();

    }

    private void Onclicks() {

        eye_image_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (num_password % 2 == 0) {

                    password_edit_text.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    eye_image_password.setImageResource(R.drawable.invisible);
                    num_password++;

                } else {

                    password_edit_text.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    eye_image_password.setImageResource(R.drawable.ic_baseline_remove_red_eye_24);
                    num_password++;

                }

            }
        });

        eye_image_confirm_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (num_confirm_password % 2 == 0) {

                    confirm_password_edit_text.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    eye_image_confirm_password.setImageResource(R.drawable.invisible);
                    num_confirm_password++;

                } else {

                    confirm_password_edit_text.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    eye_image_confirm_password.setImageResource(R.drawable.ic_baseline_remove_red_eye_24);
                    num_confirm_password++;

                }

            }
        });

        sign_in_text.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                Navigation.findNavController(view).navigate(R.id.action_registrationScreen_to_loginScreen);

            }
        });



    }



}