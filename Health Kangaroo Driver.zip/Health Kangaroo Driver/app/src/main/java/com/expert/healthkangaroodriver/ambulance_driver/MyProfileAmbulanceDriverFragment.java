package com.expert.healthkangaroodriver.ambulance_driver;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;

import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.ambulance_model.ChangePasswordAmbulanceModel;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;

public class MyProfileAmbulanceDriverFragment extends Fragment {

    private View view;
    private ImageView img_arrow, img_profile_pic;
    private TextView txt_name, txt_username, txt_phone_number, txt_email, txt_vehicle, txt_change_password, txt_address, txt_age;
    private Dialog dialog;
    private int oldCountPassword = 0, newCountpassword = 0, confirmCountPassword = 0;
    private ViewModelClass viewModel;
    private String strDriverId, strHospitalID;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_my_profile_ambulance_driver, container, false);

        findID();

        strDriverId = App.getSharedPref().getStringValue("DriverId");
        strHospitalID = App.getSharedPref().getStringValue("HospitalId");

        onClick();
        setData();


        return view;
    }

    private void setData() {

        Glide.with(view).load(App.sharedPref.getStringValue("Image")).into(img_profile_pic);

        txt_name.setText(App.sharedPref.getStringValue("Name"));
        txt_username.setText(App.sharedPref.getStringValue("Username"));
        txt_phone_number.setText(App.sharedPref.getStringValue("Phone"));
        txt_email.setText(App.sharedPref.getStringValue("Email"));
        txt_vehicle.setText(App.sharedPref.getStringValue("Vehicle"));
        txt_address.setText(App.sharedPref.getStringValue("Address"));
        txt_age.setText(App.sharedPref.getStringValue("Age"));

    }

    private void onClick() {
        img_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                requireActivity().onBackPressed();
            }
        });

        txt_change_password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog = new Dialog(requireActivity());
                dialog.setContentView(R.layout.layout_change_password_phlebotomist);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.setCanceledOnTouchOutside(true);


                EditText editext_password_old = dialog.findViewById(R.id.editext_password_old);
                EditText editext_password_new = dialog.findViewById(R.id.editext_password_new);
                EditText editext_password_confirm = dialog.findViewById(R.id.editext_password_confirm);

                ImageView ic_eye_id_old = dialog.findViewById(R.id.ic_eye_id_old);
                ImageView ic_eye_id_new = dialog.findViewById(R.id.ic_eye_id_new);
                ImageView ic_eye_id_confirm = dialog.findViewById(R.id.ic_eye_id_confirm);

    ic_eye_id_old.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (oldCountPassword % 2 == 0) {

                            editext_password_old.setTransformationMethod(HideReturnsTransformationMethod.getInstance());

                            ic_eye_id_old.setImageResource(R.drawable.invisible);

                        } else {

                            editext_password_old.setTransformationMethod(PasswordTransformationMethod.getInstance());

                            ic_eye_id_old.setImageResource(R.drawable.ic_baseline_remove_red_eye_24);
                        }

                        oldCountPassword++;

                    }
    });

                ic_eye_id_new.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (newCountpassword % 2 == 0) {

                            editext_password_new.setTransformationMethod(HideReturnsTransformationMethod.getInstance());

                            ic_eye_id_new.setImageResource(R.drawable.invisible);

                        } else {

                            editext_password_new.setTransformationMethod(PasswordTransformationMethod.getInstance());

                            ic_eye_id_new.setImageResource(R.drawable.ic_baseline_remove_red_eye_24);

                        }

                        newCountpassword++;

                    }
                });

                ic_eye_id_confirm.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (confirmCountPassword % 2 == 0) {

                            editext_password_confirm.setTransformationMethod(HideReturnsTransformationMethod.getInstance());

                            ic_eye_id_confirm.setImageResource(R.drawable.invisible);

                        } else {

                            editext_password_confirm.setTransformationMethod(PasswordTransformationMethod.getInstance());

                            ic_eye_id_confirm.setImageResource(R.drawable.ic_baseline_remove_red_eye_24);

                        }

                        confirmCountPassword++;

                    }
                });


                Button btn_submit = dialog.findViewById(R.id.btn_submit);

                btn_submit.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        String oldPasswordStr = editext_password_old.getText().toString();
                        String newPasswordStr = editext_password_new.getText().toString();
                        String confirmPasswordStr = editext_password_confirm.getText().toString();

                        if (oldPasswordStr.isEmpty()) {

                            Toast.makeText(requireActivity(), "Enter Old Password", Toast.LENGTH_SHORT).show();

                        } else if (newPasswordStr.isEmpty()) {

                            Toast.makeText(requireActivity(), "Enter New Password", Toast.LENGTH_SHORT).show();

                        } else if (confirmPasswordStr.isEmpty()) {

                            Toast.makeText(requireActivity(), "Enter Confirm Password", Toast.LENGTH_SHORT).show();


                        } else if (!confirmPasswordStr.matches(newPasswordStr)) {

                            Toast.makeText(requireActivity(), "Password and Confirm password should be same!", Toast.LENGTH_SHORT).show();

                        } else {

                            viewModel = new ViewModelClass();
                            viewModel.LiveDataChangePasswordAmbulance(requireActivity(), strHospitalID, strDriverId, oldPasswordStr, newPasswordStr).observe(requireActivity(), new Observer<ChangePasswordAmbulanceModel>() {
                                @Override
                                public void onChanged(ChangePasswordAmbulanceModel changePasswordAmbulanceModel) {
                                    if (changePasswordAmbulanceModel.getSuccess().equalsIgnoreCase("1")) {
                                        Toast.makeText(requireContext(), changePasswordAmbulanceModel.getMessage(), Toast.LENGTH_SHORT).show();
                                        dialog.dismiss();
                                    } else {
                                        Toast.makeText(requireContext(), changePasswordAmbulanceModel.getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });

                        }

                    }
                });

                Window window = dialog.getWindow();
                window.setGravity(Gravity.CENTER);
                dialog.show();


            }
        });


//        img_edit.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Navigation.findNavController(v).navigate(R.id.action_myProfileAmbulanceDriverFragment2_to_updateMyProfileAmbulanceDriverFragment);
//            }
//        });


    }

    private void findID() {
        img_arrow = view.findViewById(R.id.img_arrow);

        img_profile_pic = view.findViewById(R.id.img_profile_pic_nurse);

        txt_name = view.findViewById(R.id.txt_patient_name);
        txt_username = view.findViewById(R.id.txt_username);
        txt_phone_number = view.findViewById(R.id.txt_phone_number_ambulance);
        txt_email = view.findViewById(R.id.txt_email);
        txt_vehicle = view.findViewById(R.id.txt_vehicle);
        txt_address = view.findViewById(R.id.txt_patient_address);
        txt_age = view.findViewById(R.id.txt_age);

        txt_change_password = view.findViewById(R.id.txt_change_password);


//        img_edit=view.findViewById(R.id.img_edit);
    }
}