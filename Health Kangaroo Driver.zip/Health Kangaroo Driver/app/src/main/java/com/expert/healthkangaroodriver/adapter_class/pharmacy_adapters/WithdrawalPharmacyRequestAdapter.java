package com.expert.healthkangaroodriver.adapter_class.pharmacy_adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.pharmacy_model.DetailsWithdrawalRequestModel;

import java.util.List;

public class WithdrawalPharmacyRequestAdapter extends RecyclerView.Adapter<WithdrawalPharmacyRequestAdapter.ViewModel> {
    private Context context;
    private List<DetailsWithdrawalRequestModel.Detail> list;
    RequestReceived received;

    public interface RequestReceived {
        void details(DetailsWithdrawalRequestModel.Detail detail);
    }
    public WithdrawalPharmacyRequestAdapter(Context context, List<DetailsWithdrawalRequestModel.Detail> list, RequestReceived received) {
        this.context = context;
        this.list = list;
        this.received = received;
    }

    @NonNull
    @Override
    public ViewModel onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.received_request_layout, parent, false);

        return new ViewModel(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewModel holder, int position) {
        DetailsWithdrawalRequestModel.Detail model = list.get(position);


        holder.transId.setText(model.getTransactionId());
        holder.amountReq.setText(model.getAmount());
        holder.date_time.setText(model.getDateTime());

        holder.itemView.setOnClickListener(view -> {

            received.details(list.get(position));

        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewModel extends RecyclerView.ViewHolder {
        private TextView transId, amountReq, date_time;


        public ViewModel(@NonNull View itemView) {
            super(itemView);

            transId = itemView.findViewById(R.id.id_trans);
            date_time = itemView.findViewById(R.id.date_and_time);
            amountReq = itemView.findViewById(R.id.amountReq);
        }
    }
}
