package com.expert.healthkangaroodriver;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import com.example.healthkangaroo.R;
import com.github.angads25.toggle.widget.LabeledSwitch;


public class RegisterHealthKangarooFragment extends Fragment {
    private View view;
    private Button register;
    private EditText edtx_name, edtx_surname, edtxt_phone, edtx_email, edtx_passwrd, edtx_passwrd_confrm, edtx_addrs, edtx_postcode, edtx_city, edtx_state, edtx_docmnt, edtx_licnce, edtx_vehclusd;
    private LabeledSwitch swtch1;
    private String str_name, str_surename, str_phone, str_email, str_password, str_confrim_password, str_address, str_postcode, str_city, str_state, str_id_documents, str_driving_licence, str_types_of_vehicle_used;
    private ImageView ic_eye_id, ic_eye_id_confrim;
    private int countPassword = 0, countConfrimPassword = 0;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_register_health_kangaroo, container, false);


        FindId();
        onButtonClicked();
        showAndHidePassword();


        return view;
    }


    private void showAndHidePassword() {

        //show n hide pswd functionality
        ic_eye_id.setOnClickListener(v -> {
            if (countPassword % 2 == 0) {
                edtx_passwrd.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                ic_eye_id.setImageResource(R.drawable.ic_hide_password);

            } else {
                edtx_passwrd.setTransformationMethod(PasswordTransformationMethod.getInstance());
                ic_eye_id.setImageResource(R.drawable.ic_baseline_remove_red_eye_24);
            }
            countPassword++;
        });

        ic_eye_id_confrim.setOnClickListener(v -> {
            if (countConfrimPassword % 2 == 0) {
                edtx_passwrd_confrm.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                ic_eye_id_confrim.setImageResource(R.drawable.ic_hide_password);

            } else {
                edtx_passwrd_confrm.setTransformationMethod(PasswordTransformationMethod.getInstance());
                ic_eye_id_confrim.setImageResource(R.drawable.ic_baseline_remove_red_eye_24);
            }
            countConfrimPassword++;
        });

    }

    private void onButtonClicked() {

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//
//                str_name = edtx_name.getText().toString();
//                str_surename = edtx_surname.getText().toString();
//                str_phone = edtxt_phone.getText().toString().trim();
//                str_email = edtx_email.getText().toString();
//                str_password = edtx_passwrd.getText().toString().trim();
//                str_confrim_password = edtx_passwrd_confrm.getText().toString().trim();
//                str_address = edtx_addrs.getText().toString();
//                str_postcode = edtx_postcode.getText().toString();
//                str_city = edtx_city.getText().toString();
//                str_state = edtx_state.getText().toString();
//                str_id_documents = edtx_docmnt.getText().toString();
//                str_driving_licence = edtx_licnce.getText().toString();
//                str_types_of_vehicle_used = edtx_vehclusd.getText().toString();
//
//
//                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
//
//
//                if (str_name.equalsIgnoreCase("")) {
//                    edtx_name.setError("Field can't bt Empty");
//                } else if (str_surename.equalsIgnoreCase("")) {
//                    edtx_surname.setError("Field can't bt Empty");
//                } else if (str_phone.equalsIgnoreCase("")) {
//                    edtxt_phone.setError("Field can't bt Empty");
//                } else if (str_phone.length() != 10) {
//                    edtx_surname.setError("Phone Number must be of 10 digits");
//                } else if (str_email.equalsIgnoreCase("")) {
//                    edtx_email.setError("Field can't bt Empty");
//                } else if (!str_email.matches(emailPattern)) {
//                    edtx_surname.setError("Email format must");
//                } else if (str_password.equalsIgnoreCase("")) {
//                    edtx_passwrd.setError("Field can't bt Empty");
//                } else if (str_confrim_password.equalsIgnoreCase("")) {
//                    edtx_passwrd_confrm.setError("Field can't bt Empty");
//                } else if (!str_confrim_password.matches(str_password)) {
//                    edtx_surname.setError("Confrim Password");
//                } else if (str_address.equalsIgnoreCase("")) {
//                    edtx_addrs.setError("Field can't bt Empty");
//                } else if (str_postcode.equalsIgnoreCase("")) {
//                    edtx_postcode.setError("Field can't bt Empty");
//                } else if (str_city.equalsIgnoreCase("")) {
//                    edtx_city.setError("Field can't bt Empty");
//                } else if (str_state.equalsIgnoreCase("")) {
//                    edtx_state.setError("Field can't bt Empty");
//                } else if (str_id_documents.equalsIgnoreCase("")) {
//                    edtx_docmnt.setError("Field can't bt Empty");
//                } else if (str_driving_licence.equalsIgnoreCase("")) {
//                    edtx_licnce.setError("Field can't bt Empty");
//                } else if (str_types_of_vehicle_used.equalsIgnoreCase("")) {
//                    edtx_vehclusd.setError("Field can't bt Empty");
//                }
////                else if (swtch1.) {
////                    Toast.makeText(requireActivity(), "Please,accept the Terms of Use & Privacy Policy", Toast.LENGTH_SHORT).show();
////                }
//                else {
                Navigation.findNavController(view).navigate(R.id.action_registerHealthKangaroo_to_otpVerification);

//                }

            }
        });

    }


    private void FindId() {
        register = view.findViewById(R.id.register_button);

        edtx_name = view.findViewById(R.id.edtx_name);
        edtx_surname = view.findViewById(R.id.edtx_surname);
        edtxt_phone = view.findViewById(R.id.edtxt_phone);
        edtx_email = view.findViewById(R.id.edtx_email);
        edtx_passwrd = view.findViewById(R.id.edtx_passwrd);
        edtx_passwrd_confrm = view.findViewById(R.id.edtx_passwrd_confrm);
        edtx_addrs = view.findViewById(R.id.edtx_addrs);
        edtx_postcode = view.findViewById(R.id.edtx_postcode);
        edtx_city = view.findViewById(R.id.edtx_city);
        edtx_state = view.findViewById(R.id.edtx_state);
        edtx_docmnt = view.findViewById(R.id.edtx_docmnt);
        edtx_licnce = view.findViewById(R.id.edtx_licnce);
        edtx_vehclusd = view.findViewById(R.id.edtx_vehclusd);

        swtch1 = view.findViewById(R.id.swtch1);

        ic_eye_id = view.findViewById(R.id.ic_eye_id);
        ic_eye_id_confrim = view.findViewById(R.id.ic_eye_id_confrim);
    }


}