package com.expert.healthkangaroodriver.phlebotomist_driver;

import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.pharmacy_model.DetailsWithdrawalRequestModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.GetRequestMoneyLabModel;
import com.expert.healthkangaroodriver.adapter_class.pharmacy_adapters.WithdrawalPharmacyRequestAdapter;
import com.expert.healthkangaroodriver.adapter_class.phlebotomist_adapters.WithdrawalLabRequestAdapter;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;

import java.util.ArrayList;
import java.util.List;

public class LabDriverRequestDetailsFragment extends Fragment {
    View view;
    private RecyclerView recyclerView;
    WithdrawalLabRequestAdapter adapter;
    ViewModelClass viewModelClass;
    List<GetRequestMoneyLabModel.Detail> list = new ArrayList<>();;
    String strDriverId;
    private ProgressDialog dialog;
    ImageView back;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
       view = inflater.inflate(R.layout.fragment_lab_driver_request_details, container, false);

        viewModelClass = ViewModelProviders.of(this).get(ViewModelClass.class);

        recyclerView = view.findViewById(R.id.request_recycler_lab);
        back = view.findViewById(R.id.back_image_lab);

        strDriverId = App.getSharedPref().getStringValue("DriverId");

        back.setOnClickListener(v -> {

            requireActivity().onBackPressed();

        });


        dialog = new ProgressDialog(requireContext());
        dialog.setMessage("Loading....");

        setAdapter();


        return view;

    }

    private void setAdapter() {
        dialog.show();

        viewModelClass.getRequestMoneyLabModelLiveData(requireActivity(), strDriverId).observe(requireActivity(), new Observer<GetRequestMoneyLabModel>() {
            @Override
            public void onChanged(GetRequestMoneyLabModel getRequestMoneyLabModel) {
                dialog.dismiss();

                if (getRequestMoneyLabModel.getSuccess().equalsIgnoreCase("1")){
                    list = getRequestMoneyLabModel.getDetails();

                    adapter = new WithdrawalLabRequestAdapter(requireContext(), list, new WithdrawalLabRequestAdapter.RequestReceived() {
                        @Override
                        public void details(GetRequestMoneyLabModel.Detail detail) {

                        }
                    });

                    recyclerView.setAdapter(adapter);

                }else {

                    dialog.dismiss();

                    Toast.makeText(requireActivity(), getRequestMoneyLabModel.getMessage(), Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}