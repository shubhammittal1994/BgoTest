package com.expert.healthkangaroodriver.adapter_class.phlebotomist_adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.pharmacy_model.HistoryOrderPharmacyModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.LabDeliveryHistoryModel;

import java.util.List;

public class HistoryLabAdapter extends RecyclerView.Adapter<HistoryLabAdapter.ViewHolder> {
    private Context context;
    private List<LabDeliveryHistoryModel.Detail> list;
    HistoryPosition historyPosition;

    public interface HistoryPosition {
        void details(LabDeliveryHistoryModel.Detail detail);
    }

    public HistoryLabAdapter(Context context, List<LabDeliveryHistoryModel.Detail> list, HistoryPosition historyPosition) {
        this.context = context;
        this.list = list;
        this.historyPosition = historyPosition;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_order__history_list, parent, false);
        return new HistoryLabAdapter.ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.txt_appointment_number.setText(list.get(position).getAppointmentId());
        holder.txt_patience_name.setText(list.get(position).getPatientName());
        holder.txt_patience_phone.setText(list.get(position).getPhone());
        holder.txt_patience_address.setText(list.get(position).getAddress());
        holder.date.setText(list.get(position).getDeliverDate());
        holder.time.setText(list.get(position).getDeliveryTime());

        holder.start_btn.setVisibility(View.GONE);

        holder.itemView.setOnClickListener(v -> {

            historyPosition.details(list.get(position));

        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt_appointment_number, txt_patience_name, txt_patience_phone, txt_patience_address, date, time;
        Button start_btn, pending_order_btn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txt_appointment_number = itemView.findViewById(R.id.txt_appointment_number);
            txt_patience_name = itemView.findViewById(R.id.txt_patience_name);
            txt_patience_phone = itemView.findViewById(R.id.txt_patience_phone);
            txt_patience_address = itemView.findViewById(R.id.txt_patience_address);
            date = itemView.findViewById(R.id.date_history);
            time = itemView.findViewById(R.id.time_history);
            start_btn = itemView.findViewById(R.id.start_btn);
            pending_order_btn = itemView.findViewById(R.id.pending_order_btn);
        }
    }
}
