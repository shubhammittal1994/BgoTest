package com.expert.healthkangaroodriver;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.healthkangaroo.R;


public class AddDrivingLicenseDetailsFragment extends Fragment {

    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_add_driving_license_details, container, false);
        FindId();

        return  view;
    }

    private void FindId() {

        view.findViewById(R.id.btn_continue_lic_details).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_addDrivingLicenseDetails_to_addVehicleDetails);
            }
        });
        view.findViewById(R.id.img_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                Navigation.findNavController(v).navigate(R.id.action_add_driving_license_details_to_upload_driving_license);

                getActivity().onBackPressed();
            }
        });
    }
}