package com.expert.healthkangaroodriver.ambulance_driver;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.expert.healthkangaroodriver.AppClass.App;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.ambulance_model.AmbulanceDriverBankDetailsModel;
import com.expert.healthkangaroodriver.Model.ambulance_model.DeleteAmbulanceAccountDetailsModel;
import com.expert.healthkangaroodriver.Model.ambulance_model.RequestAmountWithdrawModel;
import com.expert.healthkangaroodriver.adapter_class.ambulance_adapter.AddAccountAmbulanceAdapter;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;

import java.util.List;

public class WithdrawAmbulanceDriverFragment extends Fragment {

    private ImageView back_image;
    private EditText editxt_amount;
    private Button btn_add_account, btn_withdraw;
    private RecyclerView recycler_view_add_account;
    private ViewModelClass viewModel;
    private String strDriverId, strHospitalId;
    private AddAccountAmbulanceAdapter adapter;
    private List<AmbulanceDriverBankDetailsModel.Detail> detailList;
    private String accountNum;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_withdraw_ambulance_driver, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        viewModel = new ViewModelClass();

        strDriverId = App.getSharedPref().getStringValue("DriverId");
        strHospitalId = App.getSharedPref().getStringValue("HospitalId");

        findId(view);
        onClick();
        setAdapter();


    }

    private void setAdapter() {

        viewModel.accountDetailsAmbulanceModelLiveData(requireActivity(), strDriverId, strHospitalId).observe(requireActivity(), new Observer<AmbulanceDriverBankDetailsModel>() {
            @Override
            public void onChanged(AmbulanceDriverBankDetailsModel ambulanceDriverBankDetailsModel) {
                if (ambulanceDriverBankDetailsModel.getSuccess().equalsIgnoreCase("1")){
                    detailList = ambulanceDriverBankDetailsModel.getDetails();
                    Toast.makeText(requireContext(), ambulanceDriverBankDetailsModel.getMessage(), Toast.LENGTH_SHORT).show();

                    adapter = new AddAccountAmbulanceAdapter(requireContext(), detailList, new AddAccountAmbulanceAdapter.SelectedAccountAmbulance() {
                        @Override
                        public void selectedAccountNumber(String accountNumber) {
                            accountNum = accountNumber;

                        }
                    }, new AddAccountAmbulanceAdapter.DeleteSelectedAccountAmbulance() {
                        @Override
                        public void deleteAccountNumber(String accountNumber) {
                            accountNum = accountNumber;
                            AlertDialog.Builder alert = new AlertDialog.Builder(requireActivity());
                            alert.setTitle("Delete Account").setIcon(R.drawable.ic_delete);
                            alert.setMessage("Do you want to delete this account?");
                            alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    viewModel.deleteAmbulanceAccountDetailsModelLiveData(requireActivity(),  strDriverId,strHospitalId, accountNum).observe(requireActivity(), new Observer<DeleteAmbulanceAccountDetailsModel>() {
                                        @Override
                                        public void onChanged(DeleteAmbulanceAccountDetailsModel deleteAmbulanceAccountDetailsModel) {

                                           if (deleteAmbulanceAccountDetailsModel.getSuccess().equalsIgnoreCase("1")){
                                               requireActivity().onBackPressed();
                                               Toast.makeText(requireActivity(), deleteAmbulanceAccountDetailsModel.getMessage(), Toast.LENGTH_SHORT).show();

                                           } else {
                                               Toast.makeText(requireActivity(), deleteAmbulanceAccountDetailsModel.getMessage(), Toast.LENGTH_SHORT).show();
                                           }

                                        }
                                    });

                                }
                            });
                            alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    dialog.dismiss();

                                }
                            });
                            alert.show();

                        }
                    });
                    recycler_view_add_account.setAdapter(adapter);

                }
                else {
                    Toast.makeText(requireContext(), ambulanceDriverBankDetailsModel.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });


    }

    private void onClick() {

        back_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requireActivity().onBackPressed();
            }
        });

        btn_add_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_withdrawAmbulanceDriverFragment_to_addBankAcountAmbulanceDriverFragment);
            }
        });

        btn_withdraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                withdrawAmount();

    }

        });
    }

    private void withdrawAmount() {

        String strAmount = editxt_amount.getText().toString();

        if (strAmount.isEmpty()) {
            Toast.makeText(requireActivity(), "Enter Amount", Toast.LENGTH_SHORT).show();
        } else if (accountNum != null && accountNum.equalsIgnoreCase("")) {
            Toast.makeText(requireActivity(), "Please,Select your Account", Toast.LENGTH_SHORT).show();
        } else {

      viewModel.requestAmountWithdrawModelLiveData(requireActivity(), strHospitalId, strDriverId, accountNum, strAmount)
                   .observe(requireActivity(), new Observer<RequestAmountWithdrawModel>() {
                       @Override
                       public void onChanged(RequestAmountWithdrawModel requestAmountWithdrawModel) {
                           if (requestAmountWithdrawModel.getSuccess().equalsIgnoreCase("1")){
                               requireActivity().onBackPressed();
                           } else {
                               Toast.makeText(requireContext(), requestAmountWithdrawModel.getMessage(), Toast.LENGTH_SHORT).show();

                           }
                       }
                   });

        }
    }

    private void findId(View view) {

        back_image = view.findViewById(R.id.back_image);
        btn_add_account = view.findViewById(R.id.btn_add_account);
        btn_withdraw = view.findViewById(R.id.btn_withdraw);
        editxt_amount = view.findViewById(R.id.editxt_amount);

        recycler_view_add_account = view.findViewById(R.id.recycler_view_add_account);

    }
}