package com.expert.healthkangaroodriver.nursing_driver;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.ChatModel.ChatModel;
import com.expert.healthkangaroodriver.Model.ChatModel.LastMessageChatModel;
import com.expert.healthkangaroodriver.Model.nurse_model.NurseOrderListModel;
import com.expert.healthkangaroodriver.adapter_class.nursing_adapters.ChatNurseUserAdapter;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.adapter_class.phlebotomist_adapters.ChatAdapter;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MessageScreenNursingFragment extends Fragment {

    private View view;
    private RecyclerView recycler_view_chat;
    private ImageView back, img_send_message;
    private EditText editxt_write_message;
    private ChatModel chatModelClass;
    private ChatNurseUserAdapter chatAdapter;
    private ProgressDialog dialog;
    private List<ChatModel> list = new ArrayList<>();
    public static NurseOrderListModel.Detail detail;
    private LastMessageChatModel lastMessageChatModel2;
    String driverId, userId, orderId;

    private DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("ChatUserNurseDriver");

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_message_screen, container, false);

        dialog = new ProgressDialog(requireActivity());
        dialog.setMessage("Message Sending......");

        findId();
        onClick();
        senderReceiverIds();
        getMessagesFromFirebase();

        return view;
    }

    private void senderReceiverIds() {

        driverId = detail.getNurseDriverId();
        userId = detail.getUserId();

    }

    private void onClick() {

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                    requireActivity().onBackPressed();
                }
        });

        img_send_message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (editxt_write_message.getText().toString().isEmpty()) {

                    Toast.makeText(requireContext(), "Can't Send Empty Message", Toast.LENGTH_SHORT).show();
                }
                else {

                    sendMessage(editxt_write_message.getText().toString(), "0");
                    getMessagesFromFirebase();

                }


            }
        });

    }
    private void sendMessage(String message, String type) {

        dialog.show();
        orderId = detail.getAppointmentId();

        String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

        String key = reference.push().getKey();

        chatModelClass = new ChatModel();


        chatModelClass.setMessage(message);
        chatModelClass.setDate(currentDate);
        chatModelClass.setTime(currentTime);
        chatModelClass.setType(type);
        chatModelClass.setKey(key);

        reference.child(userId).child(orderId).child(key).setValue(chatModelClass).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {

                dialog.dismiss();
                editxt_write_message.setText("");
                Toast.makeText(getActivity(), "Message send successfully.", Toast.LENGTH_SHORT).show();

            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                dialog.dismiss();
                Toast.makeText(getActivity(), "Message not send.", Toast.LENGTH_SHORT).show();

            }
        });


    }
    private void getMessagesFromFirebase() {
        orderId = detail.getAppointmentId();

        list  = new ArrayList<>();


        reference.child(userId).child(orderId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    list.clear();
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {

                        ChatModel driverChatModel = dataSnapshot.getValue(ChatModel.class);
                        list.add(driverChatModel);
                    }

                    setRecyclerView(list);

                }
                else {

                    Toast.makeText(requireContext(), "Not found", Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });


    }
    private void findId() {
        recycler_view_chat = view.findViewById(R.id.recycler_view_chat_nurse);
        back = view.findViewById(R.id.img_back);
        editxt_write_message = view.findViewById(R.id.editxt_nurse_msg);
        img_send_message = view.findViewById(R.id.send_msg_nurse);
    }
    private void setRecyclerView(List<ChatModel> list) {
        chatAdapter = new ChatNurseUserAdapter(requireActivity(), list);
        recycler_view_chat.setAdapter(chatAdapter);
        recycler_view_chat.smoothScrollToPosition(list.size());
        chatAdapter.notifyDataSetChanged();
    }





}