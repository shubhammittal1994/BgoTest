package com.expert.healthkangaroodriver;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.phlebotomist_driver.PhlebotomistDriverActivity;


public class AddVehicleDetailsFragment extends Fragment {

    private Button btn_continue_add_vehicle;
    private View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_add_vehicle_details, container, false);
        findIds();
        return  view;
    }
    private void findIds() {

        view.findViewById(R.id.btn_continue_add_vehicle).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(getContext(), PhlebotomistDriverActivity.class));
            }
        });
        view.findViewById(R.id.img_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                Navigation.findNavController(v).navigate(R.id.action_add_vehicle_details_to_add_driving_license_details);

                getActivity().onBackPressed();
            }
        });

    }
}