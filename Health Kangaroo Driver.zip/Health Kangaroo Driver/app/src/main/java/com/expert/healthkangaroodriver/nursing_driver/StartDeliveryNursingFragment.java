package com.expert.healthkangaroodriver.nursing_driver;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;

import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.directions.route.AbstractRouting;
import com.directions.route.Route;
import com.directions.route.RouteException;
import com.directions.route.Routing;
import com.directions.route.RoutingListener;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.AppClass.CommonUtils;
import com.expert.healthkangaroodriver.Model.ExtraChargesMode;
import com.expert.healthkangaroodriver.Model.nurse_model.NurseOrderListModel;
import com.expert.healthkangaroodriver.Model.nurse_model.OrderDeliveredNurseModel;
import com.expert.healthkangaroodriver.Model.pharmacy_model.GenerateOptModel;
import com.expert.healthkangaroodriver.phlebotomist_driver.HomePhlebotomistFragment;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;

import de.hdodenhof.circleimageview.CircleImageView;
import in.aabhasjindal.otptextview.OtpTextView;

public class StartDeliveryNursingFragment extends Fragment implements  RoutingListener {

    private View view;
    private ImageView msg_image, back, patience_profile_image, call_btn;
    private TextView txt_patience_name, txt_patience_address, txt_mobile_number;
    private SupportMapFragment mapFragment;
    private GoogleMap map;
    private List<Polyline> polylines=null;
    private double currentLat = HomeNursingFragment.myLat, currentLog = HomeNursingFragment.myLng, patienceLat, patienceLog;
    public static NurseOrderListModel.Detail detail;
    private MarkerOptions place1, place2;
    LatLng start, end;
    int PERMISSION_ALL = 1;
    String[] PERMISSIONS = {Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE};
    private AppCompatButton startService, endService, extra_charges;
    DatabaseReference reference = FirebaseDatabase.getInstance().getReference("TrackNurseDriver");
    String driverId, userId, orderId, otpView, vendorId;
    String status;
    Uri imageUriPhotos;
    String stringPhotoPath, strDriverId;
    CircleImageView imageView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_nursing_delivery_start, container, false);

        if(!hasPermissions(requireActivity(), PERMISSIONS)){
            ActivityCompat.requestPermissions(requireActivity(), PERMISSIONS, PERMISSION_ALL);
        }
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.CALL_PHONE}, 1);
        }

        strDriverId = App.getSharedPref().getStringValue("DriverId");


        FindId();

        setData();

        onClick();

        mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.frgMapDriverNursing);

        assert mapFragment != null;

        place1 = new MarkerOptions().position(new LatLng(currentLat, currentLog)).title("Your Location");
        place2 = new MarkerOptions().position(new LatLng(patienceLat, patienceLog)).title("Patient Location");

        mapFragment.getMapAsync(googleMap -> {
            map = googleMap;
            map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
            map.setTrafficEnabled(true);
            if (ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }


            map.setMyLocationEnabled(false);
            map.addMarker(place1);
            map.addMarker(place2);

            start = new LatLng(currentLat, currentLog);
            end = new LatLng(patienceLat, patienceLog);

            Findroutes(start, end);

            map.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(currentLat, currentLog), 16));

        });

        checkEndBtn();


        return view;
    }

    private void checkEndBtn() {

        reference.child(detail.getAppointmentId()).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                try {
                     status = snapshot.child("status").getValue().toString();

                } catch (Exception e) {

                    e.printStackTrace();
                }

                try {
                    if (status.equals("1"))
                    {
                        extra_charges.setVisibility(View.VISIBLE);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public static boolean hasPermissions(Context context, String... permissions) {
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }
    private double distance(double lat1, double lng1, double lat2, double lng2) {

        Location loc1 = new Location("");
        loc1.setLatitude(lat1);
        loc1.setLongitude(lng1);
        Location loc2 = new Location("");
        loc2.setLatitude(lat2);
        loc2.setLongitude(lng2);

        float distanceInMeters = loc1.distanceTo(loc2);

        float km = distanceInMeters/1000;

        if (km > 0.2f){

            startService.setVisibility(View.VISIBLE);
        }


        return distanceInMeters;

    }
    public void Findroutes(LatLng Start, LatLng End) {
        distance(currentLat, currentLog, patienceLat, patienceLog);

        if (Start == null || End == null) {

            Toast.makeText(requireActivity(), "Unable to get location", Toast.LENGTH_LONG).show();

        } else {

            Routing routing = new Routing.Builder()
                    .travelMode(AbstractRouting.TravelMode.DRIVING)
                    .withListener(this)
                    .alternativeRoutes(true)
                    .waypoints(Start, End)
                    .key(requireActivity().getString(R.string.api_map_key))  //also define your api key here.
                    .build();
            routing.execute();

        }
    }
    private void setData() {
        ///Glide.with(view).load(detail.getImage()).into(patience_profile_image);

        try {

            patienceLat = Double.parseDouble(detail.getLatitude());
            patienceLog = Double.parseDouble(detail.getLongitude());

        } catch (Exception e) {
            e.printStackTrace();

            Toast.makeText(requireContext(), "Address not found", Toast.LENGTH_SHORT).show();

        }

        txt_patience_name.setText(detail.getPatientName());
        txt_patience_address.setText(detail.getPatientAddress());
        txt_mobile_number.setText(detail.getPhone());

    }
    private void onClick() {

        msg_image.setOnClickListener(v -> Navigation.findNavController(view).navigate(R.id.action_mydeliveryStartScreen_to_messageScreen));

        back.setOnClickListener(v -> requireActivity().onBackPressed());

        call_btn.setOnClickListener(v -> {

            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:" + detail.getPhone()));
            startActivity(callIntent);
        });

        startService.setOnClickListener(v -> {
            generateServiceOtp();

        });

        endService.setOnClickListener(v -> {

            endServiceOtp();
        });


        extra_charges.setOnClickListener(v -> {

            extraDialog();
        });



    }

    private void extraDialog() {

        final Dialog dialog = new Dialog(requireActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.extra_items_layout);
        dialog.setCancelable(true);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        AppCompatButton yes = dialog.findViewById(R.id.btn_done);
        AppCompatButton no = dialog.findViewById(R.id.btn_not_done);
         imageView = dialog.findViewById(R.id.img_hospital_photo);
        ImageView upload = dialog.findViewById(R.id.img_upload_photo_id);
        EditText edtAmount = dialog.findViewById(R.id.edtAmount);



        upload.setOnClickListener(v -> {

            ImagePicker.with(this)
                    .crop()	    			//Crop image(Optional), Check Customization for more option
                    .compress(1024)			//Final image size will be less than 1 MB(Optional)
                    .maxResultSize(1080, 1080)	//Final image resolution will be less than 1080 x 1080(Optional)
                    .start();
        });


        yes.setOnClickListener(v -> {

            String amount = edtAmount.getText().toString().trim();

            if (amount.isEmpty()) {

                Toast.makeText(requireContext(), "Enter Price", Toast.LENGTH_SHORT).show();
            }
            if (imageUriPhotos == null) {

                Toast.makeText(requireContext(), "Please Select Photo Hospital Photo", Toast.LENGTH_SHORT).show();

            }


            new ViewModelClass().extraChargesModeLiveData(requireActivity(),
                    CommonUtils.stringToRequest(amount),

                    CommonUtils.stringToRequest(strDriverId),

                    CommonUtils.imageToMultiPart("image", stringPhotoPath)).observe(requireActivity(), new Observer<ExtraChargesMode>() {
                @Override
                public void onChanged(ExtraChargesMode extraChargesMode) {
                    if (extraChargesMode.getSuccess().equalsIgnoreCase("1"))
                    {
                        Toast.makeText(requireContext(), extraChargesMode.getMessage(), Toast.LENGTH_SHORT).show();
                      
                        extra_charges.setVisibility(View.GONE);
                        endService.setVisibility(View.VISIBLE);
                      
                        dialog.dismiss();


                    }else {

                        Toast.makeText(requireContext(), extraChargesMode.getMessage(), Toast.LENGTH_SHORT).show();

                    }

                }
            });
        });

        no.setOnClickListener(v -> {

            extra_charges.setVisibility(View.GONE);
            endService.setVisibility(View.VISIBLE);

            dialog.dismiss();

        });

        dialog.show();
    }

    private void endServiceOtp() {
        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        String currentTime = sdf.format(new Date());

        orderId = detail.getAppointmentId();
        driverId = detail.getNurseDriverId();
        userId = detail.getUserId();

        Random rand = new Random();
        String opt = String.format("%04d", rand.nextInt(10000));

        Map map = new HashMap();
        map.put("endOtp", opt);
        map.put("startOtp", "");
        map.put("status", "2");
        map.put("endTime", currentTime);

        reference.child(orderId).updateChildren(map).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {

                opeEndDialog();

            }
        });

    }
    private void opeEndDialog() {

        final Dialog dialog = new Dialog(requireActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.end_service_layout);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        AppCompatButton startBtn = dialog.findViewById(R.id.end_service_btn);

        OtpTextView otpTextView = dialog.findViewById(R.id.otp_view_end_nurse);

        orderId = detail.getAppointmentId();

        reference.child(orderId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                otpView = snapshot.child("endOtp").getValue().toString();

                try {

                    Toast.makeText(requireActivity(), "otp " + otpView, Toast.LENGTH_SHORT).show();

                } catch (Exception e) {
                    e.printStackTrace();
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        startBtn.setOnClickListener(v -> {

            otpTextView.equals(otpView);

            if (otpTextView.getOTP().toString().equals(otpView)){

                Toast.makeText(requireActivity(), "Service End", Toast.LENGTH_SHORT).show();
                differenceTime();
                dialog.dismiss();

            }else {
                Toast.makeText(requireActivity(), "Please Enter Valid Otp", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();

    }
    private void differenceTime() {

        final Dialog dialog = new Dialog(requireActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.total_time_layout);
        dialog.setCancelable(false);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        TextView startTimeTxt = dialog.findViewById(R.id.start_time);
        TextView endTimeTxt = dialog.findViewById(R.id.end_time);
        TextView totalTimeTxt = dialog.findViewById(R.id.total_time);
        AppCompatButton button = dialog.findViewById(R.id.end_service_btn_nurse);

        button.setOnClickListener(v -> {

            if (detail.getOrderType().equalsIgnoreCase("1")){

                orderDelivered("1");

            }
            else if (detail.getOrderType().equalsIgnoreCase("2"))

            {
                orderDelivered("2");


            }else if (detail.getOrderType().equalsIgnoreCase("3"))

            {
                orderDelivered("3");

            }else if (detail.getOrderType().equalsIgnoreCase("4"))

            {
                orderDelivered("4");

            }else {

                Toast.makeText(requireContext(), "Something went wrong", Toast.LENGTH_SHORT).show();

            }

         dialog.dismiss();

        });

        orderId = detail.getAppointmentId();

        reference.child(orderId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                String startTime = snapshot.child("startTime").getValue().toString();
                String endTime = snapshot.child("endTime").getValue().toString();
                String totalTime = snapshot.child("difference").getValue().toString();

                startTimeTxt.setText(startTime);
                endTimeTxt.setText(endTime);
                totalTimeTxt.setText(totalTime);

                SimpleDateFormat simpleDateFormat = new SimpleDateFormat("hh:mm a");

                Date date1 = null;
                try {

                    date1 = simpleDateFormat.parse(startTime);
                } catch (ParseException e) {
                    e.printStackTrace();
                }
                Date date2 = null;
                try {
                    date2 = simpleDateFormat.parse(endTime);
                } catch (ParseException e) {
                    e.printStackTrace();
                }

                long difference = date2.getTime() - date1.getTime();
                int  days = (int) (difference / (1000*60*60*24));
                int    hours = (int) ((difference - (1000*60*60*24*days)) / (1000*60*60));
                int  min = (int) (difference - (1000*60*60*24*days) - (1000*60*60*hours)) / (1000*60);

                hours = (hours < 0 ? -hours : hours);
                min = (min < 0 ? -min : min);

                Map map = new HashMap();

                map.put("difference", "0 "+hours+" hr"+":"+min+" min");

                reference.child(orderId).updateChildren(map);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        dialog.show();


    }
    private void orderDelivered(String s) {

        new ViewModelClass().orderDeliveredNurseModelLiveData(detail.getVendorId(),
                detail.getNurseDriverId(),
                detail.getAppointmentId(), s).observe(requireActivity(), new Observer<OrderDeliveredNurseModel>() {
            @Override
            public void onChanged(OrderDeliveredNurseModel orderDeliveredNurseModel) {
                if (orderDeliveredNurseModel.getSuccess().equalsIgnoreCase("1"))
                {
                    requireActivity().onBackPressed();

                    Toast.makeText(requireActivity(), orderDeliveredNurseModel.getMessage(), Toast.LENGTH_SHORT).show();
                }

                else {
                    Toast.makeText(requireActivity(), orderDeliveredNurseModel.getMessage(), Toast.LENGTH_SHORT).show();

                }
            }
        });

    }
    private void generateServiceOtp() {

        SimpleDateFormat sdf = new SimpleDateFormat("hh:mm a", Locale.getDefault());
        String currentTime = sdf.format(new Date());
        orderId = detail.getAppointmentId();
        driverId = detail.getNurseDriverId();
        userId = detail.getUserId();

        Random rand = new Random();
        String opt = String.format("%04d", rand.nextInt(10000));

        Map map = new HashMap();
        map.put("startOtp", opt);
        map.put("startTime", currentTime);

        reference.child(orderId).updateChildren(map).addOnCompleteListener(new OnCompleteListener() {
            @Override
            public void onComplete(@NonNull Task task) {
                if (task.isSuccessful()){

                    startService.setVisibility(View.GONE);

                        openDialog();

                }
            }
        });


    }
    private void openDialog() {

        final Dialog dialog = new Dialog(requireActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.start_service_layout);
        dialog.setCancelable(false);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        AppCompatButton startBtn = dialog.findViewById(R.id.start_service_btn);

        OtpTextView otpTextView = dialog.findViewById(R.id.otp_view_nurse);

        orderId = detail.getAppointmentId();

        reference.child(orderId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                otpView = snapshot.child("startOtp").getValue().toString();

                String status = snapshot.child("status").getValue().toString();


                if (status.equals("1")){

                    extra_charges.setVisibility(View.VISIBLE);
                }
                try {

                    Toast.makeText(requireActivity(), "otp "+otpView, Toast.LENGTH_SHORT).show();

                } catch (Exception e) {
                    e.printStackTrace();
                }


            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        startBtn.setOnClickListener(v -> {

            otpTextView.equals(otpView);

            if (otpTextView.getOTP().toString().equals(otpView)){

                Toast.makeText(requireActivity(), "Service Started", Toast.LENGTH_SHORT).show();

                Map map = new HashMap();
                map.put("status", "1");

                reference.child(orderId).updateChildren(map);

                dialog.dismiss();

            }else {

                Toast.makeText(requireActivity(), "Please Enter Valid Otp", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();

    }
    private void FindId() {

        msg_image = view.findViewById(R.id.message_btn);
        call_btn = view.findViewById(R.id.call_btn);
        back = view.findViewById(R.id.back_image);

        patience_profile_image = view.findViewById(R.id.patience_profile_image);
        txt_patience_name = view.findViewById(R.id.txt_patience_name);
        txt_patience_address = view.findViewById(R.id.txt_patience_address);
        txt_mobile_number = view.findViewById(R.id.txt_mobile_number);
        startService = view.findViewById(R.id.start_service_nurse);
        endService = view.findViewById(R.id.end_service_nurse);
        extra_charges = view.findViewById(R.id.extra_charges);
    }
    @Override
    public void onRoutingFailure(RouteException e) {

    }
    @Override
    public void onRoutingStart() { }
    @Override
    public void onRoutingSuccess(ArrayList<Route> route, int shortestRouteIndex) {
        map.clear();
        distance(currentLat, currentLog, patienceLat, patienceLog);

        CameraUpdate center = CameraUpdateFactory.newLatLng(start);
        CameraUpdate zoom = CameraUpdateFactory.zoomTo(16);

        map.moveCamera(zoom);
        map.animateCamera(zoom);
        map.animateCamera(center);

        if(polylines!=null) {
            polylines.clear();
        }

        PolylineOptions polyOptions = new PolylineOptions();
        LatLng polylineStartLatLng=null;
        LatLng polylineEndLatLng=null;


        polylines = new ArrayList<>();

        for (int i = 0; i <route.size(); i++) {

            if(i==shortestRouteIndex)
            {
                polyOptions.color(getResources().getColor(R.color.black));
                polyOptions.width(20);
                polyOptions.addAll(route.get(shortestRouteIndex).getPoints());
                Polyline polyline = map.addPolyline(polyOptions);
                polylineStartLatLng=polyline.getPoints().get(0);
                int k=polyline.getPoints().size();
                polylineEndLatLng=polyline.getPoints().get(k-1);
                polylines.add(polyline);

            }
            else {

            }

        }


        //Add Marker on route ending position

        if (end != null) {
            MarkerOptions endMarker = new MarkerOptions();
            endMarker.position(end);
            endMarker.icon(BitmapDescriptorFactory.fromResource(R.drawable.map_point));
            map.addMarker(endMarker);
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(end, 18));
        }
        if (start != null) {
            MarkerOptions endMarker = new MarkerOptions();
            endMarker.position(start);
            endMarker.icon(BitmapDescriptorFactory.fromResource(R.drawable.drive));
            map.addMarker(endMarker);
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(start, 18));
        }

        Findroutes(start,end);

    }
    @Override
    public void onRoutingCancelled() {
        Findroutes(start,end);
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {

            imageUriPhotos = data.getData();

            stringPhotoPath = imageUriPhotos.getPath();

            Toast.makeText(getContext(), stringPhotoPath, Toast.LENGTH_SHORT).show();

            imageView.setImageURI(imageUriPhotos);

        } else if (resultCode == ImagePicker.RESULT_ERROR) {

            Toast.makeText(requireContext(), ImagePicker.getError(data), Toast.LENGTH_SHORT).show();

        } else {

            Toast.makeText(requireContext(), "Image Uploading Cancelled", Toast.LENGTH_SHORT).show();
        }
    }
}