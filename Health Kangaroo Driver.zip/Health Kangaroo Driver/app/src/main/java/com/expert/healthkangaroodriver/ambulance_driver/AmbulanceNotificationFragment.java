package com.expert.healthkangaroodriver.ambulance_driver;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.media.Image;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.AmbulanceNotificationModal;
import com.expert.healthkangaroodriver.Model.RemoveNotificationModal;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;


public class AmbulanceNotificationFragment extends Fragment {

    View view;
    RecyclerView recyclerView;
    String strDriverId;
    ImageView back_image;




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view =  inflater.inflate(R.layout.fragment_ambulance_notification, container, false);

        recyclerView = view.findViewById(R.id.recycler_notifications);
        back_image = view.findViewById(R.id.back_image);
        strDriverId = App.getSharedPref().getStringValue("DriverId");

        back_image.setOnClickListener(v -> {

            requireActivity().onBackPressed();

        });

        new ViewModelClass().ambulanceNotificationModalMutableLiveData(requireActivity(), strDriverId).observe(requireActivity(), new Observer<AmbulanceNotificationModal>() {
            @Override
            public void onChanged(AmbulanceNotificationModal ambulanceNotificationModal) {
                if (ambulanceNotificationModal.getSuccess().equalsIgnoreCase("1"))
                {
                    Notifications_list_adapter adapter = new Notifications_list_adapter(ambulanceNotificationModal.getDetails(), new Notifications_list_adapter.NotificationInterface() {
                        @Override
                        public void removeNotificationCallBack(AmbulanceNotificationModal.Detail detail) {
                            AlertDialog.Builder builder1 = new AlertDialog.Builder(requireContext());
                            builder1.setMessage("Are you sure want to delete ?.");
                            builder1.setCancelable(true);
                            builder1.setPositiveButton(
                                    "Yes",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            removeNotification(detail.getId());

                                        }
                                    });

                            builder1.setNegativeButton(
                                    "No",
                                    new DialogInterface.OnClickListener() {
                                        public void onClick(DialogInterface dialog, int id) {
                                            dialog.cancel();
                                        }
                                    });

                            AlertDialog alert11 = builder1.create();
                            alert11.show();


                        }
                    }, requireContext());

                    recyclerView.setAdapter(adapter);
                }
            }
        });
        return view;

    }

    private void removeNotification(String id) {
        new ViewModelClass().removeNotificationModalMutableLiveData(requireActivity(), strDriverId, id).observe(requireActivity(), new Observer<RemoveNotificationModal>() {
            @Override
            public void onChanged(RemoveNotificationModal notificationRemoveModal) {
                if (notificationRemoveModal.getSuccess().equalsIgnoreCase("1")) {

                    Toast.makeText(requireContext(), "" + notificationRemoveModal.getMessage(), Toast.LENGTH_SHORT).show();

                } else {

                    Toast.makeText(requireContext(), "" + notificationRemoveModal.getMessage(), Toast.LENGTH_SHORT).show();

                }
            }
        });
    }

}
