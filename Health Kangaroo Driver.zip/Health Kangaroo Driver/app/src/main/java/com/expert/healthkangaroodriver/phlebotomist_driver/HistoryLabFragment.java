package com.expert.healthkangaroodriver.phlebotomist_driver;

import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.pharmacy_model.HistoryOrderPharmacyModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.LabDeliveryHistoryModel;
import com.expert.healthkangaroodriver.adapter_class.pharmacy_adapters.HistoryAdapter;
import com.expert.healthkangaroodriver.adapter_class.phlebotomist_adapters.HistoryLabAdapter;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;

import java.util.ArrayList;
import java.util.List;

public class HistoryLabFragment extends Fragment {
    private View view;
    private RecyclerView historyRecycler;
    private ImageView img_back, not_found;
    private String strVenderId, strDriverId;
    private ViewModelClass viewModel;
    private List<LabDeliveryHistoryModel.Detail> sampleList = new ArrayList<>();
    private ProgressDialog dialog;
    private TextView total_orders;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view =  inflater.inflate(R.layout.fragment_history_lab, container, false);

        strDriverId = App.getSharedPref().getStringValue("DriverId");
        strVenderId = App.getSharedPref().getStringValue("VenderId");

        dialog = new ProgressDialog(requireActivity());
        dialog.setMessage("Loading.....");

        FindId();
        onClick();
        setAdapter();


        return view;

    }

    private void setAdapter() {
        dialog.show();

        new ViewModelClass().labDeliveryHistoryModelLiveData(requireActivity(), strVenderId, strDriverId).observe(requireActivity(), new Observer<LabDeliveryHistoryModel>() {
            @Override
            public void onChanged(LabDeliveryHistoryModel labDeliveryHistoryModel) {
                dialog.dismiss();

                if (labDeliveryHistoryModel.getSuccess().equalsIgnoreCase("True")){
                    dialog.dismiss();

                    sampleList = labDeliveryHistoryModel.getDetails();
                    HistoryLabAdapter historyAdapter = new HistoryLabAdapter(requireActivity(), sampleList, new HistoryLabAdapter.HistoryPosition() {
                        @Override
                        public void details(LabDeliveryHistoryModel.Detail detail) {

                        }
                    });

                    historyRecycler.setAdapter(historyAdapter);
                    total_orders.setText(" "+sampleList.size());

                }  else if (labDeliveryHistoryModel.getSuccess().equalsIgnoreCase("False")){

                    dialog.dismiss();

                    not_found.setVisibility(View.VISIBLE);

                }
            }
        });
    }

    private void FindId() {

        img_back=view.findViewById(R.id.img_back);
        historyRecycler=view.findViewById(R.id.recycler_pharmacy_history);
        not_found = view.findViewById(R.id.not_found1);
        total_orders = view.findViewById(R.id.total_orders);
    }
    private void onClick() {

        img_back.setOnClickListener(v -> requireActivity().onBackPressed());

    }
}