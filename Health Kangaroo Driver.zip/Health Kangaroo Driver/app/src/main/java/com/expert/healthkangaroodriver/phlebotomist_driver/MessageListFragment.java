package com.expert.healthkangaroodriver.phlebotomist_driver;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.ChatModel.LastMessageChatModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.PhlebotomistDriverSampleCollectionModel;
import com.expert.healthkangaroodriver.adapter_class.ChatAdapter.MessageListAdapter;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class MessageListFragment extends Fragment {
    private View view;
    private RecyclerView recycler_view;
    private ImageView profile_image, imgNotification, home, videos, chat, profile;
    private LinearLayout live;
    private List<LastMessageChatModel> lastMessageChatModels = new ArrayList<>();
    public static PhlebotomistDriverSampleCollectionModel.Detail detail;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
      view = inflater.inflate(R.layout.fragment_message_list, container, false);

        findID();
        getListFromFireBase();


        return view;
    }
    private void setAdapter(List<LastMessageChatModel> lastMessageChatModels) {
        MessageListAdapter messageListAdapter = new MessageListAdapter(getContext(), lastMessageChatModels, new MessageListAdapter.click() {
            @Override
            public void clicks(int position, String id) {
                Bundle bundle = new Bundle();
                ChatMessagingStartScreenPhlebotomistFragment fragment = new ChatMessagingStartScreenPhlebotomistFragment();
                bundle.putString(detail.getLabDriverId(), id);
                fragment.setArguments(bundle);
                Toast.makeText(requireContext(), ""+id, Toast.LENGTH_SHORT).show();
            }
        });
        recycler_view.setAdapter(messageListAdapter);
    }

    private void getListFromFireBase() {

        Query query = FirebaseDatabase.getInstance().getReference().child("ChatUserDriver").child("LastMessage").child(detail.getAppointmentId());


        query.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull @NotNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Iterable<DataSnapshot> iterable = snapshot.getChildren();
                    lastMessageChatModels.clear();
                    for (DataSnapshot data : iterable) {
                        lastMessageChatModels.add(data.getValue(LastMessageChatModel.class));
                    }
                    setAdapter(lastMessageChatModels);
                }
            }

            @Override
            public void onCancelled(@NonNull @NotNull DatabaseError error) {
            }
        });
    }

    private void findID() {
        recycler_view = view.findViewById(R.id.recycler_view_list);
        profile_image = view.findViewById(R.id.imgProfile);
        imgNotification = view.findViewById(R.id.imgNotification);

    }

}