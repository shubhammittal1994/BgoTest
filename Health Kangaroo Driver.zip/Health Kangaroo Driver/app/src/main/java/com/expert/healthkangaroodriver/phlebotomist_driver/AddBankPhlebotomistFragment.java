package com.expert.healthkangaroodriver.phlebotomist_driver;

import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.nurse_model.SpinnerBankListModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.AddAccountDetailsPhlebotomistModel;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;


public class AddBankPhlebotomistFragment extends Fragment {
    private View view;
    private ImageView back;
    private Button done_btn;
    private String strDriverId, strVenderId, strAccountHoldersName, strAccountNumber, strIFSCCode, spinnerData;
    private EditText editxt_account_holders_name, editxt_account_number, editxt_ifsc_code;
    private Spinner spinner_bank_name;
    private ProgressDialog progressDialog;
    private ViewModelClass viewModel;
    private ArrayAdapter adapter;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_add_bank_phlebotomist, container, false);

        progressDialog = new ProgressDialog(requireActivity());
        progressDialog.setMessage("Loading.....");

        strDriverId = App.getSharedPref().getStringValue("DriverId");
        strVenderId = App.getSharedPref().getStringValue("VenderId");

        viewModel = new ViewModelClass();

        FindId();
        getSpinnerData();
        onClick();

        return view;
    }

    private void onClick() {

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requireActivity().onBackPressed();
            }
        });

        done_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show();

                strAccountHoldersName = editxt_account_holders_name.getText().toString();
                strAccountNumber = editxt_account_number.getText().toString();
                strIFSCCode = editxt_ifsc_code.getText().toString();

                if (strAccountHoldersName.equalsIgnoreCase("")) {
                    progressDialog.dismiss();
                    Toast.makeText(requireActivity(), "Please Enter Account Holders Name", Toast.LENGTH_SHORT).show();
                } else if (strAccountNumber.equalsIgnoreCase("")) {
                    progressDialog.dismiss();
                    Toast.makeText(requireActivity(), "Please Enter Account number", Toast.LENGTH_SHORT).show();
                } else if (spinnerData == null) {
                    progressDialog.dismiss();
                    Toast.makeText(requireActivity(), "Please, Choose Bank Account ", Toast.LENGTH_SHORT).show();
                } else if (strIFSCCode.equalsIgnoreCase("")) {
                    progressDialog.dismiss();
                    Toast.makeText(requireActivity(), "Please Enter IFSC Code", Toast.LENGTH_SHORT).show();
                } else {

                    viewModel.liveDataAddAccountDetailsPhlebotomist(requireActivity(), strDriverId, strVenderId, strAccountHoldersName, strAccountNumber, spinnerData, strIFSCCode).observe(requireActivity(), new Observer<AddAccountDetailsPhlebotomistModel>() {
                        @Override
                        public void onChanged(AddAccountDetailsPhlebotomistModel addAccountDetailsPhlebotomistModel) {
                            if (addAccountDetailsPhlebotomistModel.getSuccess().equalsIgnoreCase("1")) {
                                Toast.makeText(requireActivity(), addAccountDetailsPhlebotomistModel.getMessage(), Toast.LENGTH_SHORT).show();
                                requireActivity().onBackPressed();
                                progressDialog.dismiss();
                            } else {
                                Toast.makeText(requireActivity(), addAccountDetailsPhlebotomistModel.getMessage(), Toast.LENGTH_SHORT).show();
                                progressDialog.dismiss();
                            }
                        }
                    });

                }

            }
        });

    }

    private void getSpinnerData() {
        progressDialog.show();

        viewModel.LiveDataSpinnerBankList(requireActivity()).observe(requireActivity(), new Observer<SpinnerBankListModel>() {
            @Override
            public void onChanged(SpinnerBankListModel spinnerBankListModel) {
                if (spinnerBankListModel.getSuccess().equalsIgnoreCase("1")) {
                    adapter = new ArrayAdapter<String>(requireActivity(), android.R.layout.simple_spinner_dropdown_item);
                    adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                    for (int i = 0; i < spinnerBankListModel.getDetails().size(); i++) {
                        adapter.add(spinnerBankListModel.getDetails().get(i).getBankName());
                    }

                    spinner_bank_name.setAdapter(adapter);
                    progressDialog.dismiss();
                } else {
                    Toast.makeText(requireActivity(), spinnerBankListModel.getMessage(), Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }

                spinner_bank_name.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        int spinnerIndex = spinner_bank_name.getSelectedItemPosition();

                        spinnerData = spinnerBankListModel.getDetails().get(spinnerIndex).getBankName();

                        if (spinnerIndex == 0) {
                            spinnerData = null;
                        }

                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });


            }
        });


    }

    private void FindId() {

        back = view.findViewById(R.id.back_image);

        editxt_account_holders_name = view.findViewById(R.id.editxt_account_holders_name);
        editxt_account_number = view.findViewById(R.id.editxt_account_number);
        editxt_ifsc_code = view.findViewById(R.id.editxt_ifsc_code);

        spinner_bank_name = view.findViewById(R.id.spinner_bank_name);

        done_btn = view.findViewById(R.id.done_btn);

    }

}