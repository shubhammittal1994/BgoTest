package com.expert.healthkangaroodriver;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;

import com.example.healthkangaroo.R;


public class UploadDrivingLicenseFragment extends Fragment {
    private View view;
    private ImageView mImageView;
    private AlertDialog alertDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_upload_driving_license, container, false);


        findIds();


        return view;
    }
    private void openDialog(View view1){
        AlertDialog.Builder alert = new AlertDialog.Builder(getActivity());
        View view2 = getLayoutInflater().inflate(R.layout.dialog_box_submitted_succ,null);
        alert.setView(view2);
        alertDialog = alert.create();
        alertDialog = alert.show();
        alertDialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        Button button;
        button = view2.findViewById(R.id.continue_doc_submitted);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
                Navigation.findNavController(view1).navigate(R.id.action_uploadDrivingLicense_to_addDrivingLicenseDetails);
            }
        });
    }
    private void findIds() {
        view.findViewById(R.id.upload_driving_license_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v2) {
                openDialog(v2);
            }
        });
        view.findViewById(R.id.img_back).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });
    }
}