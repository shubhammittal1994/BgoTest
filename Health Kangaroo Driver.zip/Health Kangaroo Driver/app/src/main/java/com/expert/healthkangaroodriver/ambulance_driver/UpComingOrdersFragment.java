package com.expert.healthkangaroodriver.ambulance_driver;

import static com.expert.healthkangaroodriver.ambulance_driver.HomeAmbulanceDriverFragment.myLat;
import static com.expert.healthkangaroodriver.ambulance_driver.HomeAmbulanceDriverFragment.myLng;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.ReferralCaseModal;
import com.expert.healthkangaroodriver.Model.TrackAmbulanceModel;
import com.expert.healthkangaroodriver.adapter_class.ambulance_adapter.AllAmbulanceHVAdapter;
import com.expert.healthkangaroodriver.adapter_class.ambulance_adapter.OrderPagerAdapter;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;
import com.google.android.material.progressindicator.CircularProgressIndicator;
import com.google.android.material.tabs.TabLayout;

public class UpComingOrdersFragment extends Fragment {
    private View view;
    RecyclerView rv_manage_ambulance;
    String strDriverId;
    RelativeLayout rl_no_list_found;
    CircularProgressIndicator progress_bar;
    String userId, userName, patient_lat, patient_long, phone, relation, address, city;

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view =  inflater.inflate(R.layout.fragment_up_coming_orders, container, false);

        rv_manage_ambulance = view.findViewById(R.id.rv_manage_ambulance);
        rl_no_list_found = view.findViewById(R.id.rl_no_list_found);
        progress_bar = view.findViewById(R.id.progress_bar);

        strDriverId = App.getSharedPref().getStringValue("DriverId");

        setAdapters();

        return view.getRootView();
    }

    private void setAdapters() {

        rl_no_list_found.setVisibility(View.GONE);

       new ViewModelClass().trackAmbulanceModelMutableLiveData(requireActivity(), strDriverId).observe(requireActivity(),
               trackAmbulanceModel -> {
                   progress_bar.setVisibility(View.GONE);

                   rv_manage_ambulance.setVisibility(View.VISIBLE);

                   if (trackAmbulanceModel.getSuccess().equalsIgnoreCase("1"))
                   {
                       AllAmbulanceHVAdapter adapter = new AllAmbulanceHVAdapter(getContext(), trackAmbulanceModel.getDetails(), new AllAmbulanceHVAdapter.Click() {
                           @Override
                           public void onClick(ReferralCaseModal.Detail detail) {

//                               ReferralDetailsFragment.detail= detail;
//                               userName     = detail.getUserName();
//                               patient_lat  = detail.getLatitude();
//                               patient_long = detail.getLongitude();
//                               address =    detail.getCompleteAddress();
//                               phone   =    detail.getPhone();
//                               userId  =    detail.getUserId();
//                               //  sendRequest(detail.getDriverId());
//
//
//                               Bundle bundle = new Bundle();
//                               bundle.putString("patient_lat", String.valueOf(patient_lat));
//                               bundle.putString("patient_long", String.valueOf(patient_long));
//                               bundle.putString("driverLat", String.valueOf(myLat));
//                               bundle.putString("driverLong", String.valueOf(myLng));
//                               bundle.putString("HospitalLatitude", String.valueOf(detail.getHospitalLatitude()));
//                               bundle.putString("HospitalLongitude", String.valueOf(detail.getHospitalLongitude()));
//                               bundle.putString("address", address);
//                               bundle.putString("phone", phone);
//                               bundle.putString("userName", detail.getUserName());
//                               bundle.putString("orderId", detail.getBookingId());
//                               bundle.putString("userid", detail.getUserId());
//
//
//                               Navigation.findNavController(view).navigate(R.id.referralCaseMapFragment, bundle);
                           }
                       });
                       rv_manage_ambulance.setAdapter(adapter);
                   }
                   else {
                       progress_bar.setVisibility(View.GONE);
                       rl_no_list_found.setVisibility(View.VISIBLE);
                       Toast.makeText(requireContext(), trackAmbulanceModel.getMessage(), Toast.LENGTH_SHORT).show();
                   }
               });
    }

}