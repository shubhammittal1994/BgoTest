package com.expert.healthkangaroodriver.adapter_class.ChatAdapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.ChatModel.LastMessageChatModel;

import java.util.List;

public class MessageListAdapter extends RecyclerView.Adapter<MessageListAdapter.ViewHolder> {

    Context context;
    List<LastMessageChatModel> lastMessageChatModels;
    click click;

    public MessageListAdapter(Context context, List<LastMessageChatModel> lastMessageChatModels, MessageListAdapter.click click) {
        this.context = context;
        this.lastMessageChatModels = lastMessageChatModels;
        this.click = click;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_message_list_design, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, @SuppressLint("RecyclerView") int position) {

//        if (lastMessageChatModels.get(position).getUserName().equalsIgnoreCase("")) {
//            holder.txtUserName.setText("User Name");
//
//        } else {
//            holder.txtUserName.setText(lastMessageChatModels.get(position).getUserName());
//
//        }


        holder.txtUserName.setText(lastMessageChatModels.get(position).getUserName());
        holder.txtLastMessage.setText(lastMessageChatModels.get(position).getMessage());
        holder.txtTime.setText(lastMessageChatModels.get(position).getTime().substring(1, 5));

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                click.clicks(position, lastMessageChatModels.get(position).getUserId());
            }
        });

    }

    @Override
    public int getItemCount() {
        return lastMessageChatModels.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView txtUserName, txtLastMessage, txtTime;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txtUserName = itemView.findViewById(R.id.txtUserName);
            txtLastMessage = itemView.findViewById(R.id.txtLastMessage);
            txtTime = itemView.findViewById(R.id.txtTime);

        }
    }


    public interface click {
        void clicks(int position, String id);
    }
}
