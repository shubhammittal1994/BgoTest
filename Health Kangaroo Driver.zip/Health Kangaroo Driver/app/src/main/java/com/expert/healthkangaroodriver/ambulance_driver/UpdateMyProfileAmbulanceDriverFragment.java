package com.expert.healthkangaroodriver.ambulance_driver;

import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import android.provider.MediaStore;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.ambulance_model.UpdateProfileAmbulanceModel;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Random;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class UpdateMyProfileAmbulanceDriverFragment extends Fragment {
    private View view;
    private ImageView img_arrow, img_profile_pic, img_add;
    private Dialog dialog;
    private String imagePath, strName, strSurename, strPhone, strEmail, strDriverId, strHospitalID;
    private EditText editxt_name, editxt_surename, editxt_phone_number, editxt_email;
    private Button btn_save;
    private RequestBody rb_name, rb_surename, rb_phone, rb_email, rb_driverId, rb_hospitalId;
    private MultipartBody.Part rb_image;
    private ViewModelClass viewModel;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_update_my_profile_ambulance_driver, container, false);

        findID();

        strDriverId = App.getSharedPref().getStringValue("userid");
        strHospitalID = App.getSharedPref().getStringValue("HospitalId");

        onClick();

        return view;
    }

    private void onClick() {

        img_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requireActivity().onBackPressed();
            }
        });

        img_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialog = new Dialog(requireActivity());
                dialog.setContentView(R.layout.layout_image_picker);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialog.setCanceledOnTouchOutside(true);

                LinearLayout ll_camera = dialog.findViewById(R.id.ll_camera);
                LinearLayout ll_gallery = dialog.findViewById(R.id.ll_gallery);

                ll_camera.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent openCamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(openCamera, 1);
                    }
                });

                ll_gallery.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent openGallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        startActivityForResult(openGallery, 2);
                    }
                });

                Window window = dialog.getWindow();
                window.setGravity(Gravity.CENTER);
                dialog.show();

            }
        });

        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                strName = editxt_name.getText().toString();
                strSurename = editxt_surename.getText().toString();
                strPhone = editxt_phone_number.getText().toString().trim();
                strEmail = editxt_email.getText().toString();

                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

                if (imagePath == null) {
                    Toast.makeText(requireActivity(), "Please,Select Image", Toast.LENGTH_SHORT).show();
                } else if (strName.equalsIgnoreCase("")) {
                    editxt_name.setError("Field can't be empty");
                } else if (strSurename.equalsIgnoreCase("")) {
                    editxt_surename.setError("Field can't be empty");
                } else if (strPhone.equalsIgnoreCase("")) {
                    editxt_phone_number.setError("Field can't be empty");
                } else if (strPhone.length() != 10) {
                    editxt_phone_number.setError("Enter 10 digit Mobile Number");
                } else if (strEmail.equalsIgnoreCase("")) {
                    editxt_email.setError("Field can't be empty");
                } else if (!strEmail.matches(emailPattern)) {
                    editxt_email.setError("Enter correct Email Format");
                } else {

                    viewModel = ViewModelProviders.of(requireActivity()).get(ViewModelClass.class);

                    if (imagePath != null) {
                        File file = new File(imagePath);
                        final RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);
                        rb_image = MultipartBody.Part.createFormData("AmbulanceDriverimage", file.getName(), requestFile);
                    }

                    rb_hospitalId = RequestBody.create(MediaType.parse("text/plain"), strHospitalID);
                    rb_name = RequestBody.create(MediaType.parse("text/plain"), strName);
                    rb_surename = RequestBody.create(MediaType.parse("text/plain"), strSurename);
                    rb_phone = RequestBody.create(MediaType.parse("text/plain"), strPhone);
                    rb_email = RequestBody.create(MediaType.parse("text/plain"), strEmail);
                    rb_driverId = RequestBody.create(MediaType.parse("text/plain"), strDriverId);


                    viewModel.liveDataUpdateProfileAmbulance(requireActivity(),rb_hospitalId,rb_name,rb_surename,rb_email,rb_phone,rb_image,rb_driverId).observe(requireActivity(), new Observer<UpdateProfileAmbulanceModel>() {
                        @Override
                        public void onChanged(UpdateProfileAmbulanceModel updateProfileAmbulanceModel) {
                            if (updateProfileAmbulanceModel.getSuccess().equalsIgnoreCase("1")) {
                                requireActivity().onBackPressed();
                                Toast.makeText(requireActivity(), updateProfileAmbulanceModel.getMessage(), Toast.LENGTH_SHORT).show();
                            } else {

                                Toast.makeText(requireActivity(), updateProfileAmbulanceModel.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });

                }


            }
        });

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && data != null) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            img_profile_pic.setImageBitmap(photo);

//            Uri uri = getImageUri(requireActivity(), photo);
            Uri uri = bitmapToUriConverter(photo);
            imagePath = getPathFromURI(uri);

            dialog.dismiss();

        } else if (requestCode == 2 && null != data) {
            Uri selected = data.getData();
            Glide.with(this).load(selected).into(img_profile_pic);

            imagePath = getPathFromURI(selected);

            dialog.dismiss();
        }
    }

    public Uri bitmapToUriConverter(Bitmap mBitmap) {
        Uri uri = null;
        try {
            final BitmapFactory.Options options = new BitmapFactory.Options();
            // Calculate inSampleSize
            options.inSampleSize = calculateInSampleSize(options, 100, 100);

            // Decode bitmap with inSampleSize set
            options.inJustDecodeBounds = false;
            Bitmap newBitmap = Bitmap.createScaledBitmap(mBitmap, 200, 200,
                    true);
            File file = new File(getActivity().getFilesDir(), "Image"
                    + new Random().nextInt() + ".jpeg");
            FileOutputStream out = getActivity().openFileOutput(file.getName(),
                    Context.MODE_WORLD_READABLE);
            newBitmap.compress(Bitmap.CompressFormat.JPEG, 100, out);
            out.flush();
            out.close();
            //get absolute path
            String realPath = file.getAbsolutePath();
            File f = new File(realPath);
            uri = Uri.fromFile(f);

        } catch (Exception e) {
            Log.e("Your Error Message", e.getMessage());
        }
        return uri;
    }

    public static int calculateInSampleSize(BitmapFactory.Options options, int reqWidth, int reqHeight) {
        final int height = options.outHeight;
        final int width = options.outWidth;
        int inSampleSize = 1;

        if (height > reqHeight || width > reqWidth) {

            final int halfHeight = height / 2;
            final int halfWidth = width / 2;

            while ((halfHeight / inSampleSize) >= reqHeight
                    && (halfWidth / inSampleSize) >= reqWidth) {
                inSampleSize *= 2;
            }
        }

        return inSampleSize;
    }

    private String getPathFromURI(Uri selected) {

        String path;
        Cursor cursor = requireActivity().getContentResolver().query(selected, null, null, null, null);
        if (cursor == null)
            path = selected.getPath();
        else {
            cursor.moveToFirst();
            int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            path = cursor.getString(index);
        }
        if (cursor != null) {
            cursor.close();
        }
        return path;
    }

    private void findID() {

        img_arrow = view.findViewById(R.id.img_arrow);
        img_profile_pic = view.findViewById(R.id.img_profile_pic);
        img_add = view.findViewById(R.id.img_add);

        editxt_name = view.findViewById(R.id.editxt_name);
        editxt_surename = view.findViewById(R.id.editxt_surename);
        editxt_phone_number = view.findViewById(R.id.editxt_phone_number);
        editxt_email = view.findViewById(R.id.editxt_email);

        btn_save = view.findViewById(R.id.btn_save);

    }
}