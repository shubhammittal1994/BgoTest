package com.expert.healthkangaroodriver.ambulance_driver;

import static com.expert.healthkangaroodriver.ambulance_driver.HomeAmbulanceDriverFragment.type;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.ambulance_model.NearByFireStationHeadQuarterModel;
import com.expert.healthkangaroodriver.Model.ambulance_model.NearByFireStationHeadQuaterListModel;
import com.expert.healthkangaroodriver.Model.ambulance_model.NearByHospitalListModel;
import com.expert.healthkangaroodriver.Model.ambulance_model.NearByPoliceStationListModel;
import com.expert.healthkangaroodriver.Model.ambulance_model.NearByPoliceStationModel;
import com.expert.healthkangaroodriver.adapter_class.ambulance_adapter.NearByHospitalAdaper;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;
import com.github.dhaval2404.imagepicker.ImagePicker;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class UploadPatienceDetailsAmbulanceDriverFragment extends Fragment {

    private View view;
    private ImageView img_arrow, patience_image;
    private EditText editxt_details;
    private TextView textAddressFireStation, textDistanceFireStation, textAddressPoliceStation, textDistancePoliceStation;
    private Button Send_button;
    private RadioButton radio_button_Hospital;
    private RecyclerView recycler_view_near_by_hospital_list;
    private int hosCount = 0, policeCount = 0, fireCount = 0;
    private ImageView img_patience, add_image_patience;
    private String imagePath, strDriverId, strHospitalID, myLat, myLog;
    private ViewModelClass viewModel;
    private List<NearByHospitalListModel.Detail> hospitalList = new ArrayList<>();
    private final List<NearByPoliceStationListModel.Detail> policeHQList = new ArrayList<>();
    private final List<NearByFireStationHeadQuaterListModel.Detail> fireHQList = new ArrayList<>();
    private String userImage,  hospitalLat, hospitalLog, hospitalImage, hospitalName, hospitalAddress,
            hospitalMobile, policeSHQId, fireSHQId, patient_address, case_type;
    private RequestBody rb_userImage, rb_driverId, rb_username, rb_phone, rb_relation,
            rb_hospitalId, rb_patientDetails, rb_selectedHospitalId, rb_policeStationId, rb_fireStaionId,
            rb_userId, rb_patient_address, rb_case_type;
    private MultipartBody.Part rb_image;
    private CheckBox check_button_fire_station, check_button_police_station;
    public NearByPoliceStationModel near_police;
    private NearByFireStationHeadQuarterModel near_fire;
    private ProgressDialog dialog;
    String patientAddress,orderId;
    private String patient_lat, patient_long, driverLat, driverLong;

    public static String selectedHospitalId;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_upload_patience_details_ambulance_driver, container, false);

        strDriverId = App.getSharedPref().getStringValue("DriverId");

        strHospitalID = App.getSharedPref().getStringValue("HospitalId");


        Bundle bundle = this.getArguments();

        if (bundle != null) {

            patient_lat = bundle.getString("MyLat");
            patient_long = bundle.getString("MyLog");
            driverLat = bundle.getString("driverLat");
            driverLong = bundle.getString("driverLong");

        }

        myLat = String.valueOf(App.getSingleton().getLat());
        myLog = String.valueOf(App.getSingleton().getLog());

        patientAddress = App.getSharedPref().getStringValue("PatienceAddress");

        viewModel = new ViewModelClass();
        dialog = new ProgressDialog(requireActivity());
        dialog.setMessage("Case Sending Please Wait.....");
        dialog.setCancelable(false);

        findID();

        getFireList();
        getPoliceList();

        Glide.with(getContext()).load(App.getSharedPref().getStringValue("PatienceImage")).into(patience_image);
        onRadioButtonClicked();
        onClick();

        return view;
    }

    private void getPoliceList() {

        viewModel.nearByPoliceStationModelLiveData(requireActivity(), myLat, myLog).observe(requireActivity(), new Observer<NearByPoliceStationModel>() {
            @Override
            public void onChanged(NearByPoliceStationModel nearByPoliceStationModel) {
                if (nearByPoliceStationModel.getSuccess().equalsIgnoreCase("1")) {

                    near_police = nearByPoliceStationModel;

                    textAddressPoliceStation.setText(nearByPoliceStationModel.getAddress());

                    textDistancePoliceStation.setText(nearByPoliceStationModel.getDistance());

                    patient_address = App.getSharedPref().getStringValue("PatienceAddress");

                } else {

                    Toast.makeText(requireActivity(), nearByPoliceStationModel.getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void getFireList() {

        viewModel.nearByFireStationHeadQuarterModelLiveData(requireActivity(), myLat, myLog).observe(requireActivity(), new Observer<NearByFireStationHeadQuarterModel>() {
            @Override
            public void onChanged(NearByFireStationHeadQuarterModel nearByFireStationHeadQuarterModel) {

                if (nearByFireStationHeadQuarterModel.getSuccess().equalsIgnoreCase("1")) {

                    near_fire = nearByFireStationHeadQuarterModel;

                    textDistanceFireStation.setText(nearByFireStationHeadQuarterModel.getDistance());
                    textAddressFireStation.setText(nearByFireStationHeadQuarterModel.getAddress());
                    patient_address = App.getSharedPref().getStringValue("PatienceAddress");


                    Toast.makeText(requireActivity(), "" + nearByFireStationHeadQuarterModel.getMessage(), Toast.LENGTH_SHORT).show();
                } else {

                    Toast.makeText(requireActivity(), nearByFireStationHeadQuarterModel.getMessage(), Toast.LENGTH_LONG).show();

                }
            }
        });

    }

    private void onRadioButtonClicked() {

        radio_button_Hospital.setOnClickListener(v -> {
            hosCount++;
            if (hosCount % 2 != 0) {
                recycler_view_near_by_hospital_list.setVisibility(View.VISIBLE);

                viewModel.liveDataNearByHospitalList(requireActivity(), myLat, myLog).observe(requireActivity(), nearByHospitalListModel -> {
                    if (nearByHospitalListModel.getSuccess().equalsIgnoreCase("1")) {
                        hospitalList = nearByHospitalListModel.getDetails();

                        NearByHospitalAdaper nearByHospitalAdaper = new NearByHospitalAdaper(requireActivity(), hospitalList, new NearByHospitalAdaper.HospitalSelect() {
                            @Override
                            public void selectedHospital(String hosId, String latitude,
                                                         String longitude, String hosImage,
                                                         String hosName, String hosMobile,
                                                         String hosAddress) {

                                selectedHospitalId = hosId;
                                hospitalLat = latitude;
                                hospitalLog = longitude;
                                hospitalImage = hosImage;
                                hospitalName = hosName;
                                hospitalAddress = hosAddress;
                                hospitalMobile = hosMobile;
                            }
                        });
                        recycler_view_near_by_hospital_list.setAdapter(nearByHospitalAdaper);

                        Toast.makeText(requireActivity(), nearByHospitalListModel.getMessage(), Toast.LENGTH_SHORT).show();

                    } else {

                        Toast.makeText(requireActivity(), nearByHospitalListModel.getMessage(), Toast.LENGTH_SHORT).show();

                    }
                });


            } else {

                recycler_view_near_by_hospital_list.setVisibility(View.GONE);

                radio_button_Hospital.setChecked(false);
            }
        });


    }

    private void onClick() {

        img_arrow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requireActivity().onBackPressed();
            }
        });

        add_image_patience.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ImagePicker.Companion.with(UploadPatienceDetailsAmbulanceDriverFragment.this).cameraOnly().compress(1024).start();
            }
        });

        Send_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                sendNewCase(v);

            }
        });

    }

    private void sendNewCase(View v) {

        if (check_button_fire_station.isChecked()) {

            fireSHQId = near_fire.getId();

        } else {

            fireSHQId = "";

        }

        if (check_button_police_station.isChecked()) {

            policeSHQId = near_police.getId();

        } else {

            policeSHQId = "";

        }

        String strDetails = editxt_details.getText().toString();

        strDriverId = App.getSharedPref().getStringValue("DriverId");

        strHospitalID = App.getSharedPref().getStringValue("HospitalId");

        if (imagePath == null) {

            Toast.makeText(requireActivity(), "Please,Take Picture Of Patient.", Toast.LENGTH_SHORT).show();

        }

        if (selectedHospitalId == null) {

            Toast.makeText(requireActivity(), "Please,Select Hospital", Toast.LENGTH_SHORT).show();

        } else {

            if (type.equalsIgnoreCase("Medical Emergency")) {
                rb_case_type = RequestBody.create(MediaType.parse("text/plain"), "0");

            } else if (type.equalsIgnoreCase("Accidental Emergency")) {

                rb_case_type = RequestBody.create(MediaType.parse("text/plain"), "1");

            }

            rb_driverId = RequestBody.create(MediaType.parse("text/plain"), strDriverId);
            rb_hospitalId = RequestBody.create(MediaType.parse("text/plain"), strHospitalID);
            rb_policeStationId = RequestBody.create(MediaType.parse("text/plain"), policeSHQId);
            rb_fireStaionId = RequestBody.create(MediaType.parse("text/plain"), fireSHQId);
            rb_patientDetails = RequestBody.create(MediaType.parse("text/plain"), strDetails);
            rb_selectedHospitalId = RequestBody.create(MediaType.parse("text/plain"), selectedHospitalId);
            rb_patient_address = RequestBody.create(MediaType.parse("text/plain"), App.getSharedPref().getStringValue("userID"));
            rb_userId = RequestBody.create(MediaType.parse("text/plain"), patientAddress);

            rb_username = RequestBody.create(MediaType.parse("text/plain"), App.getSharedPref().getStringValue("PatienceName"));
            rb_phone = RequestBody.create(MediaType.parse("text/plain"), App.getSharedPref().getStringValue("PatienceMobile"));
            rb_relation = RequestBody.create(MediaType.parse("text/plain"), App.getSharedPref().getStringValue("RelationWithPatience"));

            userImage = App.getSharedPref().getStringValue("PatienceImage");


            if (imagePath != null) {

                File file = new File(imagePath);

                final RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);

                rb_image = MultipartBody.Part.createFormData("image", file.getName(), requestFile);
            }

            rb_userImage = RequestBody.create(MediaType.parse("text/plain"), userImage);

            dialog.show();
            viewModel.liveDataPatientDetailsAmbulanceDriver(requireActivity(), rb_driverId
                            , rb_hospitalId, rb_username, rb_phone, rb_relation, rb_policeStationId, rb_fireStaionId,
                            rb_patientDetails, rb_selectedHospitalId, rb_patient_address,rb_userId,
                            rb_case_type, rb_image, rb_userImage)
                    .observe(requireActivity(), patientDetailsAmbulanceDriverModel -> {
                        dialog.dismiss();

                        if (patientDetailsAmbulanceDriverModel.getSuccess().equalsIgnoreCase("1")) {


                            orderId = patientDetailsAmbulanceDriverModel.getDetails().getPatientNo();

                            Bundle bundle = new Bundle();
                            bundle.putString("PatienceLatitude", myLat);//it's PatienceLatitude
                            bundle.putString("PatienceLongitude", myLog);//it's PatienceLongitude
                            bundle.putString("HospitalLatitude", hospitalLat);//it's new Hospital latitude
                            bundle.putString("HospitalLongitude", hospitalLog);//it's new hospital longitude
                            bundle.putString("HospitalImage", hospitalImage);//it's new hospital longitude
                            bundle.putString("HospitalName", hospitalName);//it's new hospital longitude
                            bundle.putString("HospitalAddress", hospitalAddress);//it's new hospital longitude
                            bundle.putString("HospitalPhone", hospitalMobile);//it's new hospital longitude
                            bundle.putString("Page", "second");
                            bundle.putString("status", "1");
                            bundle.putString("status", "2");
                            bundle.putString("MyLat", patient_lat);
                            bundle.putString("MyLog", patient_long);
                            bundle.putString("driverLat", driverLat);
                            bundle.putString("driverLong", driverLong);
                            bundle.putString("driverLong", driverLong);
                            bundle.putString("orderId", orderId);

                            try {
                                uploadDataNew(driverLat, driverLong, orderId, patient_lat, patient_long, hospitalName);
                            } catch (IOException e) {
                                e.printStackTrace();
                            }


                            Navigation.findNavController(v).navigate(R.id.action_uploadPatienceDetailsAmbulanceDriverFragment_to_startAmbulanceDriverFragment, bundle);
                        } else {

                            Toast.makeText(requireActivity(), patientDetailsAmbulanceDriverModel.getMessage(), Toast.LENGTH_SHORT).show();
                        }

                    });
        }

    }

    private void uploadDataNew(String driverLat, String driverLong, String orderId, String patient_lat, String patient_long, String hospitalName) throws IOException {


        Geocoder geocoder;
        List<Address> addresses;
        List<Address> addressList;
        geocoder = new Geocoder(requireActivity(), Locale.getDefault());

        addresses = geocoder.getFromLocation(Double.parseDouble(driverLat), Double.parseDouble(driverLong), 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
        addressList = geocoder.getFromLocation(Double.parseDouble(patient_lat), Double.parseDouble(patient_long), 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5

        String address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
        String patient_address = addressList.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("TrackPharmacyDriver");

        Map map = new HashMap();
        map.put("appointmentNo", orderId);
        map.put("liveLocation", address);
        map.put("patientAddress", patient_address);
        map.put("vendorName", hospitalName);
        reference.child(orderId).setValue(map);


    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ImagePicker.REQUEST_CODE && resultCode == Activity.RESULT_OK) {

            img_patience.setImageURI(data.getData());

            imagePath = data.getData().getPath();

        }
    }

    private void findID() {

        img_arrow = view.findViewById(R.id.img_arrow);
        patience_image = view.findViewById(R.id.img_patience_user);

        img_patience = view.findViewById(R.id.img_patience);
        add_image_patience = view.findViewById(R.id.add_image_patience);

        radio_button_Hospital = view.findViewById(R.id.radio_button_Hospital);

        recycler_view_near_by_hospital_list = view.findViewById(R.id.recycler_view_near_by_hospital_list);

        editxt_details = view.findViewById(R.id.editxt_details);
        Send_button = view.findViewById(R.id.Send_button);

        textAddressFireStation = view.findViewById(R.id.txt_address_fire_station);
        textDistanceFireStation = view.findViewById(R.id.txt_distance_fire);

        textDistancePoliceStation = view.findViewById(R.id.txt_distance_police);
        textAddressPoliceStation = view.findViewById(R.id.txt_address_police);

        check_button_fire_station = view.findViewById(R.id.check_button_fire_station);
        check_button_police_station = view.findViewById(R.id.check_button_police_station);
    }

}