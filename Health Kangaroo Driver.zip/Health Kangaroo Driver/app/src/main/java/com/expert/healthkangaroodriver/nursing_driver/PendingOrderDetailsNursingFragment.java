package com.expert.healthkangaroodriver.nursing_driver;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.healthkangaroo.R;

public class PendingOrderDetailsNursingFragment extends Fragment {

    private View view;
    private ImageView back, patience_profile_image;
    private TextView txt_patience_name, txt_appointment_number, txt_patience_phone, txt_patience_age, txt_patience_gender, txt_patience_dob, txt_patience_appointment_date, txt_patience_language_spoken, txt_patience_address;
    private Bundle bundle;
    private String  str_patience_profile_image, str_patience_name, str_appointment_number, str_patience_phone, str_patience_age, str_patience_gender, str_patience_dob, str_patience_appointment_date, str_patience_language_spoken, str_patience_address;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_nursing_details_order_pending, container, false);
        FindId();
        bundle = this.getArguments();
        str_patience_profile_image = bundle.getString("Patience Pic");
        str_patience_name = bundle.getString("Patience Name");
        str_appointment_number = bundle.getString("Appointment id");
        str_patience_phone = bundle.getString("Patience Phone");
        str_patience_age = bundle.getString("Patience Age");
        str_patience_gender = bundle.getString("Patience Gender");
        str_patience_dob = bundle.getString("Patience DOB");
        str_patience_appointment_date = bundle.getString("Patience Appointment Date");
        str_patience_language_spoken = bundle.getString("Patience Language Spoken");
        str_patience_address = bundle.getString("Patience Address");


        setData();
        onClick();


        return view;
    }

    private void setData() {

        Glide.with(view).load(str_patience_profile_image).into(patience_profile_image);

        txt_patience_name.setText(str_patience_name);
        txt_appointment_number.setText(str_appointment_number);
        txt_patience_phone.setText(str_patience_phone);
        txt_patience_age.setText(str_patience_age);
        txt_patience_gender.setText(str_patience_gender);
        txt_patience_dob.setText(str_patience_dob);
        txt_patience_appointment_date.setText(str_patience_appointment_date);
        txt_patience_language_spoken.setText(str_patience_language_spoken);
        txt_patience_address.setText(str_patience_address);

    }

    private void onClick() {

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });

    }
    private void FindId() {
        back = view.findViewById(R.id.back_image);
        patience_profile_image = view.findViewById(R.id.patience_profile_image);

        txt_appointment_number = view.findViewById(R.id.txt_appointment_number);
        txt_patience_name = view.findViewById(R.id.txt_patience_name);
        txt_patience_phone = view.findViewById(R.id.txt_patience_phone);
        txt_patience_age = view.findViewById(R.id.txt_patience_age);
        txt_patience_gender = view.findViewById(R.id.txt_patience_gender);
        txt_patience_dob = view.findViewById(R.id.txt_patience_dob);
        txt_patience_appointment_date = view.findViewById(R.id.txt_patience_appointment_date);
        txt_patience_language_spoken = view.findViewById(R.id.txt_patience_language_spoken);
        txt_patience_address = view.findViewById(R.id.txt_patience_address);
    }
}