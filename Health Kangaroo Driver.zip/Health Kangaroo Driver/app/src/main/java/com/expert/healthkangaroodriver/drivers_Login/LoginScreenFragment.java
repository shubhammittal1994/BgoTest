package com.expert.healthkangaroodriver.drivers_Login;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;

import android.os.Looper;
import android.provider.Settings;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.login_screen_model.ModelLogin;
import com.expert.healthkangaroodriver.Model.driver_forgot_password.ForgotPassword;
import com.expert.healthkangaroodriver.Model.driver_forgot_password.OtpSend;
import com.expert.healthkangaroodriver.Model.driver_forgot_password.VerifyUserModel;
import com.expert.healthkangaroodriver.Model.login_screen_model.SpinnerLoginModel;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.URLBuilder;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;
import com.expert.healthkangaroodriver.ambulance_driver.AmbulanceDriverActivity;
import com.expert.healthkangaroodriver.nursing_driver.NursingDriverActivity;
import com.expert.healthkangaroodriver.pharmacy_driver.PharmacyDriverActivity;
import com.expert.healthkangaroodriver.phlebotomist_driver.PhlebotomistDriverActivity;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.gson.Gson;

import in.aabhasjindal.otptextview.OtpTextView;


public class LoginScreenFragment extends Fragment {
    private View view;
    private EditText email_edit_text, password_edit_text;
    private AppCompatButton btn_login_driver;
    private int num_password = 2;
    private ImageView eye_image_password;
    private TextView forgot_password;
    private Spinner spinner;
    String RadioText;
    int num_Password = 0, numPasswordTwo = 0;
    private String userEmail, userId, userPhone;
    ArrayAdapter adapter, adaptertWO;
    private ViewModelClass viewModel;
    private String spinnerData = null, spinnerTypeId;
    private String spinnerDataTwo = null, spinnerTypeIdTwo;
    private ProgressDialog progressDialog;
    private double lat = 0.00, log = 0.00;
    String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
    FusedLocationProviderClient fusedLocationProviderClient;
    Location location;
    LocationManager locationManager;
    FirebaseDatabase database;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_login_screen, container, false);
//        database=FirebaseDatabase.getInstance("https://healthkangaroouser-default-rtdb.firebaseio.com/");



        viewModel = new ViewModelClass();
        progressDialog = new ProgressDialog(requireActivity());
        progressDialog.setMessage("Loading.....");

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(requireContext());
        locationManager = (LocationManager) requireActivity().getSystemService(Context.LOCATION_SERVICE);


        FindId();
        setSpinnerData();
        OnClicks();
        showHidePassword();


        return view;
    }


    private void setSpinnerData() {
        progressDialog.show();

        viewModel.liveDataDriverType(requireActivity()).observe(requireActivity(), spinnerLoginModel -> {
            if (spinnerLoginModel.getDetails() != null) {

                adapter = new ArrayAdapter<String>(requireActivity(), android.R.layout.simple_spinner_dropdown_item);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                for (int i = 0; i < spinnerLoginModel.getDetails().size(); i++) {
                    adapter.add(spinnerLoginModel.getDetails().get(i).getDrivers());
                }

                spinner.setAdapter(adapter);
                progressDialog.dismiss();

            } else {
                Toast.makeText(requireActivity(), spinnerLoginModel.getMessage(), Toast.LENGTH_SHORT).show();
            }


            spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                @Override
                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    int spinnerIndex = spinner.getSelectedItemPosition();

                    spinnerData = spinnerLoginModel.getDetails().get(spinnerIndex).getDrivers();
                    spinnerTypeId = spinnerLoginModel.getDetails().get(spinnerIndex).getId();
                    App.sharedPref.saveString("TypeId", spinnerTypeId);
                    if (spinnerIndex == 0) {
                        spinnerData = null;
                    }

                }

                @Override
                public void onNothingSelected(AdapterView<?> parent) {
                }
            });

        });


    }

    private void showHidePassword() {
        eye_image_password.setOnClickListener(v -> {
            if (num_password % 2 == 0) {
                password_edit_text.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                eye_image_password.setImageResource(R.drawable.invisible);
            } else {
                password_edit_text.setTransformationMethod(PasswordTransformationMethod.getInstance());
                eye_image_password.setImageResource(R.drawable.ic_baseline_remove_red_eye_24);
            }
            num_password++;
        });

    }

    private void FindId() {

        spinner = view.findViewById(R.id.spinner);

        eye_image_password = view.findViewById(R.id.img_eye);
        email_edit_text = view.findViewById(R.id.edtx_email_login);
        password_edit_text = view.findViewById(R.id.editext_password_hv);

        btn_login_driver = view.findViewById(R.id.btn_login_driver);
        forgot_password = view.findViewById(R.id.forgot_password);
    }

    private void OnClicks() {

        btn_login_driver.setOnClickListener(v -> {
            progressDialog.show();

            String strEmail = email_edit_text.getText().toString();
            String strPassword = password_edit_text.getText().toString();

            if (spinnerData == null) {
                progressDialog.dismiss();
                Toast.makeText(requireActivity(), "Please, Select Login As ", Toast.LENGTH_SHORT).show();
            } else if (strEmail.equalsIgnoreCase("")) {
                progressDialog.dismiss();
                Toast.makeText(requireActivity(), "Please Enter Driver User Name", Toast.LENGTH_SHORT).show();
            } else if (strPassword.equalsIgnoreCase("")) {
                progressDialog.dismiss();
                Toast.makeText(requireActivity(), "Please Enter Password", Toast.LENGTH_SHORT).show();
            } else {


                viewModel.liveDataLogin(requireActivity(), strEmail, strPassword, spinnerTypeId,
                        FirebaseInstanceId.getInstance().getToken(),
                        "Android", String.valueOf(App.getSingleton().getLat()),
                        String.valueOf(App.getSingleton().getLog())).observe(requireActivity(), new Observer<ModelLogin>() {
                    @Override
                    public void onChanged(ModelLogin modelLogin) {
                        progressDialog.dismiss();

                        App.getSharedPref().saveString("DriverType", modelLogin.getSuccess());


                        if (modelLogin.getSuccess().equalsIgnoreCase("2")) {
                            App.getSharedPref().saveString("DriverId", modelLogin.getDetails().getId());
                            App.getSharedPref().saveString("VenderId", modelLogin.getDetails().getVendorId());

                            App.getSharedPref().saveString("Image", modelLogin.getDetails().getImage());
                            App.getSharedPref().saveString("Name", modelLogin.getDetails().getName());
                            App.getSharedPref().saveString("Username", modelLogin.getDetails().getUsername());
                            App.getSharedPref().saveString("Phone", modelLogin.getDetails().getPhone());
                            App.getSharedPref().saveString("Email", modelLogin.getDetails().getEmail());
                            App.getSharedPref().saveString("Address", modelLogin.getDetails().getAddress());


                            App.getSingleton().setImage(modelLogin.getDetails().getImage());
                            App.getSingleton().setName(modelLogin.getDetails().getName());
                            App.getSingleton().setUsername(modelLogin.getDetails().getUsername());
                            App.getSingleton().setPhone(modelLogin.getDetails().getPhone());
                            App.getSingleton().setEmail(modelLogin.getDetails().getEmail());
                            App.getSingleton().setAddress(modelLogin.getDetails().getAddress());


                            Intent intent = new Intent(requireActivity(), PhlebotomistDriverActivity.class);
                            requireActivity().startActivity(intent);
                            requireActivity().finishAffinity();

                            Toast.makeText(requireActivity(), modelLogin.getSuccess(), Toast.LENGTH_SHORT).show();

                        } else if (modelLogin.getSuccess().equalsIgnoreCase("3")) {

                            App.getSharedPref().saveString("DriverId", modelLogin.getDetails().getId());
                            App.getSharedPref().saveString("VenderId", modelLogin.getDetails().getVendorId());
                            App.getSharedPref().saveString("vendor_name", modelLogin.getDetails().getVendor_name());
                            App.getSharedPref().saveString("Image", modelLogin.getDetails().getImage());
                            App.getSharedPref().saveString("Name", modelLogin.getDetails().getName());
                            App.getSharedPref().saveString("Username", modelLogin.getDetails().getUsername());
                            App.getSharedPref().saveString("Phone", modelLogin.getDetails().getPhone());
                            App.getSharedPref().saveString("Email", modelLogin.getDetails().getEmail());
                            App.getSharedPref().saveString("Address", modelLogin.getDetails().getAddress());


                            Intent intent = new Intent(requireActivity(), NursingDriverActivity.class);
                            requireActivity().startActivity(intent);
                            requireActivity().finishAffinity();

                            Toast.makeText(requireActivity(), modelLogin.getSuccess(), Toast.LENGTH_SHORT).show();


                        } else if (modelLogin.getSuccess().equalsIgnoreCase("4")) {

                            App.getSharedPref().saveString("DriverId", modelLogin.getDetails().getId());
                            App.getSharedPref().saveString("VenderId", modelLogin.getDetails().getVendor_id());
                            App.getSharedPref().saveString("vendor_name", modelLogin.getDetails().getVendor_name());

                            App.getSharedPref().saveString("Image", modelLogin.getDetails().getImage());
                            App.getSharedPref().saveString("Name", modelLogin.getDetails().getName());
                            App.getSharedPref().saveString("Username", modelLogin.getDetails().getUsername());
                            App.getSharedPref().saveString("Phone", modelLogin.getDetails().getPhone());
                            App.getSharedPref().saveString("Email", modelLogin.getDetails().getEmail());
                            App.getSharedPref().saveString("Address", modelLogin.getDetails().getAddress());
                            App.getSharedPref().saveString("Vehicle", modelLogin.getDetails().getVehicle());

                            App.getSingleton().setImage(modelLogin.getDetails().getImage());
                            App.getSingleton().setName(modelLogin.getDetails().getName());
                            App.getSingleton().setUsername(modelLogin.getDetails().getUsername());
                            App.getSingleton().setPhone(modelLogin.getDetails().getPhone());
                            App.getSingleton().setEmail(modelLogin.getDetails().getEmail());
                            App.getSingleton().setAddress(modelLogin.getDetails().getAddress());
                            App.getSingleton().setVehicle(modelLogin.getDetails().getVehicle());
                            App.getSingleton().setVehicle(modelLogin.getDetails().getVendor_id());
                            App.getSingleton().setVehicle(modelLogin.getDetails().getVendor_name());


                            Intent intent = new Intent(requireActivity(), PharmacyDriverActivity.class);
                            requireActivity().startActivity(intent);
                            requireActivity().finishAffinity();

                            Toast.makeText(requireActivity(), modelLogin.getSuccess(), Toast.LENGTH_SHORT).show();

                        } else if (modelLogin.getSuccess().equalsIgnoreCase("5")) {

                            SharedPreferences sharedPreferences= requireActivity().getSharedPreferences(URLBuilder.SharedPreferencesKeyName.SharedPreferencesName, Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor=sharedPreferences.edit();
                            Gson gson = new Gson();
                            String json = gson.toJson(modelLogin);
                            editor.putString(URLBuilder.SharedPreferencesKeyName.SharedPreferencesKey,json);
                            editor.apply();

                            App.getSharedPref().saveString("DriverId", modelLogin.getDetails().getId());
                            App.getSharedPref().saveString("HospitalId", modelLogin.getDetails().getHospital_id());


                            App.getSharedPref().saveString("Image", modelLogin.getDetails().getAmbulance_photo());
                            App.getSharedPref().saveString("Name", modelLogin.getDetails().getDriver_name());
                            App.getSharedPref().saveString("Username", modelLogin.getDetails().getDriver_id());
                            App.getSharedPref().saveString("Phone", modelLogin.getDetails().getOfficial_number());
                            App.getSharedPref().saveString("Email", modelLogin.getDetails().getEmail());
                            App.getSharedPref().saveString("Address", modelLogin.getDetails().getAddress());
                            App.getSharedPref().saveString("Vehicle", modelLogin.getDetails().getAmbulance_type());
                            App.getSharedPref().saveString("Age", modelLogin.getDetails().getDob());

                            App.getSharedPref().saveString("hos_lat", modelLogin.getDetails().getHos_lat());
                            App.getSharedPref().saveString("hos_long", modelLogin.getDetails().getHos_long());



                            App.getSharedPref().saveString("Login-Details", String.valueOf(modelLogin.getDetails()));


                            App.getSingleton().setImage(modelLogin.getDetails().getImage());
                            App.getSingleton().setName(modelLogin.getDetails().getDriver_name());
                            App.getSingleton().setUsername(modelLogin.getDetails().getDriver_id());
                            App.getSingleton().setPhone(modelLogin.getDetails().getOfficial_number());
                            App.getSingleton().setEmail(modelLogin.getDetails().getEmail());
                            App.getSingleton().setAddress(modelLogin.getDetails().getAddress());
                            App.getSingleton().setVehicle(modelLogin.getDetails().getVehicle());
                            App.getSingleton().setAge(modelLogin.getDetails().getDob());


                            Intent intent = new Intent(requireActivity(), AmbulanceDriverActivity.class);
                            requireActivity().startActivity(intent);
                            requireActivity().finishAffinity();

                            Toast.makeText(requireActivity(), modelLogin.getMessage(), Toast.LENGTH_SHORT).show();

                        } else {
                            Toast.makeText(requireActivity(), modelLogin.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }

                });
            }


        });

        forgot_password.setOnClickListener(v -> {
            getVerifyDialog(requireContext());
        });
    }

    private void getVerifyDialog(Context context) {
        Dialog dialog = new Dialog(context);
        dialog.setContentView(R.layout.layout_confirm_user);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        Spinner spinner2 = dialog.findViewById(R.id.verifySpinner);
        EditText edtUser = dialog.findViewById(R.id.editTextUSerName);
        Button button = dialog.findViewById(R.id.btnVerifyUserNAme);

        hitSpinerApi(spinner2);
        button.setOnClickListener(v -> {

            if (spinnerDataTwo == null) {
                Toast.makeText(requireContext(), "Choose LoginAs", Toast.LENGTH_SHORT).show();
            } else if (edtUser.getText().toString().isEmpty()) {
                Toast.makeText(requireActivity(), "Please Enter Driver ID", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(requireActivity(), "" + spinnerTypeIdTwo, Toast.LENGTH_SHORT).show();
                hitApi(edtUser.getText().toString(), spinnerTypeIdTwo);
                dialog.dismiss();
            }


        });
        dialog.show();
    }

    private void hitApi(String userName, String name) {

        viewModel.VerifyDriver(requireActivity(), userName, name).observe(requireActivity(), new Observer<VerifyUserModel>() {
            @Override
            public void onChanged(VerifyUserModel verifyUserModel) {

                if (verifyUserModel.getSuccess().equalsIgnoreCase("1")) {

                    Toast.makeText(requireContext(), "" + verifyUserModel.getMessage(), Toast.LENGTH_SHORT).show();
                    userEmail = verifyUserModel.getDetails().getEmail();
                    userId = verifyUserModel.getDetails().getId();
                    userPhone = verifyUserModel.getDetails().getPhone();

                    dialogChooseNumber();


                } else {
                    Toast.makeText(requireContext(), "" + verifyUserModel.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }

            private void dialogChooseNumber() {
                Dialog dialog = new Dialog(requireContext());
                dialog.setContentView(R.layout.layout_choose_option);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));


                RadioButton radioButton1 = dialog.findViewById(R.id.txtNumber);
                RadioButton radioButton2 = dialog.findViewById(R.id.txtEmail);
                RadioGroup radioGroup = dialog.findViewById(R.id.radioGroup);
                radioButton1.setText(userPhone);
                radioButton2.setText(userEmail);


                radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
                    RadioButton radioButton = (RadioButton) group.findViewById(checkedId);
                    RadioText = radioButton.getText().toString();
                });

                dialog.findViewById(R.id.btnGetOtp).setOnClickListener(v -> {


                    hitApiSendOtp(RadioText, spinnerTypeIdTwo);
                    dialog.dismiss();
                });

                dialog.show();

            }


        });
    }

    private void hitApiSendOtp(String radioText, String toString) {
        viewModel.OtpSend(requireActivity(), toString, radioText).observe(requireActivity(), new Observer<OtpSend>() {
            @Override
            public void onChanged(OtpSend otpSend) {
                if (otpSend.getSuccess().equalsIgnoreCase("1")) {

                    Toast.makeText(requireContext(), "" + otpSend.getMessage(), Toast.LENGTH_SHORT).show();
                    Toast.makeText(requireContext(), "" + otpSend.getOtp(), Toast.LENGTH_SHORT).show();

                    dialogBoxOtp(otpSend.getOtp(), radioText);

//


                } else {
                    Toast.makeText(requireContext(), "" + otpSend.getMessage(), Toast.LENGTH_SHORT).show();

                }
            }
        });


    }

    private void dialogBoxOtp(String otpSendOtp, String otp) {
        Dialog dialog = new Dialog(requireContext());
        dialog.setContentView(R.layout.layout_otp_phlebotomist);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        Button submitOtp = dialog.findViewById(R.id.btn_submit_otp);
        TextView textView = dialog.findViewById(R.id.txt_email_ll);
        OtpTextView otpTextView = dialog.findViewById(R.id.otp_view);
        textView.setText(otp);
        submitOtp.setOnClickListener(v -> {
            Toast.makeText(requireContext(), "" + otpTextView.getOTP(), Toast.LENGTH_SHORT).show();
            if (otpTextView.getOTP().isEmpty()) {
                Toast.makeText(requireContext(), "Can't Empty", Toast.LENGTH_SHORT).show();
            }
            if (otpSendOtp.equalsIgnoreCase(otpTextView.getOTP())) {
                Toast.makeText(requireContext(), "Otp Match", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
                dialogBoxForgetPassword();

            } else {
                Toast.makeText(requireContext(), "Otp Not Match", Toast.LENGTH_SHORT).show();

            }

        });
        dialog.show();


    }

    private void dialogBoxForgetPassword() {

        Dialog dialog = new Dialog(requireContext());
        dialog.setContentView(R.layout.layout_forgot_password);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));

        Button submit = dialog.findViewById(R.id.btn_submit_new_pass_dv);
        ImageView imgEynew = dialog.findViewById(R.id.ic_eye_id_dv);
        ImageView imgEyConferm = dialog.findViewById(R.id.ic_eye_confirm_id_dv);
        EditText edtPassword = dialog.findViewById(R.id.edt_password_forgot_pass_dv);
        EditText edtPasswordConfrm = dialog.findViewById(R.id.edt_confirm_password_forgot_pass_dv);
        imgEynew.setOnClickListener(v -> {
            if (num_Password % 2 == 0) {

                edtPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                imgEynew.setImageResource(R.drawable.ic_hide_password);

            } else {

                edtPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                imgEynew.setImageResource(R.drawable.ic_baseline_remove_red_eye_24);

            }
            num_Password++;


        });
        imgEyConferm.setOnClickListener(v -> {
            if (numPasswordTwo % 2 == 0) {

                edtPasswordConfrm.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                imgEyConferm.setImageResource(R.drawable.ic_hide_password);

            } else {

                edtPasswordConfrm.setTransformationMethod(PasswordTransformationMethod.getInstance());
                imgEyConferm.setImageResource(R.drawable.ic_baseline_remove_red_eye_24);

            }
            numPasswordTwo++;


        });

        submit.setOnClickListener(v -> {
            if (edtPassword.getText().toString().isEmpty()) {
                Toast.makeText(requireContext(), "Can't Empty", Toast.LENGTH_SHORT).show();

            } else if (edtPasswordConfrm.getText().toString().isEmpty()) {
                Toast.makeText(requireContext(), "Can't Empty", Toast.LENGTH_SHORT).show();

            } else if (!edtPassword.getText().toString().equalsIgnoreCase(edtPasswordConfrm.getText().toString())) {
                Toast.makeText(requireContext(), "Pass Word Miss Match", Toast.LENGTH_SHORT).show();

            } else {

                hitAPiForgetPassword(edtPassword.getText().toString(), spinnerTypeIdTwo, userId);
                dialog.dismiss();
            }


        });
        dialog.show();
    }

    private void hitAPiForgetPassword(String toString, String spinnerDataTwo, String userId) {

        viewModel.NewPassChange(requireActivity(), toString, spinnerDataTwo, userId).observe(requireActivity(), new Observer<ForgotPassword>() {
            @Override
            public void onChanged(ForgotPassword forgotPassword) {
                if (forgotPassword.getSuccess().equalsIgnoreCase("1")) {
                    Toast.makeText(requireActivity(), "" + forgotPassword.getMessage(), Toast.LENGTH_SHORT).show();

                } else {
                    Toast.makeText(requireActivity(), "" + forgotPassword.getMessage(), Toast.LENGTH_SHORT).show();

                }

            }
        });


    }

    private void getCurrentLocation() {


        if (ActivityCompat.checkSelfPermission(requireActivity(),
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireActivity(),
                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(requireActivity(), permissions, 10);
        }

        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {


            fusedLocationProviderClient.getLastLocation().addOnCompleteListener(new OnCompleteListener<Location>() {
                @Override
                public void onComplete(@NonNull Task<Location> task) {
                    location = task.getResult();

                    if (location != null) {
                        lat = location.getLatitude();

                        log = location.getLongitude();
                        App.getSingleton().setLat(lat);
                        App.getSingleton().setLog(log);


                    } else {

                        LocationRequest locationRequest = new LocationRequest().setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY).setInterval(1000).setFastestInterval(1000).setNumUpdates(1);

                        LocationCallback locationCallback = new LocationCallback() {
                            @Override
                            public void onLocationResult(@NonNull LocationResult locationResult) {
                                super.onLocationResult(locationResult);

                                Location location1 = locationResult.getLastLocation();
                                lat = location.getLatitude();

                                log = location.getLongitude();
                                App.getSingleton().setLat(lat);
                                App.getSingleton().setLog(log);
                            }
                        };

                        if (ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireActivity(),
                                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(requireActivity(), permissions, 10);

                        }
                        fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());

                    }


                }
            });


        } else {
//            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));

            new AlertDialog.Builder(requireContext())
                    .setMessage(R.string.gps_network_not_enabled).setIcon(R.drawable.location).setTitle(R.string.location_alert_dialog)
                    .setPositiveButton(R.string.open_location_settings, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface paramDialogInterface, int paramInt) {

                            requireContext().startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS));
                        }
                    }).setNegativeButton(R.string.Cancel, null)
                    .show();

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 10 && grantResults.length > 0) {
            getCurrentLocation();
        } else {
            Toast.makeText(getContext(), "Permission deny", Toast.LENGTH_SHORT).show();
        }
    }

    private void hitSpinerApi(Spinner spinner2) {

        viewModel.liveDataDriverType(requireActivity()).observe(requireActivity(), new Observer<SpinnerLoginModel>() {
            @Override
            public void onChanged(SpinnerLoginModel spinnerLoginModel) {
                if (spinnerLoginModel.getDetails() != null) {

                    adaptertWO = new ArrayAdapter<String>(requireActivity(), android.R.layout.simple_spinner_dropdown_item);
                    adaptertWO.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                    for (int i = 0; i < spinnerLoginModel.getDetails().size(); i++) {
                        adaptertWO.add(spinnerLoginModel.getDetails().get(i).getDrivers());
                    }


                    spinner2.setAdapter(adaptertWO);

                    progressDialog.dismiss();

                } else {
                    Toast.makeText(requireActivity(), spinnerLoginModel.getMessage(), Toast.LENGTH_SHORT).show();
                }


                spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        int spinnerIndex2 = spinner2.getSelectedItemPosition();
                        Toast.makeText(requireContext(), "" + spinnerIndex2, Toast.LENGTH_SHORT).show();
                        spinnerDataTwo = spinnerLoginModel.getDetails().get(spinnerIndex2).getDrivers();
                        spinnerTypeIdTwo = spinnerLoginModel.getDetails().get(spinnerIndex2).getId();

                        if (spinnerIndex2 == 0) {
                            spinnerDataTwo = null;
                        }

                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {
                    }
                });

            }
        });


    }

}