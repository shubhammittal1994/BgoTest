package com.expert.healthkangaroodriver.adapter_class.nursing_adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.expert.healthkangaroodriver.Model.nurse_model.GetNurseWithdrawlCreditHistoryModel;
import com.example.healthkangaroo.R;

import java.util.List;

public class HistoryDetailsNursingAdapter extends RecyclerView.Adapter<HistoryDetailsNursingAdapter.ViewHolder> {

    Context context;
    private List<GetNurseWithdrawlCreditHistoryModel.Detail> historyList;

    public HistoryDetailsNursingAdapter(Context context, List<GetNurseWithdrawlCreditHistoryModel.Detail> historyList) {
        this.context = context;
        this.historyList = historyList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_recycler_view_history_details, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.txt_title.setText(historyList.get(position).getTitle());
        holder.txt_transaction_id.setText(historyList.get(position).getTransactionId());
        holder.txt_date_and_time.setText(historyList.get(position).getDateTime());
        holder.txt_amount.setText(historyList.get(position).getAmount());

    }

    @Override
    public int getItemCount() {
        return historyList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt_date_and_time, txt_amount, txt_title, txt_transaction_id;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txt_title = itemView.findViewById(R.id.txt_title);
            txt_transaction_id = itemView.findViewById(R.id.txt_transaction_id);
            txt_date_and_time = itemView.findViewById(R.id.txt_date_and_time);
            txt_amount = itemView.findViewById(R.id.txt_amount);
        }
    }
}
