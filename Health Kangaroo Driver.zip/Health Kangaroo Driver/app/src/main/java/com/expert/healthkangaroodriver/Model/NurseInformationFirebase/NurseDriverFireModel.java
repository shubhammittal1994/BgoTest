package com.expert.healthkangaroodriver.Model.NurseInformationFirebase;

public class NurseDriverFireModel {

    String  appointmentNo, patientAddress;
    String liveLocation;
    String vendorName;
    String startOtp;
    String endOtp;
    String status;
    String startTime, endTime, difference;



    public NurseDriverFireModel() {
    }



    public NurseDriverFireModel(String appointmentNo, String patientAddress, String liveLocation, String vendorName, String startOtp, String endOtp, String status, String startTime, String endTime, String difference) {
        this.appointmentNo = appointmentNo;
        this.patientAddress = patientAddress;
        this.liveLocation = liveLocation;
        this.vendorName = vendorName;
        this.startOtp = startOtp;
        this.endOtp = endOtp;
        this.status = status;
        this.startTime = startTime;
        this.endTime = endTime;
        this.difference = difference;
    }

    public String getAppointmentNo() {
        return appointmentNo;
    }

    public void setAppointmentNo(String appointmentNo) {
        this.appointmentNo = appointmentNo;
    }

    public String getPatientAddress() {
        return patientAddress;
    }

    public void setPatientAddress(String patientAddress) {
        this.patientAddress = patientAddress;
    }

    public String getLiveLocation() {
        return liveLocation;
    }

    public void setLiveLocation(String liveLocation) {
        this.liveLocation = liveLocation;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }

    public String getStartOtp() {
        return startOtp;
    }

    public void setStartOtp(String startOtp) {
        this.startOtp = startOtp;
    }

    public String getEndOtp() {
        return endOtp;
    }

    public void setEndOtp(String endOtp) {
        this.endOtp = endOtp;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getStartTime() {
        return startTime;
    }

    public void setStartTime(String startTime) {
        this.startTime = startTime;
    }

    public String getEndTime() {
        return endTime;
    }

    public void setEndTime(String endTime) {
        this.endTime = endTime;
    }

    public String getDifference() {
        return difference;
    }

    public void setDifference(String difference) {
        this.difference = difference;
    }
}
