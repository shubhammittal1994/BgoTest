package com.expert.healthkangaroodriver.ambulance_driver;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.ImageView;

import com.example.healthkangaroo.R;

public class TermsAndConditionAmbulanceDriverFragment extends Fragment {
    private View view;
    private ImageView img_back;
    private WebView webView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        view = inflater.inflate(R.layout.fragment_terms_and_condition_ambulance_driver, container, false);

        img_back = view.findViewById(R.id.img_back);
        webView = view.findViewById(R.id.webView_term_driver);

        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requireActivity().onBackPressed();
            }
        });

        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("https://www.jsonschema2pojo.org/");

        img_back.setOnClickListener(v -> {

            requireActivity().onBackPressed();

        });
       return view;
    }
}