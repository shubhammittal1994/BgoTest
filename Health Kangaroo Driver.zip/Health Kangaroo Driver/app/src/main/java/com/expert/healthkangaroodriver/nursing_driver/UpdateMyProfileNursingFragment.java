package com.expert.healthkangaroodriver.nursing_driver;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;

import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.AppClass.CommonUtils;
import com.expert.healthkangaroodriver.Model.nurse_model.UpdateProfileNurse;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;
import com.github.dhaval2404.imagepicker.ImagePicker;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class UpdateMyProfileNursingFragment extends Fragment {

    private View view;
    String imgpath;
    ImageView profile_image;
    private ViewModelClass viewModelClass = new ViewModelClass();
    private ImageView back, add_profile_pic, profile_img_edt_prof;
    private EditText email_edit_text, name_edit_text, phone_edit_text, location_edit_text;
    private Button save_button_edt_prof;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_myprofile_update_nursing, container, false);

        FindId();
        OnClicks();
        setData();

        return view;
    }

    private void setData() {
        email_edit_text.setText(App.getSharedPref().getStringValue("Email"));
        name_edit_text.setText(App.getSharedPref().getStringValue("Name"));
        phone_edit_text.setText(App.getSharedPref().getStringValue("Phone"));
        location_edit_text.setText(App.getSharedPref().getStringValue("Address"));
        Glide.with(profile_img_edt_prof).load(App.getSharedPref().getStringValue("Image")).into(profile_img_edt_prof);

    }

    private void FindId() {

        back = view.findViewById(R.id.back_image);

        save_button_edt_prof = view.findViewById(R.id.save_btn_edt_prof);

        add_profile_pic = view.findViewById(R.id.Add_Profilepic_imageView);
        profile_img_edt_prof = view.findViewById(R.id.profile_img_edt_prof);

        name_edit_text = view.findViewById(R.id.edtx_name_profile_edit);
        email_edit_text = view.findViewById(R.id.edtx_email_profile_edit);
        phone_edit_text = view.findViewById(R.id.edtx_phn_profile_edit);
        location_edit_text = view.findViewById(R.id.edtx_locatn_profile_edit);

    }

    private void OnClicks() {

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getActivity().onBackPressed();

            }
        });

        save_button_edt_prof.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (imgpath == null) {
                    Toast.makeText(requireContext(), "Select Image", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(requireContext(), ""+App.getSharedPref().getStringValue("DriverId"), Toast.LENGTH_SHORT).show();
                    Toast.makeText(requireContext(), ""+App.getSharedPref().getStringValue("VenderId"), Toast.LENGTH_SHORT).show();
                    hitApiUpdatePtofile(CommonUtils.stringToRequest(App.getSharedPref().getStringValue("VenderId")),
                            CommonUtils.stringToRequest(App.getSharedPref().getStringValue("DriverId")), CommonUtils.imageToMultiPart("image", imgpath));

                }


//                Toast.makeText(getContext(), "Profile Edited Successfully", Toast.LENGTH_SHORT).show();

            }
        });

        add_profile_pic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ImagePicker.Companion.with(UpdateMyProfileNursingFragment.this).galleryOnly().compress(1024).start();
//                int permission = ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE);
//
//                if (permission != PackageManager.PERMISSION_GRANTED) {
//
//                    requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE
//                            , Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
//                } else {
//                    Intent intent = new Intent(Intent.ACTION_PICK);
//                    intent.setType("image/*");
//
//                    startActivityForResult(intent, 1);
//
//
//                }
            }
        });

    }

    private void hitApiUpdatePtofile(RequestBody driverId, RequestBody venderId, MultipartBody.Part image) {
        viewModelClass.updateProfileNurse(requireActivity(), driverId,venderId, image).observe(requireActivity(), new Observer<UpdateProfileNurse>() {
            @Override
            public void onChanged(UpdateProfileNurse updateProfileNurse) {
                if (updateProfileNurse.getMessage().equalsIgnoreCase("1")) {
                    getActivity().onBackPressed();

                    App.sharedPref.saveString("Image", updateProfileNurse.getDetails().getImage());
                }

                Toast.makeText(requireActivity(), "" + updateProfileNurse.getMessage(), Toast.LENGTH_SHORT).show();
                getActivity().onBackPressed();
            }
        });


    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if (resultCode == Activity.RESULT_OK && ImagePicker.REQUEST_CODE == requestCode) {
            imgpath = data.getData().getPath();
            Glide.with(requireActivity()).load(imgpath).into(profile_img_edt_prof);
        }


//        if (requestCode == 1 && resultCode == Activity.RESULT_OK) {
//
//
//            assert data != null;
//            Uri image = data.getData();
//
//            ContentResolver contentResolver = requireContext().getContentResolver();
//            Cursor cursor = contentResolver.query(image, null, null, null, null);
//
//            if (cursor != null) {
//                while (cursor.moveToNext()) {
//
//                    File file = new File(cursor.getString(cursor.getColumnIndex("_data")));
//
//                    this.imgpath = file.toString();
//
//
//                    profile_image.setImageURI(image);
//
//                }
//
//                cursor.close();
//
//            }
//
//        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                Intent intent = new Intent(Intent.ACTION_PICK);
                intent.setType("image/*");

                startActivityForResult(intent, 1);


            } else {

                if (shouldShowRequestPermissionRationale(Manifest.permission.READ_EXTERNAL_STORAGE)) {

                    requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE
                            , Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);

                } else {
                    Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                    Uri uri = Uri.fromParts("package", requireContext().getPackageName(), null);
                    intent.setData(uri);
                    requireContext().startActivity(intent);

                }
            }
        }

    }

}