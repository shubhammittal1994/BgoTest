package com.expert.healthkangaroodriver.phlebotomist_driver;


import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.directions.route.AbstractRouting;
import com.directions.route.Route;
import com.directions.route.RouteException;
import com.directions.route.Routing;
import com.directions.route.RoutingListener;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.pharmacy_model.GenerateOptModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.LabOrderDeliveredModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.PhlebotomistDriverSampleCollectionModel;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

import in.aabhasjindal.otptextview.OtpTextView;


public class StartMyDeliveryPhlebotomistFragment extends Fragment implements RoutingListener {
    private View view;
    private ImageView img_back, patience_profile_image, img_patient_call, img_patient_message;
    private TextView txt_patience_name, txt_patience_address, txt_patience_number;
    private SupportMapFragment mapFragment;
    private GoogleMap map;
    private String patienceName, patienceAddress, patiencePhone;
    private double currentLat = HomePhlebotomistFragment.myLat, currentLog = HomePhlebotomistFragment.myLng, patienceLat, patienceLog;
    private MarkerOptions place1, place2;
    private List<Polyline> polylines = null;
    public static PhlebotomistDriverSampleCollectionModel.Detail detail;
    private AppCompatButton orderComplete;
    String driverId, userId, orderId, otpView, vendorId;
    DatabaseReference reference = FirebaseDatabase.getInstance().getReference("TrackPharmacyDriver");

    LatLng start, end;

    int PERMISSION_ALL = 1;
    String[] PERMISSIONS = {Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_start_my_delivery_phlebotomist, container, false);

        if (!hasPermissions(requireActivity(), PERMISSIONS)) {
            ActivityCompat.requestPermissions(requireActivity(), PERMISSIONS, PERMISSION_ALL);
        }

        FindId();
        onClick();
        setData();


        place1 = new MarkerOptions().position(new LatLng(currentLat, currentLog)).title("Your Location");
        place2 = new MarkerOptions().position(new LatLng(patienceLat, patienceLog)).title("Patient Location");

        mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.frgMapDriverNursing);

        mapFragment.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(@NonNull GoogleMap googleMap) {

                map = googleMap;
                map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                map.setTrafficEnabled(true);
                if (ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                    return;
                }
                map.setMyLocationEnabled(false);
                map.addMarker(place1);
                map.addMarker(place2);

                start = new LatLng(currentLat, currentLog);
                end = new LatLng(patienceLat, patienceLog);


                Findroutes(start, end);


                map.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(currentLat, currentLog), 16));

            }
        });


        return view;
    }

    public static boolean hasPermissions(Context context, String... permissions) {
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && context != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(context, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    private void setData() {

        patienceName = detail.getPatientName();
        patienceAddress = detail.getAddress();
        patiencePhone = detail.getPhone();
        patienceLat = Double.parseDouble(detail.getLatitude());
        patienceLog = Double.parseDouble(detail.getLongitude());

//        Glide.with(view).load(patienceImage).into(patience_profile_image);

        txt_patience_name.setText(patienceName);
        txt_patience_address.setText(patienceAddress);
        txt_patience_number.setText(patiencePhone);

    }

    private void onClick() {

        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requireActivity().onBackPressed();
            }
        });

        img_patient_message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_myDeliveryStartScreenPhlebo_to_chatMessagingStartScreen);
            }
        });

        img_patient_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent callIntent = new Intent(Intent.ACTION_CALL);
                callIntent.setData(Uri.parse("tel:" + patiencePhone));
                startActivity(callIntent);
            }
        });

        orderComplete.setOnClickListener(v -> {
            generateOtp();


        });


    }

    private void generateOtp() {

        orderId = detail.getAppointmentId();
        driverId = detail.getLabDriverId();
        userId = detail.getUserId();


        Random rand = new Random();
        String opt;
        opt = String.format("%04d", rand.nextInt(10000));


        Map map = new HashMap();
        map.put("otp", opt);

        reference.child(orderId).updateChildren(map).addOnCompleteListener(new OnCompleteListener() {
            @Override
            public void onComplete(@NonNull Task task) {
                if (task.isSuccessful()) {

                    openDialog();

                }
            }
        });

    }


    private void openDialog() {

        final Dialog dialog = new Dialog(requireActivity());
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.order_complete_layout);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

        AppCompatButton completeOder = dialog.findViewById(R.id.order_complete);

        OtpTextView otpTextView = dialog.findViewById(R.id.otp_view_edtx);

        orderId = detail.getAppointmentId();


        reference.child(orderId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                otpView = snapshot.child("otp").getValue().toString();

                Toast.makeText(requireActivity(), "otp " + otpView, Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
            }
        });

        completeOder.setOnClickListener(v -> {

            otpTextView.equals(otpView);

            if (otpTextView.getOTP().toString().equals(otpView)) {

                if (detail.getOrderType().equalsIgnoreCase("1")) {

                    orderDeliveredGeneral("1");

                } else if (detail.getOrderType().equalsIgnoreCase("2")) {

                    orderDeliveredGeneral("2");


                } else if (detail.getOrderType().equalsIgnoreCase("3")) {

                    orderDeliveredGeneral("3");

                }

                dialog.dismiss();

            } else {

                Toast.makeText(requireActivity(), "Please Enter Valid Otp", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();


    }

    private void orderDeliveredGeneral(String s) {

        vendorId = detail.getVendorId();

        new ViewModelClass().deliveredModelLiveData(vendorId, driverId, orderId, s).observe(requireActivity(), new Observer<LabOrderDeliveredModel>() {
            @Override
            public void onChanged(LabOrderDeliveredModel labOrderDeliveredModel) {
                if (labOrderDeliveredModel.getSuccess().equalsIgnoreCase("1")) {
                    requireActivity().onBackPressed();

                    Toast.makeText(requireActivity(), labOrderDeliveredModel.getMessage(), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(requireActivity(), labOrderDeliveredModel.getMessage(), Toast.LENGTH_SHORT).show();

                }
            }
        });

    }

    private double distance(double lat1, double lng1, double lat2, double lng2) {

        Location loc1 = new Location("");
        loc1.setLatitude(lat1);
        loc1.setLongitude(lng1);
        Location loc2 = new Location("");
        loc2.setLatitude(lat2);
        loc2.setLongitude(lng2);

        float distanceInMeters = loc1.distanceTo(loc2);

        float km = distanceInMeters / 1000;

//        if (km < 0.2f){
//
//        }

        orderComplete.setVisibility(View.VISIBLE);

        return distanceInMeters;

    }

    public void Findroutes(LatLng Start, LatLng End) {
        distance(currentLat, currentLog, patienceLat, patienceLog);

        if (Start == null || End == null) {
            Toast.makeText(requireActivity(), "Unable to get location", Toast.LENGTH_LONG).show();
        } else {

            Routing routing = new Routing.Builder()
                    .travelMode(AbstractRouting.TravelMode.DRIVING)
                    .withListener(this)
                    .alternativeRoutes(true)
                    .waypoints(Start, End)
                    .key(getContext().getString(R.string.api_map_key))   //also define your api key here.
                    .build();
            routing.execute();


        }
    }

    private void FindId() {

        orderComplete = view.findViewById(R.id.order_complete_lab);
        img_back = view.findViewById(R.id.img_back);
        patience_profile_image = view.findViewById(R.id.patience_profile_image);
        img_patient_call = view.findViewById(R.id.img_patient_call);
        img_patient_message = view.findViewById(R.id.img_patient_message);
        txt_patience_name = view.findViewById(R.id.txt_patience_name);
        txt_patience_address = view.findViewById(R.id.txt_patience_address);
        txt_patience_number = view.findViewById(R.id.txt_number_lab);


    }

    @Override
    public void onRoutingFailure(RouteException e) {

    }

    @Override
    public void onRoutingStart() {

    }

    @Override
    public void onRoutingSuccess(ArrayList<Route> route, int shortestRouteIndex) {
        map.clear();
        distance(currentLat, currentLog, patienceLat, patienceLog);

        CameraUpdate center = CameraUpdateFactory.newLatLng(start);
        CameraUpdate zoom = CameraUpdateFactory.zoomTo(16);

        map.moveCamera(zoom);
        map.animateCamera(zoom);
        map.animateCamera(center);

        if (polylines != null) {
            polylines.clear();
        }

        PolylineOptions polyOptions = new PolylineOptions();
        LatLng polylineStartLatLng = null;
        LatLng polylineEndLatLng = null;


        polylines = new ArrayList<>();

        for (int i = 0; i < route.size(); i++) {

            if (i == shortestRouteIndex) {
                polyOptions.color(getResources().getColor(R.color.black));
                polyOptions.width(20);
                polyOptions.addAll(route.get(shortestRouteIndex).getPoints());
                Polyline polyline = map.addPolyline(polyOptions);
                polylineStartLatLng = polyline.getPoints().get(0);
                int k = polyline.getPoints().size();
                polylineEndLatLng = polyline.getPoints().get(k - 1);
                polylines.add(polyline);

            } else {

            }

        }


        //Add Marker on route ending position
        if (end != null) {
            MarkerOptions endMarker = new MarkerOptions();
            endMarker.position(end);
            endMarker.icon(BitmapDescriptorFactory.fromResource(R.drawable.map_point));
            map.addMarker(endMarker);
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(end, 18));
        }
        if (start != null) {
            MarkerOptions endMarker = new MarkerOptions();
            endMarker.position(start);
            endMarker.icon(BitmapDescriptorFactory.fromResource(R.drawable.drive));
            map.addMarker(endMarker);
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(start, 18));
        }

//        Findroutes(myLatLng, userLat);

    }

    @Override
    public void onRoutingCancelled() {
        Findroutes(start, end);
    }

}