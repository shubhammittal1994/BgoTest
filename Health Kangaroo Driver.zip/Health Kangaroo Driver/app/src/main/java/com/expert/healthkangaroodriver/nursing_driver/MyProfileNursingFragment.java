package com.expert.healthkangaroodriver.nursing_driver;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.nurse_model.ChangePassNurse;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;


public class MyProfileNursingFragment extends Fragment {

    private View view;
    private ImageView edit_profile_image;
    private ImageView back, image_profl;
    TextView txt_change_password;
    Dialog dialog;
    private  int oldCountPassword=0,newCountpassword=0,confirmCountPassword=0;
    private EditText email_edit_text, name_edit_text, phone_edit_text, location_edit_text;
    private ViewModelClass viewModel  =new ViewModelClass();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_myprofile_nursing, container, false);


        FindId();
        OnClicks();
        setData();
        return view;
    }

    private void setData() {
        email_edit_text.setText(App.getSharedPref().getStringValue("Email"));
        name_edit_text.setText(App.getSharedPref().getStringValue("Name"));
        phone_edit_text.setText(App.getSharedPref().getStringValue("Phone"));
        location_edit_text.setText(App.getSharedPref().getStringValue("Address"));

        Glide.with(image_profl).load(App.getSharedPref().getStringValue("Image")).into(image_profl);

    }


    private void FindId() {

        edit_profile_image = view.findViewById(R.id.edit_img);
        back = view.findViewById(R.id.back_img);
        email_edit_text = view.findViewById(R.id.edtx_email_profile);
        txt_change_password = view.findViewById(R.id.txt_change_password);
        name_edit_text = view.findViewById(R.id.edtx_name_profile);
        phone_edit_text = view.findViewById(R.id.edtx_phn_profile);
        location_edit_text = view.findViewById(R.id.edtx_locatn_profile);
        image_profl = view.findViewById(R.id.image_profl);

    }

    private void OnClicks() {

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getActivity().onBackPressed();
            }
        });

        edit_profile_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Navigation.findNavController(view).navigate(R.id.action_myprofileScreen_to_myprofileEditScreen);

            }
        });

        txt_change_password.setOnClickListener(v -> {

            dialog = new Dialog(requireActivity());
            dialog.setContentView(R.layout.layout_change_password_phlebotomist);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            dialog.setCanceledOnTouchOutside(true);


            EditText editext_password_old = dialog.findViewById(R.id.editext_password_old);
            EditText editext_password_new = dialog.findViewById(R.id.editext_password_new);
            EditText editext_password_confirm = dialog.findViewById(R.id.editext_password_confirm);

            ImageView ic_eye_id_old = dialog.findViewById(R.id.ic_eye_id_old);
            ImageView ic_eye_id_new = dialog.findViewById(R.id.ic_eye_id_new);
            ImageView ic_eye_id_confirm = dialog.findViewById(R.id.ic_eye_id_confirm);

            ic_eye_id_old.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (oldCountPassword % 2 == 0) {
                        editext_password_old.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                        ic_eye_id_old.setImageResource(R.drawable.invisible);
                    } else {
                        editext_password_old.setTransformationMethod(PasswordTransformationMethod.getInstance());
                        ic_eye_id_old.setImageResource(R.drawable.ic_baseline_remove_red_eye_24);
                    }
                    oldCountPassword++;
                }
            });

            ic_eye_id_new.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (newCountpassword % 2 == 0) {
                        editext_password_new.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                        ic_eye_id_new.setImageResource(R.drawable.invisible);
                    } else {
                        editext_password_new.setTransformationMethod(PasswordTransformationMethod.getInstance());
                        ic_eye_id_new.setImageResource(R.drawable.ic_baseline_remove_red_eye_24);
                    }
                    newCountpassword++;
                }
            });

            ic_eye_id_confirm.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (confirmCountPassword % 2 == 0) {
                        editext_password_confirm.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                        ic_eye_id_confirm.setImageResource(R.drawable.invisible);
                    } else {
                        editext_password_confirm.setTransformationMethod(PasswordTransformationMethod.getInstance());
                        ic_eye_id_confirm.setImageResource(R.drawable.ic_baseline_remove_red_eye_24);
                    }
                    confirmCountPassword++;
                }
            });


            Button btn_submit = dialog.findViewById(R.id.btn_submit);

            btn_submit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    String oldPasswordStr = editext_password_old.getText().toString();
                    String newPasswordStr = editext_password_new.getText().toString();
                    String confirmPasswordStr = editext_password_confirm.getText().toString();

                    if (oldPasswordStr.isEmpty()) {

                        Toast.makeText(requireActivity(), "Enter Old Password", Toast.LENGTH_SHORT).show();

                    } else if (newPasswordStr.isEmpty()) {

                        Toast.makeText(requireActivity(), "Enter New Password", Toast.LENGTH_SHORT).show();

                    } else if (confirmPasswordStr.isEmpty()) {

                        Toast.makeText(requireActivity(), "Enter Confirm Password", Toast.LENGTH_SHORT).show();


                    } else if (!confirmPasswordStr.matches(newPasswordStr)) {

                        Toast.makeText(requireActivity(), "Password and Confirm password should be same!", Toast.LENGTH_SHORT).show();

                    }
                    else {
                       viewModel.changePassNurse(requireActivity(),
                                App.getSharedPref().getStringValue("VenderId"),
                                App.getSharedPref().getStringValue("DriverId"), oldPasswordStr, newPasswordStr).observe(requireActivity(), new Observer<ChangePassNurse>() {
                            @Override
                            public void onChanged(ChangePassNurse changePassNurse) {
                                if (changePassNurse.getSuccess().equalsIgnoreCase("1")) {
                                    Toast.makeText(requireContext(), changePassNurse.getMessage(), Toast.LENGTH_SHORT).show();
                                    dialog.dismiss();
                                } else {
                                    Toast.makeText(requireContext(), changePassNurse.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                    }

                }
            });

            Window window = dialog.getWindow();
            window.setGravity(Gravity.CENTER);
            dialog.show();


        });


    }


        }