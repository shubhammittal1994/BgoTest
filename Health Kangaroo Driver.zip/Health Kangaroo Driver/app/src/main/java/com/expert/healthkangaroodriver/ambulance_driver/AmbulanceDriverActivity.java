package com.expert.healthkangaroodriver.ambulance_driver;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.example.healthkangaroo.R;

public class AmbulanceDriverActivity extends AppCompatActivity {
    public static final String data_key = "data_key";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ambulance_driver);
    }
}