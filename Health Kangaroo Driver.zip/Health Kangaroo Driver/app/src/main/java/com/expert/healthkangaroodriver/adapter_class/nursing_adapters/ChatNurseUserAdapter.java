package com.expert.healthkangaroodriver.adapter_class.nursing_adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.ChatModel.ChatModel;
import com.expert.healthkangaroodriver.adapter_class.pharmacy_adapters.ChatPharmacyUserAdapter;

import java.util.List;

public class ChatNurseUserAdapter extends RecyclerView.Adapter<ChatNurseUserAdapter.ViewHolder> {
    private Context context;
    List<ChatModel> list;

    public ChatNurseUserAdapter(Context context, List<ChatModel> list) {
        this.context = context;
        this.list = list;
    }
    private View view;

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_sender_message_nursing_driver, parent, false);

        return new ChatNurseUserAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        if (list.get(position).getType().equals("0")){

            holder.rl_message_user.setVisibility(View.VISIBLE);

            holder.rl_message_doctor.setVisibility(View.GONE);

            holder.UserMessage.setText(list.get(position).getMessage());

            holder.SenderTxtTime.setText(list.get(position).getTime());

        }else {

            holder.rl_message_user.setVisibility(View.GONE);

            holder.rl_message_doctor.setVisibility(View.VISIBLE);

            holder.doc_message.setText(list.get(position).getMessage());

            holder.receiverTxtTime.setText(list.get(position).getTime());

        }

    }

    @Override
    public int getItemCount() {
        return list.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView UserMessage, SenderTxtTime, doc_message, receiverTxtTime;
        private RelativeLayout rl_message_user, rl_message_doctor;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            rl_message_doctor = itemView.findViewById(R.id.rl_message_doctor);
            rl_message_user = itemView.findViewById(R.id.rl_message_user);
            UserMessage = itemView.findViewById(R.id.txt_message_user);
            SenderTxtTime = itemView.findViewById(R.id.SenderTxtTime);
            doc_message = itemView.findViewById(R.id.txtDoc_message);
            receiverTxtTime = itemView.findViewById(R.id.receiverTxtTime);

        }
    }
}
