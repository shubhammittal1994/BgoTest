package com.expert.healthkangaroodriver.ambulance_driver;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.expert.healthkangaroodriver.AppClass.App;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.ambulance_model.CreditAmbulanceAmountModel;
import com.expert.healthkangaroodriver.Model.ambulance_model.DebitAmbulanceAmountModel;
import com.expert.healthkangaroodriver.Model.ambulance_model.HistoryAmbulanceAmountModel;
import com.expert.healthkangaroodriver.Model.ambulance_model.TotalAmountAmbulanceDetailsModel;
import com.expert.healthkangaroodriver.adapter_class.ambulance_adapter.CreditedAmountAmbulanceAdapter;
import com.expert.healthkangaroodriver.adapter_class.ambulance_adapter.DebitedAmountAmbulanceAdapter;
import com.expert.healthkangaroodriver.adapter_class.ambulance_adapter.HistoryDetailsAmbulanceAdapter;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MyWalletAmbulanceDriverFragment extends Fragment {
    private View view, view_credit, view_debit, view_history_details;
    private ImageView back;
    private TextView txt_credit_amount, txt_debit_amount, txt_total_amount, txt_history_details;
    private RecyclerView recyclerview_credited_amount, recyclerview_debited_amount, recyclerview_history_details;
    private Button btn_tap_to_withdraw;
    private ProgressDialog progressDialog;
    private String strDriverId, strHospitalId, totalAmount;
    String strStartDate, strEndDate;
    private int mYear, mMonth, mDay;
    private CreditedAmountAmbulanceAdapter creditedAmountAmbulanceAdapter;
    private DebitedAmountAmbulanceAdapter debitedAmountAmbulanceAdapter;
    private HistoryDetailsAmbulanceAdapter historyDetailsAmbulanceAdapter;
    private ViewModelClass viewModel;
    private List<DebitAmbulanceAmountModel.Detail> debitedList = new ArrayList<>();;
    private List<CreditAmbulanceAmountModel.Detail> creditedList = new ArrayList<>();;
    private List<HistoryAmbulanceAmountModel.Detail> historyList = new ArrayList<>();;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_my_wallet_ambulance_driver, container, false);

        viewModel = new ViewModelClass();

        progressDialog = new ProgressDialog(requireActivity());
        progressDialog.setMessage("Loading.....");

        strDriverId = App.getSharedPref().getStringValue("DriverId");
        strHospitalId = App.getSharedPref().getStringValue("HospitalId");

        FindId();
        defaultSetAdapter();

        setTotalAmount();
        onClick();

        return view;
    }

    private void setTotalAmount() {

        totalAmount = txt_total_amount.getText().toString();


        viewModel.totalAmountAmbulanceDetailsModelLiveData(requireActivity(), strDriverId, strHospitalId).observe(requireActivity(), new Observer<TotalAmountAmbulanceDetailsModel>() {
            @Override
            public void onChanged(TotalAmountAmbulanceDetailsModel totalAmountAmbulanceDetailsModel) {
                if (totalAmountAmbulanceDetailsModel.getSuccess().equalsIgnoreCase("1")){
                    txt_total_amount.setText(totalAmountAmbulanceDetailsModel.getDetails().getAmount());
                }
            }
        });
    }


    private void defaultSetAdapter() {
        progressDialog.show();

        viewModel.creditAmbulanceAmountModelLiveData(requireActivity(), strHospitalId, strHospitalId).observe(requireActivity(), new Observer<CreditAmbulanceAmountModel>() {
            @Override
            public void onChanged(CreditAmbulanceAmountModel creditAmbulanceAmountModel) {
                progressDialog.dismiss();
                if (creditAmbulanceAmountModel.getSuccess().equalsIgnoreCase("1"))
               {
                   creditedList = creditAmbulanceAmountModel.getDetails();
                   creditedAmountAmbulanceAdapter=new CreditedAmountAmbulanceAdapter(requireActivity(), creditedList );
                   recyclerview_credited_amount.setAdapter(creditedAmountAmbulanceAdapter);
               }
               else {

                   Toast.makeText(requireContext(), creditAmbulanceAmountModel.getMessage(), Toast.LENGTH_SHORT).show();
                   progressDialog.dismiss();
               }
            }
        });


    }

    private void onClick() {

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requireActivity().onBackPressed();
            }
        });

        btn_tap_to_withdraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_myWalletAmbulanceDriverFragment_to_withdrawAmbulanceDriverFragment);
            }
        });

        txt_credit_amount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_debit_amount.setTextColor(getResources().getColor(R.color.grey));
                txt_credit_amount.setTextColor(getResources().getColor(R.color.green));
                txt_history_details.setTextColor(getResources().getColor(R.color.grey));
                view_credit.setBackgroundColor(getResources().getColor(R.color.green));
                view_debit.setBackgroundColor(getResources().getColor(R.color.white));
                view_history_details.setBackgroundColor(getResources().getColor(R.color.white));

                recyclerview_credited_amount.setVisibility(View.VISIBLE);
                recyclerview_debited_amount.setVisibility(View.GONE);
                recyclerview_history_details.setVisibility(View.GONE);

            }
        });

        txt_debit_amount.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                txt_debit_amount.setTextColor(getResources().getColor(R.color.green));
                txt_credit_amount.setTextColor(getResources().getColor(R.color.grey));
                txt_history_details.setTextColor(getResources().getColor(R.color.grey));
                view_credit.setBackgroundColor(getResources().getColor(R.color.white));
                view_debit.setBackgroundColor(getResources().getColor(R.color.green));
                view_history_details.setBackgroundColor(getResources().getColor(R.color.white));

                recyclerview_credited_amount.setVisibility(View.GONE);
                recyclerview_debited_amount.setVisibility(View.VISIBLE);
                recyclerview_history_details.setVisibility(View.GONE);

                debitedAmountApi();
            }

        });

        txt_history_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_debit_amount.setTextColor(getResources().getColor(R.color.grey));
                txt_credit_amount.setTextColor(getResources().getColor(R.color.grey));
                txt_history_details.setTextColor(getResources().getColor(R.color.green));
                view_credit.setBackgroundColor(getResources().getColor(R.color.white));
                view_debit.setBackgroundColor(getResources().getColor(R.color.white));
                view_history_details.setBackgroundColor(getResources().getColor(R.color.green));

                recyclerview_credited_amount.setVisibility(View.GONE);
                recyclerview_debited_amount.setVisibility(View.GONE);
                recyclerview_history_details.setVisibility(View.VISIBLE);


                openCalenderDialog();
            }
        });


    }

    private void debitedAmountApi() {

        viewModel.debitAmbulanceAmountModelLiveData(requireActivity(), strHospitalId, strDriverId).observe(requireActivity(), new Observer<DebitAmbulanceAmountModel>() {
            @Override
            public void onChanged(DebitAmbulanceAmountModel debitAmbulanceAmountModel) {
                if (debitAmbulanceAmountModel.getSuccess().equalsIgnoreCase("1")){
                    debitedList = debitAmbulanceAmountModel.getDetails();

                    debitedAmountAmbulanceAdapter =new DebitedAmountAmbulanceAdapter(requireActivity(), debitedList);
                    recyclerview_debited_amount.setAdapter(debitedAmountAmbulanceAdapter);
                }
                else {
                    Toast.makeText(requireContext(), debitAmbulanceAmountModel.getMessage(), Toast.LENGTH_SHORT).show();
                }

            }
        });





    }

    private void openCalenderDialog() {

        Dialog dialog = new Dialog(requireActivity());
        dialog.setContentView(R.layout.layout_design_calender_nursing_driver);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCanceledOnTouchOutside(true);

        TextView txt_start_date = dialog.findViewById(R.id.txt_start_date);
        TextView txt_end_date = dialog.findViewById(R.id.txt_end_date);
        AppCompatButton btn_done = dialog.findViewById(R.id.btn_done);


        txt_start_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(v.getContext(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                        txt_start_date.setText(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);

                        strStartDate = txt_start_date.getText().toString();
                        Toast.makeText(requireContext(), "Start  " + strStartDate, Toast.LENGTH_SHORT).show();

                    }
                }, mYear, mMonth, mDay);

                datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
                datePickerDialog.show();

            }
        });

        txt_end_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(v.getContext(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                        txt_end_date.setText(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);

                        strEndDate = txt_end_date.getText().toString();
                        Toast.makeText(requireContext(), "End  " + strEndDate, Toast.LENGTH_SHORT).show();
                    }
                }, mYear, mMonth, mDay);
                datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
                datePickerDialog.show();
            }
        });
        btn_done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

              if (strStartDate == null) {
                    Toast.makeText(requireActivity(), "Please,Select Start Date", Toast.LENGTH_SHORT).show();
                } else if (strEndDate == null) {
                    Toast.makeText(requireActivity(), "Please,Select End Date", Toast.LENGTH_SHORT).show();
                } else {

                    viewModel.historyAmbulanceAmountModelLiveData(requireActivity(), strHospitalId, strDriverId, strStartDate, strEndDate).observe(requireActivity(), new Observer<HistoryAmbulanceAmountModel>() {
                        @Override
                        public void onChanged(HistoryAmbulanceAmountModel historyAmbulanceAmountModel) {
                            if (historyAmbulanceAmountModel.getSuccess().equalsIgnoreCase("1")){
                                historyList = historyAmbulanceAmountModel.getDetails();

                                historyDetailsAmbulanceAdapter=new HistoryDetailsAmbulanceAdapter(requireActivity(), historyList);
                                recyclerview_history_details.setAdapter(historyDetailsAmbulanceAdapter);
                                dialog.dismiss();
                            }else {
                                Toast.makeText(requireContext(), historyAmbulanceAmountModel.getMessage(), Toast.LENGTH_SHORT).show();
                                dialog.dismiss();
                            }

                        }
                    });

                }

            }
        });

        Window window = dialog.getWindow();
        window.setGravity(Gravity.CENTER);
        dialog.show();

    }

    private void FindId() {

        back = view.findViewById(R.id.back_image);

        btn_tap_to_withdraw = view.findViewById(R.id.btn_tap_to_withdraw);

        txt_total_amount = view.findViewById(R.id.txt_total_amount_ambulance);
        txt_credit_amount = view.findViewById(R.id.txt_credit_amount);
        txt_debit_amount = view.findViewById(R.id.txt_debit_amount);
        txt_history_details = view.findViewById(R.id.txt_history_details);

        view_credit = view.findViewById(R.id.view_credit);
        view_debit = view.findViewById(R.id.view_debit);
        view_history_details = view.findViewById(R.id.view_history_details);

        recyclerview_credited_amount = view.findViewById(R.id.recyclerview_credited_amount);
        recyclerview_debited_amount = view.findViewById(R.id.recyclerview_debited_amount);
        recyclerview_history_details = view.findViewById(R.id.recyclerview_history_details);
    }

}