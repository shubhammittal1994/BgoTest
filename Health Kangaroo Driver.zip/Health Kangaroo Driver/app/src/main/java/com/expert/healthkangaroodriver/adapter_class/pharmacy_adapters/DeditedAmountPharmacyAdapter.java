package com.expert.healthkangaroodriver.adapter_class.pharmacy_adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.expert.healthkangaroodriver.Model.pharmacy_model.DebitedAmountListPharmacyModel;
import com.example.healthkangaroo.R;

import java.util.List;


public class DeditedAmountPharmacyAdapter extends RecyclerView.Adapter<DeditedAmountPharmacyAdapter.ViewHolder> {
    Context context;
    private List<DebitedAmountListPharmacyModel.Detail> debitedList;

    public DeditedAmountPharmacyAdapter(Context context, List<DebitedAmountListPharmacyModel.Detail> debitedList) {
        this.context = context;
        this.debitedList = debitedList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view= LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_recycler_view_debit_amount,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.txt_title.setText(debitedList.get(position).getTitle());
        holder.txt_transaction_id.setText(debitedList.get(position).getTransactionId());
        holder.txt_date_and_time.setText(debitedList.get(position).getDateTime());
        holder.txt_amount.setText(debitedList.get(position).getAmount());

    }

    @Override
    public int getItemCount() {
        return debitedList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt_date_and_time,txt_amount,txt_title,txt_transaction_id;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txt_title=itemView.findViewById(R.id.txt_title);
            txt_transaction_id=itemView.findViewById(R.id.txt_transaction_id);
            txt_date_and_time=itemView.findViewById(R.id.txt_date_and_time);
            txt_amount=itemView.findViewById(R.id.txt_amount);
        }
    }
}
