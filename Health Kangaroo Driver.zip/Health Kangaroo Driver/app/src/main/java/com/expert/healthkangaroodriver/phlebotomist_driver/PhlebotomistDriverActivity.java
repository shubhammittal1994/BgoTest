package com.expert.healthkangaroodriver.phlebotomist_driver;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.healthkangaroo.R;

public class PhlebotomistDriverActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_phlebotomist_);




    }
}