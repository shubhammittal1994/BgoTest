package com.expert.healthkangaroodriver.ambulance_driver;

import static android.content.Context.LOCATION_SERVICE;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.directions.route.AbstractRouting;
import com.directions.route.Route;
import com.directions.route.RouteException;
import com.directions.route.Routing;
import com.directions.route.RoutingListener;
import com.expert.healthkangaroodriver.AppClass.App;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.nursing_driver.HomeNursingFragment;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StartAmbulanceDriverFragment extends Fragment implements RoutingListener, LocationListener {

    private View view;
    private TextView txt_patience_name, txt_patience_address, txt_patience_relaton;
    private LinearLayout ll_relation_title;
    private ImageView patience_image;
    private ImageView back_image;
    private ImageView img_patient_call;
    private String patienceMob;
    private SupportMapFragment supportMapFragment;
    private double currentLat = HomeAmbulanceDriverFragment.myLat,
            currentLog = HomeAmbulanceDriverFragment.myLng, patienceLat, patienceLog;
    private MarkerOptions place1, place2;
    LatLng start, end;
    private GoogleMap map;
    private AppCompatButton uploadDetails, upload_condition;
    private List<Polyline> polylines = null;
    String status;
    private String patient_lat, patient_long, driverLat, driverLong;
    String strDriverId, hospitalLatitude,hospitalLongitude,orderId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_start_ambulance_driver, container, false);
        strDriverId = App.getSharedPref().getStringValue("DriverId");


        Bundle bundle = this.getArguments();

        if (bundle != null) {

            patient_lat = bundle.getString("MyLat");
            patient_long = bundle.getString("MyLog");
            driverLat = bundle.getString("driverLat");
            driverLong = bundle.getString("driverLong");
            hospitalLatitude = bundle.getString("HospitalLatitude");
            hospitalLongitude = bundle.getString("HospitalLongitude");
            orderId = bundle.getString("orderId");


        }


        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(requireActivity(), new String[]{Manifest.permission.CALL_PHONE}, 1);

        }


        findID();
        setData();
        onClick();

        try {

            if (status.equalsIgnoreCase("1")) {
                backPressed();
            } else {

            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        place1 = new MarkerOptions().position(new LatLng(Double.parseDouble(driverLat), Double.parseDouble(driverLong))).title("Your Location");
        place2 = new MarkerOptions().position(new LatLng(Double.parseDouble(patient_lat), Double.parseDouble(patient_long))).title("Patient Location");
        supportMapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.frgMapDriverNursing);
        supportMapFragment.getMapAsync(googleMap -> {

            MarkerOptions sourceMarker = new MarkerOptions().position(new LatLng(currentLat, currentLog)).title("Your Location");
            MarkerOptions destinationMarker = new MarkerOptions().position(new LatLng(patienceLat, patienceLog)).title("Destination");

            googleMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
            googleMap.setTrafficEnabled(true);
            if (ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            }
            googleMap.setMyLocationEnabled(false);
            googleMap.addMarker(sourceMarker);
            googleMap.addMarker(destinationMarker);

            map = googleMap;
            map.setMapType(GoogleMap.MAP_TYPE_NORMAL);
            map.setTrafficEnabled(true);
            if (ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                return;
            }
            map.setMyLocationEnabled(false);
            map.addMarker(place1);
            map.addMarker(place2);


            start = new LatLng(Double.parseDouble(driverLat), Double.parseDouble(driverLong));
            end = new LatLng(Double.parseDouble(patient_lat), Double.parseDouble(patient_long));


            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(currentLat, currentLog), 14));

            LocationManager lm = (LocationManager) requireActivity().getSystemService(LOCATION_SERVICE);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 0, 0, this);
            this.onLocationChanged(null);
        });


        return view;
    }

    public void Findroutes(LatLng Start, LatLng End) {

        if (Start == null || End == null) {
            Toast.makeText(requireActivity(), "Unable to get location", Toast.LENGTH_LONG).show();
        } else {

            Routing routing = new Routing.Builder()
                    .travelMode(AbstractRouting.TravelMode.DRIVING)
                    .withListener(this)
                    .alternativeRoutes(true)
                    .waypoints(Start, End)
                    .key(getContext().getString(R.string.api_map_key))  //also define your api key here.
                    .build();
            routing.execute();

        }
    }

    private void onClick() {

        uploadDetails.setOnClickListener(v -> {

            Bundle bundle = new Bundle();
            bundle.putString("MyLat", patient_lat);
            bundle.putString("MyLog", patient_long);
            bundle.putString("Patience", App.getSharedPref().getStringValue("PatienceImage"));
            bundle.putString("driverLat", driverLat);
            bundle.putString("driverLong", driverLong);
            bundle.putString("HospitalLatitude", hospitalLatitude);
            bundle.putString("HospitalLongitude", hospitalLongitude);

            Navigation.findNavController(v).navigate(R.id.uploadPatienceDetailsAmbulanceDriverFragment, bundle);
        });

        back_image.setOnClickListener(v -> requireActivity().onBackPressed());

        img_patient_call.setOnClickListener(v -> {

            Intent callIntent = new Intent(Intent.ACTION_CALL);
            callIntent.setData(Uri.parse("tel:" + patienceMob));
            startActivity(callIntent);

        });

        upload_condition.setOnClickListener(v -> {

            Bundle bundle = new Bundle();
            bundle.putString("MyLat", patient_lat);
            bundle.putString("MyLog", patient_long);
            bundle.putString("Patience", App.getSharedPref().getStringValue("PatienceImage"));
            bundle.putString("driverLat", driverLat);
            bundle.putString("driverLong", driverLong);
            bundle.putString("HospitalLatitude", hospitalLatitude);
            bundle.putString("HospitalLongitude", hospitalLongitude);
            bundle.putString("orderId", orderId);


            Navigation.findNavController(v).navigate(R.id.action_startAmbulanceDriverFragment_to_patientConditionFragment, bundle);

        });
    }


    private void setData() {

        Bundle bundle = this.getArguments();
        String page = bundle.getString("Page");
        status = bundle.getString("status");


        try {
            if (status.equalsIgnoreCase("1")) {
                uploadDetails.setVisibility(View.GONE);

            } else if (status.equalsIgnoreCase("2")) {
                upload_condition.setVisibility(View.VISIBLE);
                uploadDetails.setVisibility(View.GONE);

            }

        } catch (Exception e) {
            e.printStackTrace();
        }


        if (page == "first") {
            currentLat = Double.parseDouble(bundle.getString("MyLat"));
            currentLog = Double.parseDouble(bundle.getString("MyLog"));

            txt_patience_name.setText(App.getSharedPref().getStringValue("PatienceName"));
            txt_patience_address.setText(App.getSharedPref().getStringValue("PatienceAddress"));

            txt_patience_address.setText(App.getSharedPref().getStringValue("PatienceAddress"));

            Glide.with(getContext()).load(App.getSharedPref().getStringValue("PatienceImage")).into(patience_image);

            ll_relation_title.setVisibility(View.VISIBLE);
            txt_patience_relaton.setText(App.getSharedPref().getStringValue("RelationWithPatience"));
            patienceMob = App.getSharedPref().getStringValue("PatienceMobile");

            patienceLat = Double.parseDouble(App.getSharedPref().getStringValue("PatienceLatitude"));
            patienceLog = Double.parseDouble(App.getSharedPref().getStringValue("PatienceLongitude"));

        }
        if (page == "second") {
            currentLat = Double.parseDouble(bundle.getString("PatienceLatitude"));
            currentLog = Double.parseDouble(bundle.getString("PatienceLongitude"));

            Glide.with(view).load(bundle.getString("HospitalImage")).into(patience_image);
            txt_patience_name.setText(bundle.getString("HospitalName"));
            txt_patience_address.setText(bundle.getString("HospitalAddress"));
            ll_relation_title.setVisibility(View.GONE);
            patienceMob = bundle.getString("HospitalPhone");

            patienceLat = Double.parseDouble(bundle.getString("HospitalLatitude"));
            patienceLog = Double.parseDouble(bundle.getString("HospitalLongitude"));


        }


    }

    private void findID() {

        patience_image = view.findViewById(R.id.patience_image);
        txt_patience_name = view.findViewById(R.id.txt_patience_name);
        txt_patience_address = view.findViewById(R.id.txt_patience_address);
        ll_relation_title = view.findViewById(R.id.ll_relation_title);
        txt_patience_relaton = view.findViewById(R.id.txt_patience_relaton);
        img_patient_call = view.findViewById(R.id.img_patient_call);
        uploadDetails = view.findViewById(R.id.upload_details_user);
        back_image = view.findViewById(R.id.back_image);
        upload_condition = view.findViewById(R.id.upload_condition);

    }

    //Routing call back functions.
    @Override
    public void onRoutingFailure(RouteException e) {

    }

    @Override
    public void onRoutingStart() {

    }

    //If Route finding success..
    @Override
    public void onRoutingSuccess(ArrayList<Route> route, int shortestRouteIndex) {
        map.clear();
        CameraUpdate center = CameraUpdateFactory.newLatLng(start);
        CameraUpdate zoom = CameraUpdateFactory.zoomTo(16);

        if (polylines != null) {
            polylines.clear();
        }

        PolylineOptions polyOptions = new PolylineOptions();
        LatLng polylineStartLatLng = null;
        LatLng polylineEndLatLng = null;


        polylines = new ArrayList<>();

        for (int i = 0; i < route.size(); i++) {

            if (i == shortestRouteIndex) {
                polyOptions.color(getResources().getColor(R.color.black));
                polyOptions.width(20);
                polyOptions.addAll(route.get(shortestRouteIndex).getPoints());
                Polyline polyline = map.addPolyline(polyOptions);
                polylineStartLatLng = polyline.getPoints().get(0);
                int k = polyline.getPoints().size();
                polylineEndLatLng = polyline.getPoints().get(k - 1);
                polylines.add(polyline);

            } else {

            }

        }

        //Add Marker on route ending position
        if (end != null) {
            MarkerOptions startMarker = new MarkerOptions();
            startMarker.position(end);
            startMarker.icon(BitmapDescriptorFactory.fromResource(R.drawable.map_point));
            map.addMarker(startMarker);
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(end, 18));
        }
        if (start != null) {
            MarkerOptions endMarker = new MarkerOptions();
            endMarker.position(start);
            endMarker.icon(BitmapDescriptorFactory.fromResource(R.drawable.ambulance));
            map.addMarker(endMarker);
            map.animateCamera(CameraUpdateFactory.newLatLngZoom(start, 18));
        }

//        Findroutes(myLatLng, userLat);

    }

    @Override
    public void onRoutingCancelled() {
    }


    private void backPressed() {

        view.setFocusableInTouchMode(true);

        view.requestFocus();

        view.setOnKeyListener((view, i, keyEvent) -> {
            if (keyEvent.getAction() == KeyEvent.ACTION_DOWN) {

                if (i == KeyEvent.KEYCODE_BACK) {

                    Navigation.findNavController(view).navigate(R.id.homeAmbulanceDriverFragment);


                    return true;

                }
            }

            return false;
        });
    }

    @Override
    public void onLocationChanged(Location location) {

        if (location == null) {
            // if you can't get speed because reasons :)
       // Toast.makeText(requireContext(), "00 km/h", Toast.LENGTH_SHORT).show();
            Findroutes(start, end);

        } else {
            //int speed=(int) ((location.getSpeed()) is the standard which returns meters per second. In this example i converted it to kilometers per hour
            Findroutes(start, end);

            int speed = (int) ((location.getSpeed() * 3600) / 1000);

        //   Toast.makeText(requireContext(), "" + speed + " km/h", Toast.LENGTH_SHORT).show();
        }


        try {
            // Get the location manager
            double lat;
            double lon;
            double speed = 0;
            double time = 0;
            LocationManager locationManager = (LocationManager)
                    getActivity().getSystemService(LOCATION_SERVICE);
            Criteria criteria = new Criteria();
            String bestProvider = locationManager.getBestProvider(criteria, false);
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                return;
            }
            Location lastKnownLocation = locationManager.getLastKnownLocation(bestProvider);

            try {
                lat = lastKnownLocation.getLatitude();
                lon = lastKnownLocation.getLongitude();
                speed = (int) ((location.getSpeed() * 3600) / 1000);
                time = lastKnownLocation.getTime();

            } catch (NullPointerException e) {
                lat = -1.0;
                lon = -1.0;
            }


//           Toast.makeText(requireContext(), "time " + time, Toast.LENGTH_SHORT).show();

//            mTxt_lat.setText("" + lat);
//            mTxt_speed.setText("" + speed);

            DatabaseReference reference = FirebaseDatabase.getInstance().getReference("ambulanceSpeed");

            Map map = new HashMap();
            map.put("driverLat", lat);
            map.put("driverLong", lon);
            map.put("time", time);
            map.put("speed", speed);
            map.put("driverId", strDriverId);

            reference.child(strDriverId).setValue(map);

        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onProviderEnabled(String provider) {
        // TODO Auto-generated method stub

    }

    @Override
    public void onProviderDisabled(String provider) {


    }
}