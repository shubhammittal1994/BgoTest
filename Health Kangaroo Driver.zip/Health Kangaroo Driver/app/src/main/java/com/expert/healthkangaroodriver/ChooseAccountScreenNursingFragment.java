package com.expert.healthkangaroodriver;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.example.healthkangaroo.R;

import java.util.Objects;

public class ChooseAccountScreenNursingFragment extends Fragment implements View.OnClickListener {

    View view;
    ImageView image_add1;
    ImageView back;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_choose_account_screen, container, false);

        FindId();

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                requireActivity().onBackPressed();

            }
        });

        image_add1.setOnClickListener(this::onClick);

        return view;
    }

    private void FindId() {

        image_add1=view.findViewById(R.id.image_add);
        back=view.findViewById(R.id.back_image);

    }

    @Override
    public void onClick(View v) {

//        Navigation.findNavController(view).navigate(R.id.action_chooseAccountScreen_to_addBankScreen);
    }
}