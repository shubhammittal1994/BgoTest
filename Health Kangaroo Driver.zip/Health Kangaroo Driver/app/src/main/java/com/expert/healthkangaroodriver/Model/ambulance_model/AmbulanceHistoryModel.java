package com.expert.healthkangaroodriver.Model.ambulance_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class AmbulanceHistoryModel {

    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("success")
    @Expose
    private String success;
    @SerializedName("details")
    @Expose
    private List<Detail> details = null;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public List<Detail> getDetails() {
        return details;
    }

    public void setDetails(List<Detail> details) {
        this.details = details;
    }
    public class Detail {

        @SerializedName("id")
        @Expose
        private String id;
        @SerializedName("hosId")
        @Expose
        private String hosId;
        @SerializedName("doctor_id")
        @Expose
        private String doctorId;
        @SerializedName("patient_id")
        @Expose
        private String patientId;
        @SerializedName("discharge_reason")
        @Expose
        private String dischargeReason;
        @SerializedName("discharge_image")
        @Expose
        private String dischargeImage;
        @SerializedName("discharge_history_image")
        @Expose
        private String dischargeHistoryImage;
        @SerializedName("price")
        @Expose
        private String price;
        @SerializedName("DC_status")
        @Expose
        private String dCStatus;
        @SerializedName("status")
        @Expose
        private String status;
        @SerializedName("created")
        @Expose
        private String created;
        @SerializedName("updated")
        @Expose
        private String updated;
        @SerializedName("doctor_name")
        @Expose
        private String doctorName;
        @SerializedName("driverId")
        @Expose
        private String driverId;
        @SerializedName("driver_name")
        @Expose
        private String driverName;
        @SerializedName("ambulance_number")
        @Expose
        private String ambulanceNumber;
        @SerializedName("patient_details")
        @Expose
        private String patientDetails;
        @SerializedName("phone")
        @Expose
        private String phone;
        @SerializedName("username")
        @Expose
        private String username;
        @SerializedName("releation")
        @Expose
        private String releation;
        @SerializedName("case_type")
        @Expose
        private String caseType;
        @SerializedName("patient_address")
        @Expose
        private String patientAddress;
        @SerializedName("patient_img")
        @Expose
        private String patientImg;
        @SerializedName("patient_no")
        @Expose
        private String patientNo;
        @SerializedName("policeheadName")
        @Expose
        private String policeheadName;
        @SerializedName("address")
        @Expose
        private String address;
        @SerializedName("policeheadPhone")
        @Expose
        private String policeheadPhone;
        @SerializedName("hospitalName")
        @Expose
        private String hospitalName;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getHosId() {
            return hosId;
        }

        public void setHosId(String hosId) {
            this.hosId = hosId;
        }

        public String getDoctorId() {
            return doctorId;
        }

        public void setDoctorId(String doctorId) {
            this.doctorId = doctorId;
        }

        public String getPatientId() {
            return patientId;
        }

        public void setPatientId(String patientId) {
            this.patientId = patientId;
        }

        public String getDischargeReason() {
            return dischargeReason;
        }

        public void setDischargeReason(String dischargeReason) {
            this.dischargeReason = dischargeReason;
        }

        public String getDischargeImage() {
            return dischargeImage;
        }

        public void setDischargeImage(String dischargeImage) {
            this.dischargeImage = dischargeImage;
        }

        public String getDischargeHistoryImage() {
            return dischargeHistoryImage;
        }

        public void setDischargeHistoryImage(String dischargeHistoryImage) {
            this.dischargeHistoryImage = dischargeHistoryImage;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getDCStatus() {
            return dCStatus;
        }

        public void setDCStatus(String dCStatus) {
            this.dCStatus = dCStatus;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getCreated() {
            return created;
        }

        public void setCreated(String created) {
            this.created = created;
        }

        public String getUpdated() {
            return updated;
        }

        public void setUpdated(String updated) {
            this.updated = updated;
        }

        public String getDoctorName() {
            return doctorName;
        }

        public void setDoctorName(String doctorName) {
            this.doctorName = doctorName;
        }

        public String getDriverId() {
            return driverId;
        }

        public void setDriverId(String driverId) {
            this.driverId = driverId;
        }

        public String getDriverName() {
            return driverName;
        }

        public void setDriverName(String driverName) {
            this.driverName = driverName;
        }

        public String getAmbulanceNumber() {
            return ambulanceNumber;
        }

        public void setAmbulanceNumber(String ambulanceNumber) {
            this.ambulanceNumber = ambulanceNumber;
        }

        public String getPatientDetails() {
            return patientDetails;
        }

        public void setPatientDetails(String patientDetails) {
            this.patientDetails = patientDetails;
        }

        public String getPhone() {
            return phone;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getReleation() {
            return releation;
        }

        public void setReleation(String releation) {
            this.releation = releation;
        }

        public String getCaseType() {
            return caseType;
        }

        public void setCaseType(String caseType) {
            this.caseType = caseType;
        }

        public String getPatientAddress() {
            return patientAddress;
        }

        public void setPatientAddress(String patientAddress) {
            this.patientAddress = patientAddress;
        }

        public String getPatientImg() {
            return patientImg;
        }

        public void setPatientImg(String patientImg) {
            this.patientImg = patientImg;
        }

        public String getPatientNo() {
            return patientNo;
        }

        public void setPatientNo(String patientNo) {
            this.patientNo = patientNo;
        }

        public String getPoliceheadName() {
            return policeheadName;
        }

        public void setPoliceheadName(String policeheadName) {
            this.policeheadName = policeheadName;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getPoliceheadPhone() {
            return policeheadPhone;
        }

        public void setPoliceheadPhone(String policeheadPhone) {
            this.policeheadPhone = policeheadPhone;
        }

        public String getHospitalName() {
            return hospitalName;
        }

        public void setHospitalName(String hospitalName) {
            this.hospitalName = hospitalName;
        }

    }
}
