package com.expert.healthkangaroodriver.AppClass;

import android.content.Context;
import android.net.ConnectivityManager;

import java.io.File;

import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class CommonUtils {

    public static RequestBody stringToRequest(String s) {

        return RequestBody.create(MediaType.parse("text/plain"), s);
    }


    public static MultipartBody.Part imageToMultiPart(String parameter, String imagePath) {

        if (!imagePath.equalsIgnoreCase("")) {
            File file = new File(imagePath);
            RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), file);
            return MultipartBody.Part.createFormData(parameter, file.getName(), requestFile);
        } else {
            RequestBody requestFile = RequestBody.create(MediaType.parse("multipart/form-data"), "");
            return MultipartBody.Part.createFormData(parameter, "", requestFile);
        }


    }

    public static boolean isNetworkConnected(Context context) {
        ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
        return cm.getActiveNetworkInfo() != null;
    }
}
