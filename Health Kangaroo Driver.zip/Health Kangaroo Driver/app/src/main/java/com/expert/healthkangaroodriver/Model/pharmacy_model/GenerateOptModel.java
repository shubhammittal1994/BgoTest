package com.expert.healthkangaroodriver.Model.pharmacy_model;

public class GenerateOptModel {

    private String otp;

    public GenerateOptModel(String otp){
        this.otp = otp;

    }


    public GenerateOptModel() {
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

}
