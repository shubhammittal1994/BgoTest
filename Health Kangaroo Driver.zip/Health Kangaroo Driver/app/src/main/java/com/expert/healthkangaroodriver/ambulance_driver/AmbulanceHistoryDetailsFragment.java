package com.expert.healthkangaroodriver.ambulance_driver;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.ambulance_model.AmbulanceHistoryModel;
import com.makeramen.roundedimageview.RoundedImageView;

public class AmbulanceHistoryDetailsFragment extends Fragment {
    public static AmbulanceHistoryModel.Detail list;
    View view;
    TextView txtDetails_case, txtPatientNum, txtDoctorName, txtHospitalName, ambulance_booked, user_phone,
            txtDriverName
            ,txtAmbulanceNum, txtDetails_relation,case_type,txtDate, txtPrice, address, station_name, txtPatientAddress, police_report, txtPatientStatus;

    RoundedImageView roundedImageView;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view =  inflater.inflate(R.layout.fragment_ambulace_history_details, container, false);

        findIds();

        return view;
    }

    private void findIds() {

        txtDetails_case = view.findViewById(R.id.txtDetails_case);
        txtPatientNum = view.findViewById(R.id.txtPatientNum);
        txtDoctorName = view.findViewById(R.id.txtDoctorName);
        txtHospitalName = view.findViewById(R.id.txtHospitalName);
        ambulance_booked = view.findViewById(R.id.ambulance_booked);
        user_phone = view.findViewById(R.id.user_phone);
        txtAmbulanceNum = view.findViewById(R.id.txtAmbulanceNum);
        txtDate = view.findViewById(R.id.txtDate);
        address = view.findViewById(R.id.address);
        station_name = view.findViewById(R.id.station_name);
        txtPatientAddress = view.findViewById(R.id.txtPatientAddress);
        police_report = view.findViewById(R.id.police_report);
        txtDriverName = view.findViewById(R.id.txtDriverName);
        txtPrice = view.findViewById(R.id.txtPrice);
        roundedImageView = view.findViewById(R.id.imgPatient);
        txtPatientStatus = view.findViewById(R.id.txtPatientStatus);
        txtDetails_relation = view.findViewById(R.id.txtDetails_relation);
        case_type = view.findViewById(R.id.case_type);

        txtDetails_case.setText(list.getPatientDetails());
        txtPatientNum.setText(list.getPatientId());
        txtDoctorName.setText(list.getDoctorName());
        txtHospitalName.setText(list.getHospitalName());
        ambulance_booked.setText(list.getUsername());
        user_phone.setText(list.getPhone());
        txtAmbulanceNum.setText(list.getAmbulanceNumber());
        txtDate.setText(list.getCreated());
        address.setText(list.getAddress());
        station_name.setText(list.getPoliceheadName());
        txtPatientAddress.setText(list.getPatientAddress());
        police_report.setText(list.getPatientDetails());
        txtDriverName.setText(list.getDriverName());
        txtPatientStatus.setText(list.getDischargeReason());
        txtDetails_relation.setText(list.getReleation());
        txtPrice.setText(list.getPrice());
        Glide.with(getContext()).load(list.getPatientImg()).into(roundedImageView);


        if (list.getCaseType().equalsIgnoreCase("0"))
        {
         case_type.setText("Medical Emergency");

        }else {
            case_type.setText("Accidental Emergency");

        }

    }
}