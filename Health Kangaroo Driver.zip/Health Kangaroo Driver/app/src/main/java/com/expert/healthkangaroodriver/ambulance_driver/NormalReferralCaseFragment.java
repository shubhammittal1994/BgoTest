package com.expert.healthkangaroodriver.ambulance_driver;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.RecyclerView;

import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.example.healthkangaroo.R;
import com.example.healthkangaroo.databinding.FragmentNormalReferralCaseBinding;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.PatientConditionModal;
import com.expert.healthkangaroodriver.Model.ambulance_model.NearByHospitalListModel;
import com.expert.healthkangaroodriver.Model.ambulance_model.SearchModal;
import com.expert.healthkangaroodriver.adapter_class.ambulance_adapter.NearByHospitalAdaper;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class NormalReferralCaseFragment extends Fragment {

    View view;
    private String selectedHospitalId, strDriverId, myLat, myLog, userId;
    RecyclerView near_by_recyclerview;
    AppCompatButton send_button, search_button;
    EditText patient_details, search_hospital;
    private List<NearByHospitalListModel.Detail> hospitalList = new ArrayList<>();
    NearByHospitalAdaper nearByHospitalAdaper;
    ImageView back_image, userid;
    private String patient_lat, patient_long, driverLat, driverLong, orderId;
    String hospitalLatitude, hospitalLongitude;
    DatabaseReference reference, databaseReference;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_normal_referral_case, container, false);

        myLat = String.valueOf(App.getSingleton().getLat());
        myLog = String.valueOf(App.getSingleton().getLog());
        strDriverId = App.getSharedPref().getStringValue("DriverId");

        databaseReference = FirebaseDatabase.getInstance().getReference("ambulanceInvoice");

        Bundle bundle = this.getArguments();

        if (bundle != null) {

            patient_lat = bundle.getString("MyLat");
            patient_long = bundle.getString("MyLog");
            driverLat = bundle.getString("driverLat");
            driverLong = bundle.getString("driverLong");
            hospitalLatitude = bundle.getString("HospitalLatitude");
            hospitalLongitude = bundle.getString("HospitalLongitude");
            orderId = bundle.getString("orderId");

        }

        near_by_recyclerview = view.findViewById(R.id.near_by_recyclerview);
        send_button = view.findViewById(R.id.send_button);
        patient_details = view.findViewById(R.id.patient_details);
        search_hospital = view.findViewById(R.id.search_hospital);
        search_button = view.findViewById(R.id.search_button);
        back_image = view.findViewById(R.id.back_image);

        userId = App.getSharedPref().getStringValue("userID");

        setRecyclerView();
        searchItem();

        send_button.setOnClickListener(v -> {

            uploadDetails();

        });
        back_image.setOnClickListener(v -> {

            requireActivity().onBackPressed();

        });

        invoice();

        return view;
    }


    private void invoice() {

    }

    private void searchItemApi() {
        String search = search_hospital.getText().toString();

        new ViewModelClass().searchModalLiveData(requireActivity(), search).observe(requireActivity(), new Observer<SearchModal>() {
            @Override
            public void onChanged(SearchModal searchModal) {

                if (searchModal.getSuccess().equalsIgnoreCase("1")) {

                    Toast.makeText(requireContext(), "" + searchModal.getSuccess(), Toast.LENGTH_SHORT).show();

                } else {

                    Toast.makeText(requireContext(), "" + searchModal.getSuccess(), Toast.LENGTH_SHORT).show();

                }
            }

        });
    }

    private void searchItem() {
        search_hospital.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                filter(s.toString());

            }
        });
    }

    private void filter(String text) {

        new ViewModelClass().searchModalLiveData(requireActivity(), text).observe(requireActivity(), new Observer<SearchModal>() {
            @Override
            public void onChanged(SearchModal searchModal) {

                if (searchModal.getSuccess().equalsIgnoreCase("1")) {

                    Toast.makeText(requireContext(), "" + searchModal.getSuccess(), Toast.LENGTH_SHORT).show();

                } else {

                    Toast.makeText(requireContext(), "" + searchModal.getSuccess(), Toast.LENGTH_SHORT).show();

                }
            }

        });
    }

    private void uploadDetails() {
        String details = patient_details.getText().toString();

        Toast.makeText(requireActivity(), "ok", Toast.LENGTH_SHORT).show();


        new ViewModelClass().normalRefferralCaseCompleteByDriver(requireActivity(), userId, strDriverId, selectedHospitalId,
                details, patient_lat, patient_long, hospitalLatitude,
                hospitalLongitude, orderId).observe(requireActivity(), new Observer<PatientConditionModal>() {
            @Override
            public void onChanged(PatientConditionModal patientConditionModal) {
                if (patientConditionModal.getSuccess().equalsIgnoreCase("1")) {
                    Toast.makeText(requireActivity(), patientConditionModal.getMessage(), Toast.LENGTH_SHORT).show();
                    
                    openDialog(patientConditionModal);

                    DatabaseReference reference = FirebaseDatabase.getInstance().getReference("ambulanceRequest");

                    reference.child(strDriverId).addValueEventListener(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            if (snapshot.exists()) {
                                String driverId = snapshot.child("driverId").getValue().toString();
                                reference.child(driverId).removeValue();
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });

                } else {
                    Toast.makeText(requireActivity(), patientConditionModal.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


    private void openDialog(PatientConditionModal patientConditionModal) {
        Calendar callForDate = Calendar.getInstance();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("dd-MM-yy");
        String date = simpleDateFormat.format(callForDate.getTime());

        Calendar callForTime = Calendar.getInstance();
        SimpleDateFormat simpleTime = new SimpleDateFormat("hh-mm-a");
        String time = simpleTime.format(callForTime.getTime());


        Map map = new HashMap();
        map.put("date", date);
        map.put("userId", userId);
        map.put("Price", patientConditionModal.getDetails().getTotalPrice());
        map.put("distance", patientConditionModal.getDetails().getDistanceInKm());
        map.put("fixed", patientConditionModal.getDetails().getTotalPrice());
        map.put("patientNo", patientConditionModal.getDetails().getPatientNo());
        map.put("perkmPrice", patientConditionModal.getDetails().getAmbulancePerKmPrice());
        map.put("time", time);

        databaseReference.child(userId).setValue(map);

    }

    private void setRecyclerView() {

        new ViewModelClass().nearByHospitalLiveDta(requireActivity(), myLat, myLog).observe(requireActivity(), new Observer<NearByHospitalListModel>() {
            @Override
            public void onChanged(NearByHospitalListModel nearByHospitalListModel) {
                if (nearByHospitalListModel.getSuccess().equalsIgnoreCase("1")) {
                    hospitalList = nearByHospitalListModel.getDetails();

                    NearByHospitalAdaper nearByHospitalAdaper = new NearByHospitalAdaper(requireActivity(), hospitalList, new NearByHospitalAdaper.HospitalSelect() {
                        @Override
                        public void selectedHospital(String hosId, String latitude, String longitude, String hosImage, String hosName, String hosMobile, String hosAddress) {

                            selectedHospitalId = hosId;
                        }

                    });
                    near_by_recyclerview.setAdapter(nearByHospitalAdaper);

                    Toast.makeText(requireActivity(), nearByHospitalListModel.getMessage(), Toast.LENGTH_SHORT).show();
                } else {

                    Toast.makeText(requireActivity(), nearByHospitalListModel.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}