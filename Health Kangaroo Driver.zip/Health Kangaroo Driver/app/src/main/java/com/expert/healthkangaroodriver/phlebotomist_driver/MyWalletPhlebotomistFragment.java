package com.expert.healthkangaroodriver.phlebotomist_driver;

import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;

import androidx.appcompat.widget.AppCompatButton;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.CreditedAmountInPhlebotomistWalletModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.DebitedAmountListPhlebotomistModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.GetPhlebotomistWithdrawlCreditHistoryModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.PhlebotomistWalletTotalAmountModel;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.RequestMoneyLabModel;
import com.expert.healthkangaroodriver.adapter_class.phlebotomist_adapters.CreditedAmountPhlebotomistAdapter;
import com.expert.healthkangaroodriver.adapter_class.phlebotomist_adapters.DeditedAmountPhlebotomistAdapter;
import com.expert.healthkangaroodriver.adapter_class.phlebotomist_adapters.HistoryDetailsPhlebotomistAdapter;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

public class MyWalletPhlebotomistFragment extends Fragment {
    private View view, view_credit, view_debit, view_history_details;
    private ImageView back;
    private TextView txt_credit_amount, txt_debit_amount, txt_total_amount, txt_history_details;
    private RecyclerView recyclerview_credited_amount, recyclerview_debited_amount, recyclerview_history_details;
    private Button btn_tap_to_withdraw;
    String strStartDate, strEndDate;
    private int mYear, mMonth, mDay;
    private ViewModelClass viewModel;
    private ProgressDialog progressDialog;
    private String strDriverId, strVenderId;
    private CreditedAmountPhlebotomistAdapter adapter;
    private DeditedAmountPhlebotomistAdapter deditedAmountAdapter;
    private HistoryDetailsPhlebotomistAdapter historyAdapter;
    private List<CreditedAmountInPhlebotomistWalletModel.Detail> creditedList = new ArrayList<>();
    private List<DebitedAmountListPhlebotomistModel.Detail> debitedList = new ArrayList<>();
    private List<GetPhlebotomistWithdrawlCreditHistoryModel.Detail> historyList = new ArrayList<>();

    AppCompatButton requestMoney, detailsMoney;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_my_wallet_phlebotomist, container, false);

        viewModel = new ViewModelClass();

        progressDialog = new ProgressDialog(requireActivity());
        progressDialog.setMessage("Loading.....");

        strDriverId = App.getSharedPref().getStringValue("DriverId");
        strVenderId = App.getSharedPref().getStringValue("VenderId");

        FindId();

        defaultSetAdapter();

        onClick();

        setData();


        return view;
    }

    private void setData() {

        progressDialog.show();

        viewModel.LiveDataPhlebotomistWalletTotalAmount(requireActivity(), strDriverId, strVenderId).observe(requireActivity(), new Observer<PhlebotomistWalletTotalAmountModel>() {
            @Override
            public void onChanged(PhlebotomistWalletTotalAmountModel phlebotomistWalletTotalAmountModel) {
                if (phlebotomistWalletTotalAmountModel.getSuccess().equalsIgnoreCase("1")) {
                    progressDialog.dismiss();

                    txt_total_amount.setText(phlebotomistWalletTotalAmountModel.getDetails().getAmount());
                    Toast.makeText(requireContext(), phlebotomistWalletTotalAmountModel.getMessage(), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(requireContext(), phlebotomistWalletTotalAmountModel.getMessage(), Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }
        });


    }

    private void defaultSetAdapter() {

        progressDialog.show();

        viewModel.LiveDataCreditedAmountInPhlebotomistWallet(requireActivity(), strDriverId, strVenderId).observe(requireActivity(), new Observer<CreditedAmountInPhlebotomistWalletModel>() {
            @Override
            public void onChanged(CreditedAmountInPhlebotomistWalletModel creditedAmountInPhlebotomistWalletModel) {
                if (creditedAmountInPhlebotomistWalletModel.getSuccess().equalsIgnoreCase("1")) {
                    Toast.makeText(requireContext(), creditedAmountInPhlebotomistWalletModel.getMessage(), Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                    creditedList = creditedAmountInPhlebotomistWalletModel.getDetails();

                    adapter = new CreditedAmountPhlebotomistAdapter(requireActivity(), creditedList);
                    recyclerview_credited_amount.setAdapter(adapter);

                } else {
                    Toast.makeText(requireContext(), creditedAmountInPhlebotomistWalletModel.getMessage(), Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }
        });

    }

    private void onClick() {
        detailsMoney.setOnClickListener(v -> {
            Navigation.findNavController(v).navigate(R.id.action_wallet2_to_labDriverRequestDetailsFragment);

        });

        requestMoney.setOnClickListener(v -> {
            requestMoneyVendor();
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requireActivity().onBackPressed();
            }
        });

        btn_tap_to_withdraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_wallet2_to_chooseBankAccount2);
            }
        });

        txt_credit_amount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_debit_amount.setTextColor(getResources().getColor(R.color.grey));
                txt_credit_amount.setTextColor(getResources().getColor(R.color.green));
                txt_history_details.setTextColor(getResources().getColor(R.color.grey));
                view_credit.setBackgroundColor(getResources().getColor(R.color.green));
                view_debit.setBackgroundColor(getResources().getColor(R.color.white));
                view_history_details.setBackgroundColor(getResources().getColor(R.color.white));

                recyclerview_credited_amount.setVisibility(View.VISIBLE);
                recyclerview_debited_amount.setVisibility(View.GONE);
                recyclerview_history_details.setVisibility(View.GONE);

            }
        });

        txt_debit_amount.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                txt_debit_amount.setTextColor(getResources().getColor(R.color.green));
                txt_credit_amount.setTextColor(getResources().getColor(R.color.grey));
                txt_history_details.setTextColor(getResources().getColor(R.color.grey));
                view_credit.setBackgroundColor(getResources().getColor(R.color.white));
                view_debit.setBackgroundColor(getResources().getColor(R.color.green));
                view_history_details.setBackgroundColor(getResources().getColor(R.color.white));

                recyclerview_credited_amount.setVisibility(View.GONE);
                recyclerview_debited_amount.setVisibility(View.VISIBLE);
                recyclerview_history_details.setVisibility(View.GONE);

                debitedAmountApi();
            }

        });

        txt_history_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txt_debit_amount.setTextColor(getResources().getColor(R.color.grey));
                txt_credit_amount.setTextColor(getResources().getColor(R.color.grey));
                txt_history_details.setTextColor(getResources().getColor(R.color.green));
                view_credit.setBackgroundColor(getResources().getColor(R.color.white));
                view_debit.setBackgroundColor(getResources().getColor(R.color.white));
                view_history_details.setBackgroundColor(getResources().getColor(R.color.green));

                recyclerview_credited_amount.setVisibility(View.GONE);
                recyclerview_debited_amount.setVisibility(View.GONE);
                recyclerview_history_details.setVisibility(View.VISIBLE);


                openCalenderDialog();
            }
        });


    }

    private void requestMoneyVendor() {

    final Dialog dialog = new Dialog(requireContext());
    dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
    dialog.setContentView(R.layout.request_money_layout);
    dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
    Button sentRequest = dialog.findViewById(R.id.request_money_bt);


        sentRequest.setOnClickListener(v -> {

        EditText amount = dialog.findViewById(R.id.edt_amount);

        String amountStr = amount.getText().toString();

        if (amountStr.isEmpty()){

            amount.setError("Enter Amount");

        }
        else

        {
            Toast.makeText(requireActivity(), strVenderId, Toast.LENGTH_SHORT).show();
            Toast.makeText(requireActivity(), strDriverId, Toast.LENGTH_SHORT).show();
            Toast.makeText(requireActivity(), amountStr, Toast.LENGTH_SHORT).show();


            viewModel.requestMoneyLabModelLiveData(requireActivity(), strVenderId, strDriverId, amountStr).observe(requireActivity(), new Observer<RequestMoneyLabModel>() {
                @Override
                public void onChanged(RequestMoneyLabModel requestMoneyLabModel) {
                    if (requestMoneyLabModel.getSuccess().equalsIgnoreCase("1")){

                        Toast.makeText(requireActivity(), "Request Sent Successfully", Toast.LENGTH_SHORT).show();

                        dialog.dismiss();

                    }else {

                        Toast.makeText(requireActivity(), "Something wen wrong!", Toast.LENGTH_SHORT).show();

                    }
                }
            });
        }
        });

        dialog.show();

    }

    private void openCalenderDialog() {

        Dialog dialog = new Dialog(requireActivity());
        dialog.setContentView(R.layout.layout_design_calender_nursing_driver);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCanceledOnTouchOutside(true);

        TextView txt_start_date = dialog.findViewById(R.id.txt_start_date);
        TextView txt_end_date = dialog.findViewById(R.id.txt_end_date);
        AppCompatButton btn_done = dialog.findViewById(R.id.btn_done);


        txt_start_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(v.getContext(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                        txt_start_date.setText(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);

                        strStartDate = txt_start_date.getText().toString();
                        Toast.makeText(requireContext(), "Start  " + strStartDate, Toast.LENGTH_SHORT).show();

                    }
                }, mYear, mMonth, mDay);

                datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
                datePickerDialog.show();
            }
        });

        txt_end_date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR);
                mMonth = c.get(Calendar.MONTH);
                mDay = c.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog datePickerDialog = new DatePickerDialog(v.getContext(), new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {

                        txt_end_date.setText(year + "-" + (monthOfYear + 1) + "-" + dayOfMonth);

                        strEndDate = txt_end_date.getText().toString();
                        Toast.makeText(requireContext(), "End  " + strEndDate, Toast.LENGTH_SHORT).show();
                    }
                }, mYear, mMonth, mDay);

                datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
                datePickerDialog.show();
            }
        });

        btn_done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (strStartDate == null) {
                    Toast.makeText(requireActivity(), "Please,Select Start Date", Toast.LENGTH_SHORT).show();
                } else if (strEndDate == null) {
                    Toast.makeText(requireActivity(), "Please,Select End Date", Toast.LENGTH_SHORT).show();
                } else {

                    viewModel.liveDataGetPhlebotomistWithdrawlCreditHistory(requireActivity(), strDriverId, strVenderId, strStartDate, strEndDate).observe(requireActivity(), new Observer<GetPhlebotomistWithdrawlCreditHistoryModel>() {
                        @Override
                        public void onChanged(GetPhlebotomistWithdrawlCreditHistoryModel getPhlebotomistWithdrawlCreditHistoryModel) {
                            if (getPhlebotomistWithdrawlCreditHistoryModel.getSuccess().equalsIgnoreCase("1")) {
                                historyList = getPhlebotomistWithdrawlCreditHistoryModel.getDetails();

                                historyAdapter = new HistoryDetailsPhlebotomistAdapter(requireActivity(), historyList);
                                recyclerview_history_details.setAdapter(historyAdapter);
                                dialog.dismiss();

                                Toast.makeText(requireActivity(), getPhlebotomistWithdrawlCreditHistoryModel.getMessage(), Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(requireContext(), getPhlebotomistWithdrawlCreditHistoryModel.getMessage(), Toast.LENGTH_SHORT).show();
                                dialog.dismiss();
                            }
                        }
                    });

                }

            }
        });

        Window window = dialog.getWindow();
        window.setGravity(Gravity.CENTER);
        dialog.show();

    }

    private void debitedAmountApi() {

        viewModel.LiveDataGetPhlebotomistDriverWithdrawDetails(requireActivity(), strDriverId, strVenderId).observe(requireActivity(), new Observer<DebitedAmountListPhlebotomistModel>() {
            @Override
            public void onChanged(DebitedAmountListPhlebotomistModel debitedAmountListPhlebotomistModel) {
                if (debitedAmountListPhlebotomistModel.getSuccess().equalsIgnoreCase("1")) {
                    Toast.makeText(requireContext(), debitedAmountListPhlebotomistModel.getMessage(), Toast.LENGTH_SHORT).show();
                    debitedList = debitedAmountListPhlebotomistModel.getDetails();

                    deditedAmountAdapter = new DeditedAmountPhlebotomistAdapter(requireActivity(), debitedList);
                    recyclerview_debited_amount.setAdapter(deditedAmountAdapter);

                } else {
                    Toast.makeText(requireContext(), debitedAmountListPhlebotomistModel.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void FindId() {

        back = view.findViewById(R.id.back_image);
        requestMoney = view.findViewById(R.id.btn_request_money_lab);
        detailsMoney = view.findViewById(R.id.btn_request_money_details_lab);

        btn_tap_to_withdraw = view.findViewById(R.id.btn_tap_to_withdraw);

        txt_total_amount = view.findViewById(R.id.txt_total_amount);
        txt_credit_amount = view.findViewById(R.id.txt_credit_amount);
        txt_debit_amount = view.findViewById(R.id.txt_debit_amount);
        txt_history_details = view.findViewById(R.id.txt_history_details);

        view_credit = view.findViewById(R.id.view_credit);
        view_debit = view.findViewById(R.id.view_debit);
        view_history_details = view.findViewById(R.id.view_history_details);

        recyclerview_credited_amount = view.findViewById(R.id.recyclerview_credited_amount);
        recyclerview_debited_amount = view.findViewById(R.id.recyclerview_debited_amount);
        recyclerview_history_details = view.findViewById(R.id.recyclerview_history_details);

    }

}