package com.expert.healthkangaroodriver.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class ReferralCaseModal {
    @SerializedName("success")
    @Expose
    private String success;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("details")
    @Expose
    private List<Detail> details = null;

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<Detail> getDetails() {
        return details;
    }

    public void setDetails(List<Detail> details) {
        this.details = details;
    }
    public class Detail {

        @SerializedName("driverId")
        @Expose
        private String driverId;
        @SerializedName("hospitalId")
        @Expose
        private String hospitalId;
        @SerializedName("bookingId")
        @Expose
        private String bookingId;
        @SerializedName("latitude")
        @Expose
        private String latitude;
        @SerializedName("longitude")
        @Expose
        private String longitude;
        @SerializedName("time")
        @Expose
        private String time;
        @SerializedName("date")
        @Expose
        private String date;
        @SerializedName("ride_disassign")
        @Expose
        private String rideDisassign;
        @SerializedName("userName")
        @Expose
        private String userName;
        @SerializedName("number")
        @Expose
        private String number;
        @SerializedName("father_name")
        @Expose
        private String fatherName;
        @SerializedName("hospitalName")
        @Expose
        private String hospitalName;
        @SerializedName("HospitalLatitude")
        @Expose
        private String hospitalLatitude;
        @SerializedName("HospitalLongitude")
        @Expose
        private String hospitalLongitude;
        @SerializedName("user_address")
        @Expose
        private String userAddress;

        public String getDriverId() {
            return driverId;
        }

        public void setDriverId(String driverId) {
            this.driverId = driverId;
        }

        public String getHospitalId() {
            return hospitalId;
        }

        public void setHospitalId(String hospitalId) {
            this.hospitalId = hospitalId;
        }

        public String getBookingId() {
            return bookingId;
        }

        public void setBookingId(String bookingId) {
            this.bookingId = bookingId;
        }

        public String getLatitude() {
            return latitude;
        }

        public void setLatitude(String latitude) {
            this.latitude = latitude;
        }

        public String getLongitude() {
            return longitude;
        }

        public void setLongitude(String longitude) {
            this.longitude = longitude;
        }

        public String getTime() {
            return time;
        }

        public void setTime(String time) {
            this.time = time;
        }

        public String getDate() {
            return date;
        }

        public void setDate(String date) {
            this.date = date;
        }

        public String getRideDisassign() {
            return rideDisassign;
        }

        public void setRideDisassign(String rideDisassign) {
            this.rideDisassign = rideDisassign;
        }

        public String getUserName() {
            return userName;
        }

        public void setUserName(String userName) {
            this.userName = userName;
        }

        public String getNumber() {
            return number;
        }

        public void setNumber(String number) {
            this.number = number;
        }

        public String getFatherName() {
            return fatherName;
        }

        public void setFatherName(String fatherName) {
            this.fatherName = fatherName;
        }

        public String getHospitalName() {
            return hospitalName;
        }

        public void setHospitalName(String hospitalName) {
            this.hospitalName = hospitalName;
        }

        public String getHospitalLatitude() {
            return hospitalLatitude;
        }

        public void setHospitalLatitude(String hospitalLatitude) {
            this.hospitalLatitude = hospitalLatitude;
        }

        public String getHospitalLongitude() {
            return hospitalLongitude;
        }

        public void setHospitalLongitude(String hospitalLongitude) {
            this.hospitalLongitude = hospitalLongitude;
        }

        public String getUserAddress() {
            return userAddress;
        }

        public void setUserAddress(String userAddress) {
            this.userAddress = userAddress;
        }

    }
}
