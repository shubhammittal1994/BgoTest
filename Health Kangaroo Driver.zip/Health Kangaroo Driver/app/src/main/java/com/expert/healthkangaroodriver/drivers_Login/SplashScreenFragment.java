package com.expert.healthkangaroodriver.drivers_Login;


import android.Manifest;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import com.expert.healthkangaroodriver.AppClass.App;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.ambulance_driver.AmbulanceDriverActivity;
import com.expert.healthkangaroodriver.nursing_driver.NursingDriverActivity;
import com.expert.healthkangaroodriver.pharmacy_driver.PharmacyDriverActivity;
import com.expert.healthkangaroodriver.phlebotomist_driver.PhlebotomistDriverActivity;

public class SplashScreenFragment extends Fragment {
    private View view;
    private String strVenderId, strDriverId;
    ProgressDialog progressDialog;
    int count = 0;
    String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_splash_screen, container, false);

        progressDialog = new ProgressDialog(requireActivity());
        progressDialog.setMessage("Wait Your Location Is Fetching.....");

        strDriverId = App.getSharedPref().getStringValue("DriverId");

        startHandler();

        return view;

    }

    private void startHandler() {
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {


                if (strDriverId.length() != 0) {
                    if (App.getSharedPref().getStringValue("DriverType").equalsIgnoreCase("2")) {

                        App.getSingleton().setImage(App.getSharedPref().getStringValue("Image"));
                        App.getSingleton().setName(App.getSharedPref().getStringValue("Name"));
                        App.getSingleton().setUsername(App.getSharedPref().getStringValue("Username"));
                        App.getSingleton().setPhone(App.getSharedPref().getStringValue("Phone"));
                        App.getSingleton().setEmail(App.getSharedPref().getStringValue("Email"));
                        App.getSingleton().setAddress(App.getSharedPref().getStringValue("Address"));

                        Intent intent = new Intent(requireActivity(), PhlebotomistDriverActivity.class);
                        requireActivity().startActivity(intent);
                        requireActivity().finishAffinity();

                    } else if (App.getSharedPref().getStringValue("DriverType").equalsIgnoreCase("3")) {
                        Intent intent = new Intent(requireActivity(), NursingDriverActivity.class);
                        requireActivity().startActivity(intent);
                        requireActivity().finishAffinity();

                    } else if (App.getSharedPref().getStringValue("DriverType").equalsIgnoreCase("4")) {

                        App.getSingleton().setImage(App.getSharedPref().getStringValue("Image"));
                        App.getSingleton().setName(App.getSharedPref().getStringValue("Name"));
                        App.getSingleton().setUsername(App.getSharedPref().getStringValue("Username"));
                        App.getSingleton().setPhone(App.getSharedPref().getStringValue("Phone"));
                        App.getSingleton().setEmail(App.getSharedPref().getStringValue("Email"));
                        App.getSingleton().setAddress(App.getSharedPref().getStringValue("Address"));
                        App.getSingleton().setVehicle(App.getSharedPref().getStringValue("Vehicle"));


                        Intent intent = new Intent(requireActivity(), PharmacyDriverActivity.class);
                        requireActivity().startActivity(intent);
                        requireActivity().finishAffinity();

                    } else if (App.getSharedPref().getStringValue("DriverType").equalsIgnoreCase("5")) {

                        App.getSingleton().setImage(App.getSharedPref().getStringValue("Image"));
                        App.getSingleton().setName(App.getSharedPref().getStringValue("Name"));
                        App.getSingleton().setUsername(App.getSharedPref().getStringValue("Username"));
                        App.getSingleton().setPhone(App.getSharedPref().getStringValue("Phone"));
                        App.getSingleton().setEmail(App.getSharedPref().getStringValue("Email"));
                        App.getSingleton().setVehicle(App.getSharedPref().getStringValue("Vehicle"));
                        App.getSingleton().setAddress(App.getSharedPref().getStringValue("Address"));
                        App.getSingleton().setAge(App.getSharedPref().getStringValue("Age"));

                        Intent intent = new Intent(requireActivity(), AmbulanceDriverActivity.class);
                        requireActivity().startActivity(intent);
                        requireActivity().finishAffinity();

                    }

                } else {

                    Navigation.findNavController(view).navigate(R.id.loginScreen);
                }


            }
        }, 2000);


    }


}
