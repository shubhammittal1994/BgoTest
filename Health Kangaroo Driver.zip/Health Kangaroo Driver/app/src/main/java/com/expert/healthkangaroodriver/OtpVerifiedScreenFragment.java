package com.expert.healthkangaroodriver;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.nursing_driver.NursingDriverActivity;

public class OtpVerifiedScreenFragment extends Fragment implements View.OnClickListener {
    View view;
    Button done_buttn;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_otp_verified_screen, container, false);
        FindId();
        done_buttn.setOnClickListener(this::onClick);
        return view;
    }

    private void FindId() {
        done_buttn=view.findViewById(R.id.done_btn);
    }

    @Override
    public void onClick(View v) {

        Intent intent=new Intent(getContext(), NursingDriverActivity.class);
        startActivity(intent);

    }
}