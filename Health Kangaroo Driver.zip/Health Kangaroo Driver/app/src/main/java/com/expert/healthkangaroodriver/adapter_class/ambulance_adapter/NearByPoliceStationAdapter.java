package com.expert.healthkangaroodriver.adapter_class.ambulance_adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.expert.healthkangaroodriver.Model.ambulance_model.NearByPoliceStationListModel;
import com.example.healthkangaroo.R;

import java.util.List;

public class NearByPoliceStationAdapter extends RecyclerView.Adapter<NearByPoliceStationAdapter.ViewHolder> {
    private int lastSelectedItem = -1;
    Context context;
    private List<NearByPoliceStationListModel.Detail> policeHQList;
    PoliceStationHQSelect policeStationHQSelect;

    public NearByPoliceStationAdapter(Context context, List<NearByPoliceStationListModel.Detail> policeHQList, PoliceStationHQSelect policeStationHQSelect) {
        this.context = context;
        this.policeHQList = policeHQList;
        this.policeStationHQSelect = policeStationHQSelect;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_recycler_view_near_by_police_station_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Glide.with(context).load(policeHQList.get(position).getImage());
        holder.txt_address.setText(policeHQList.get(position).getAddress());
        holder.txt_distance.setText(policeHQList.get(position).getDistance());

        if (lastSelectedItem == position) {
            holder.linear_layout.setBackgroundResource(R.color.grey);
            policeStationHQSelect.selectedPoliceStationHS(policeHQList.get(lastSelectedItem).getId());
        } else {
            holder.linear_layout.setBackgroundResource(R.color.white);
        }
    }

    @Override
    public int getItemCount() {
        return policeHQList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView txt_name,txt_address,txt_distance;
        LinearLayout linear_layout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            linear_layout=itemView.findViewById(R.id.linear_layout);

            imageView=itemView.findViewById(R.id.imageView);
            txt_name=itemView.findViewById(R.id.txt_name);
            txt_address=itemView.findViewById(R.id.txt_address);
            txt_distance=itemView.findViewById(R.id.txt_distance);

            linear_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    lastSelectedItem = getAdapterPosition();
                    notifyDataSetChanged();
                }
            });

        }
    }

    public interface PoliceStationHQSelect{
        void selectedPoliceStationHS(String PSHQId);
    }

}
