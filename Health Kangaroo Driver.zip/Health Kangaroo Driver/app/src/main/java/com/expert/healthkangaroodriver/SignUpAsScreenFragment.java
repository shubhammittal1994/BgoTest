package com.expert.healthkangaroodriver;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.ambulance_driver.AmbulanceDriverActivity;


public class SignUpAsScreenFragment extends Fragment {
   View view;
   TextView nursing,pharmasy,phlebotomist_btn,ambulance_driver;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_signupas_screen, container, false);

        FindId();

        nursing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                Navigation.findNavController(view).navigate(R.id.action_signupasScreen_to_registrationScreen);

            }
        });

        pharmasy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                Navigation.findNavController(view).navigate(R.id.action_signupasScreen_to_registerScreenPharmsy);

            }
        });

        phlebotomist_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                Navigation.findNavController(view).navigate(R.id.action_signupasScreen_to_registerHealthKangaroo);

            }
        });

        ambulance_driver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(requireActivity(), AmbulanceDriverActivity.class);
                requireActivity().startActivity(intent);
            }
        });

        return view;
    }

    private void FindId() {

        nursing=view.findViewById(R.id.nursng);
        pharmasy=view.findViewById(R.id.phrmsy);
        phlebotomist_btn=view.findViewById(R.id.phlebo);
        ambulance_driver=view.findViewById(R.id.ambulance_driver);

    }
}