package com.expert.healthkangaroodriver.phlebotomist_driver;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.LogoutPhlebotomistModel;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.OnOffStatusLabDriverModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.OnlineOffLineLabModel;
import com.expert.healthkangaroodriver.drivers_Login.MainStartingActivity;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;
import com.github.angads25.toggle.interfaces.OnToggledListener;
import com.github.angads25.toggle.model.ToggleableView;
import com.github.angads25.toggle.widget.LabeledSwitch;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.io.IOException;
import java.util.List;


public class HomePhlebotomistFragment extends Fragment implements OnMapReadyCallback {
    private View view;
    private ImageView mImageView, img_profile_pic, img_get_current_location;
    private TextView txt_profile_name, txt_driver_address, txt_online, txt_offline;
    private ViewModelClass viewModel;
    private String strVenderId, strDriverId;
    private LabeledSwitch switch_before;
    private Address address;
    private GoogleMap mMap;
    private String[] perms = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.INTERNET};
    private int permissionCode = 123;
    private Geocoder geocoder;
    private LatLng latLng;
    public static double myLat, myLng;
    String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
    FusedLocationProviderClient fusedLocationProviderClient;
    private double lat = 0.00, log = 0.00;
    LocationManager locationManager;
    private Location location;
    private ImageView btn_call;
    private AppCompatButton sampleCollectionBtn;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_phlebotomist_home, container, false);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(requireContext());
        locationManager = (LocationManager) requireActivity().getSystemService(Context.LOCATION_SERVICE);

        if (ActivityCompat.checkSelfPermission(requireActivity(), ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireActivity(), ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(requireContext(), "permission Check", Toast.LENGTH_SHORT).show();
            ActivityCompat.requestPermissions(requireActivity(), permissions, 10);
        } else {

            getCurrentLocation();

        }

        SupportMapFragment mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.mapPhlebotomist);

        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        findID();
        geocoder = new Geocoder(requireContext());
        viewModel = new ViewModelClass();

        strDriverId = App.getSharedPref().getStringValue("DriverId");
        strVenderId = App.getSharedPref().getStringValue("VenderId");

        setData();
        onOffStatus();
        switchCondition();
        navigationMenuHandler();
        onClick();

        return view;
    }

    private void onOffStatus() {
        viewModel.onOffStatusLabDriverModelLiveData(requireActivity(), strDriverId).observe(requireActivity(), new Observer<OnOffStatusLabDriverModel>() {
            @Override
            public void onChanged(OnOffStatusLabDriverModel onOffStatusLabDriverModel) {
                if (onOffStatusLabDriverModel.getSuccess().equalsIgnoreCase("1")){
                    if (onOffStatusLabDriverModel.getMessage().getOnOffStatus().equalsIgnoreCase("1")){
                        switch_before.setOn(true);
                        txt_offline.setVisibility(View.GONE);
                        txt_online.setVisibility(View.VISIBLE);
                    }else {
                        switch_before.setOn(false);
                    }

                }
            }
        });
    }

    private void switchCondition() {

        switch_before.setOnToggledListener(new OnToggledListener() {
            @Override
            public void onSwitched(ToggleableView toggleableView, boolean isOn) {
                if (switch_before.isOn()){
                    txt_offline.setVisibility(View.GONE);
                    txt_online.setVisibility(View.VISIBLE);
                    hitApiOnLineStatus("online", strVenderId, strDriverId, lat, log);
                }else {
                    hitApiOnLineStatus("offline", strVenderId, strDriverId, lat, log);

                    txt_offline.setVisibility(View.VISIBLE);
                    txt_online.setVisibility(View.GONE);

                }
            }
        });

    }
    private void hitApiOnLineStatus(String type, String strVenderId, String strDriverId, double lat, double log) {
        viewModel.onlineOffLineLabModelLiveData(requireActivity(),type, strVenderId, strDriverId, Double.toString(lat), Double.toString(log)).observe(requireActivity(), new Observer<OnlineOffLineLabModel>() {
            @Override
            public void onChanged(OnlineOffLineLabModel onlineOffLineLabModel) {
                if (onlineOffLineLabModel.getSuccess().equalsIgnoreCase("1")){

                        Toast.makeText(requireContext(), onlineOffLineLabModel.getMessage(), Toast.LENGTH_SHORT).show();

                } else {

                    Toast.makeText(requireContext(), onlineOffLineLabModel.getMessage(), Toast.LENGTH_SHORT).show();

                }
            }
        });

    }
    private void onClick() {

        btn_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Toast.makeText(requireActivity(), "Call Clicked", Toast.LENGTH_SHORT).show();
            }
        });

        sampleCollectionBtn.setOnClickListener(v -> {

            Bundle bundle = new Bundle();
            bundle.putString("My Latitue", String.valueOf(lat));
            bundle.putString("My Longitude", String.valueOf(log));
            Navigation.findNavController(view).navigate(R.id.action_mapscreenDrawerLayout_to_myDeliveries, bundle);

        });



        img_get_current_location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 18);

                mMap.animateCamera(cameraUpdate);


            }
        });

    }
    private void setData() {

        txt_profile_name.setText(App.getSingleton().getName());
        txt_driver_address.setText(App.getSingleton().getAddress());
        Glide.with(view).load(App.getSharedPref().getStringValue("Image")).into(img_profile_pic);

    }
    private void findID() {

        btn_call = view.findViewById(R.id.btn_call);

        txt_profile_name = view.findViewById(R.id.txt_profile_name);
        img_profile_pic = view.findViewById(R.id.img_profile_pic_phelo);
        txt_driver_address = view.findViewById(R.id.txt_driver_address);
        txt_online = view.findViewById(R.id.txt_online);
        txt_offline = view.findViewById(R.id.txt_offline);
        switch_before = view.findViewById(R.id.switch_phlebotomist);
        img_get_current_location = view.findViewById(R.id.img_get_current_location);
        sampleCollectionBtn = view.findViewById(R.id.sample_collection_lab);

    }
    private void navigationMenuHandler() {

        DrawerLayout drawerLayout = view.findViewById(R.id.my_drawer_layout);
        NavigationView navigationView = view.findViewById(R.id.navigation_drawer_pharmacy);
        mImageView = view.findViewById(R.id.toolbar1);

        mImageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });


//        View headerView = navigationView.inflateHeaderView(R.layout.header_layout2);
        View headerView = navigationView.getHeaderView(0);
        TextView drawerName = headerView.findViewById(R.id.txt_name_drawer);
        ImageView drawerImage = headerView.findViewById(R.id.img_profile_pic_drawer);

        drawerName.setText(App.getSingleton().getName());
        Glide.with(view).load(App.getSingleton().getImage()).into(drawerImage);


        Menu menuNav = navigationView.getMenu();

        MenuItem myprofile, mydeliveries, mywallet, about, termsAndConditions, report, logout;
        myprofile = menuNav.findItem(R.id.item_myprofile);
        mydeliveries = menuNav.findItem(R.id.my_history);
        mywallet = menuNav.findItem(R.id.my_wallet);
        about = menuNav.findItem(R.id.about);
        termsAndConditions = menuNav.findItem(R.id.terms_conditions);
        report = menuNav.findItem(R.id.report);
        logout = menuNav.findItem(R.id.logout);


        mydeliveries.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Navigation.findNavController(view).navigate(R.id.historyLabFragment);

                return true;
            }
        });

        myprofile.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                Navigation.findNavController(view).navigate(R.id.action_mapscreenDrawerLayout_to_myProfile);
                return true;
            }
        });

        termsAndConditions.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                Navigation.findNavController(view).navigate(R.id.termAndConditionLabFragment);
                return true;
            }
        });
        about.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                Navigation.findNavController(view).navigate(R.id.aboutLabFragment);
                return true;
            }
        });

        mywallet.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Navigation.findNavController(view).navigate(R.id.action_mapscreenDrawerLayout_to_wallet);
                return true;
            }
        });


        report.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                final Dialog dialog = new Dialog(requireActivity());
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.call_layout);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

                ImageView call_btn = dialog.findViewById(R.id.call_btn_call);
                ImageView email_btn = dialog.findViewById(R.id.mail_btn);
                TextView call_txt = dialog.findViewById(R.id.call_txt);

                call_btn.setOnClickListener(v -> {

                    Intent callIntent = new Intent(Intent.ACTION_CALL);
                    callIntent.setData(Uri.parse("tel:" + call_txt.getText().toString()));
                    startActivity(callIntent);
                    dialog.dismiss();

                });

                email_btn.setOnClickListener(v -> {
                    final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
                    emailIntent.setType("plain/text");
                    emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"Test123@gmail.com"});
                    emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject");
                    emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Text");
                    requireActivity().startActivity(Intent.createChooser(emailIntent, "Send mail..."));
                    dialog.dismiss();

                });

                dialog.show();





                return false;
            }
        });


        logout.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {


                AlertDialog.Builder alert = new AlertDialog.Builder(requireActivity());
                alert.setIcon(R.drawable.ic_warning).setTitle("Logout");
                alert.setMessage("Do you want to logout?");

                alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        viewModel.LiveDataLogoutPhlebotomist(requireActivity(), strVenderId, strDriverId).observe(requireActivity(), new Observer<LogoutPhlebotomistModel>() {
                            @Override
                            public void onChanged(LogoutPhlebotomistModel logoutPhlebotomistModel) {
                                if (logoutPhlebotomistModel.getSuccess().equalsIgnoreCase("1")) {

                                    App.getSharedPref().clearPreferences();

                                    Toast.makeText(requireContext(), logoutPhlebotomistModel.getMessage(), Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(requireActivity(), MainStartingActivity.class);
                                    requireActivity().startActivity(intent);

                                }
                            }
                        });

                    }
                });

                alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                alert.show();


                return true;
            }
        });

    }
    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
        try {
            List<Address> addressList = geocoder.getFromLocation(App.getSingleton().getLat(), App.getSingleton().getLog(), 1);

            address = addressList.get(0);
            myLat = address.getLatitude();
            myLng = address.getLongitude();


            latLng = new LatLng(address.getLatitude(), address.getLongitude());
//            markerOptions = new MarkerOptions().position(latLng).title(address.getLocality());
//            currentAddress = address.getAddressLine(0);

//            mMap.addMarker(markerOptions.title(currentAddress));
//            CircleOptions circleOptions = new CircleOptions().center(latLng);
//            mMap.addCircle(circleOptions);

            if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                    && ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                // TODO: Consider calling
                //    ActivityCompat#requestPermissions
                // here to request the missing permissions, and then overriding
                //   public void onRequestPermissionsResult(int requestCode, String[] permissions,\\
                requestPermissions(perms, permissionCode);
                //                                          int[] grantResults)
                // to handle the case where the user grants the permission. See the documentation
                // for ActivityCompat#requestPermissions for more details.
                return;
            }
            mMap.setMyLocationEnabled(true);

            mMap.getUiSettings().setMyLocationButtonEnabled(false);
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 18);


            mMap.animateCamera(cameraUpdate);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    private void getCurrentLocation() {


        if (ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(requireActivity(),
                        Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(requireActivity(), permissions, 10);
        }

        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {


            fusedLocationProviderClient.getLastLocation().addOnCompleteListener(new OnCompleteListener<Location>() {
                @Override
                public void onComplete(@NonNull Task<Location> task) {
                    location = task.getResult();

                    if (location != null) {
                        lat = location.getLatitude();

                        log = location.getLongitude();


                    } else {

                        LocationRequest locationRequest = new LocationRequest().setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY).setInterval(1000).setFastestInterval(1000).setNumUpdates(1);

                        LocationCallback locationCallback = new LocationCallback() {
                            @Override
                            public void onLocationResult(@NonNull LocationResult locationResult) {
                                super.onLocationResult(locationResult);

                                Location location1 = locationResult.getLastLocation();
                                lat = location.getLatitude();

                                log = location.getLongitude();
                            }
                        };

                        if (ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireActivity(),
                                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(requireActivity(), permissions, 10);

                        }
                        fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());

                    }


                }
            });


        } else {
//            startActivity(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK));

            Toast.makeText(requireActivity(), "Turn on location", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
            startActivity(intent);
//        }
        }
    }
    @Override
    public void onResume() {
        super.onResume();

        if (ActivityCompat.checkSelfPermission(requireActivity(), ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireActivity(), ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(requireContext(), "permission Check", Toast.LENGTH_SHORT).show();
            ActivityCompat.requestPermissions(requireActivity(), permissions, 10);
        } else {
            getCurrentLocation();

        }

    }
}