package com.expert.healthkangaroodriver.adapter_class.pharmacy_adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.pharmacy_model.PharmacyDeliveryModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.PhlebotomistDriverSampleCollectionModel;
import com.expert.healthkangaroodriver.adapter_class.nursing_adapters.NursingOrderListAdapter;
import com.expert.healthkangaroodriver.adapter_class.phlebotomist_adapters.PhlebotomistSampleCollectionAdapter;

import java.util.List;


public class PharmacyDeliveriesAdapter extends RecyclerView.Adapter<PharmacyDeliveriesAdapter.ViewHolder> {
    Context context;
    private final List<PharmacyDeliveryModel.Detail> sampleList;
    Delivery select;
    StartDeliveryPositionPharmacy startDeliveryPosition;
    private int latestIndex;

    public interface Delivery {

        void details(PharmacyDeliveryModel.Detail detail);

    }

    public PharmacyDeliveriesAdapter(Context context, List<PharmacyDeliveryModel.Detail> sampleList, Delivery select, StartDeliveryPositionPharmacy startDeliveryPosition) {
        this.context = context;
        this.sampleList = sampleList;
        this.select = select;
        this.startDeliveryPosition = startDeliveryPosition;
    }

    @NonNull
    @Override
    public PharmacyDeliveriesAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_order_list, parent, false);
        return new ViewHolder(view);

    }

    @Override
    public void onBindViewHolder(@NonNull PharmacyDeliveriesAdapter.ViewHolder holder, @SuppressLint("RecyclerView") int position) {


        holder.txt_appointment_number.setText(sampleList.get(position).getOrderId());
        holder.txt_patience_name.setText(sampleList.get(position).getName());
        holder.txt_patience_phone.setText(sampleList.get(position).getPhone());
        holder.txt_patience_address.setText(sampleList.get(position).getAddress());


        latestIndex = position;

        if (latestIndex == 0) {
            holder.pending_order_btn.setVisibility(View.GONE);
            holder.start_btn.setVisibility(View.VISIBLE);

            holder.start_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Bundle bundle = new Bundle();
                    bundle.putString("Patience Name", sampleList.get(position).getName());
                    bundle.putString("Patience Phone", sampleList.get(position).getPhone());
                    bundle.putString("Patience Address", sampleList.get(position).getAddress());
                    bundle.putString("Patience Latitude", sampleList.get(position).getLatitude());
                    bundle.putString("Patience Longitude", sampleList.get(position).getLongitude());

                    startDeliveryPosition.startPosition(sampleList.get(position).getOrderId(),sampleList.get(position).getLatitude(),sampleList.get(position).getLongitude(), sampleList.get(position).getAddress(),sampleList.get(position).getPhone());

                    select.details(sampleList.get(position));
                }
            });

        }
       else {
            holder.pending_order_btn.setVisibility(View.VISIBLE);
            holder.start_btn.setVisibility(View.GONE);

            holder.pending_order_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Bundle bundle = new Bundle();
                    bundle.putString("Name", sampleList.get(position).getName());
                    bundle.putString("Phone", sampleList.get(position).getPhone());
                    bundle.putString("Address", sampleList.get(position).getAddress());
                    bundle.putString("OrderId", sampleList.get(position).getOrderId());
                    bundle.putString("OrderAmount", sampleList.get(position).getPrice());

                    Navigation.findNavController(v).navigate(R.id.inprogressScreenPharmsy, bundle);
                }
            });


        }


    }

    @Override
    public int getItemCount() {

        return sampleList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt_appointment_number, txt_patience_name, txt_patience_phone, txt_patience_address;
        Button start_btn, pending_order_btn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txt_appointment_number = itemView.findViewById(R.id.txt_appointment_number);
            txt_patience_name = itemView.findViewById(R.id.txt_patience_name);
            txt_patience_phone = itemView.findViewById(R.id.txt_patience_phone);
            txt_patience_address = itemView.findViewById(R.id.txt_patience_address);
            start_btn = itemView.findViewById(R.id.start_btn);
            pending_order_btn = itemView.findViewById(R.id.pending_order_btn);
        }
    }
    public interface StartDeliveryPositionPharmacy{
        void startPosition(String appointmentNo,String patientLat,String patientLng,String patientAddress,String patientPhone);
    }
}
