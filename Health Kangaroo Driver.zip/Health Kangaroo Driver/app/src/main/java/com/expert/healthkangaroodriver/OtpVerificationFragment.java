package com.expert.healthkangaroodriver;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.healthkangaroo.R;


public class OtpVerificationFragment extends Fragment {

    View view;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_otp_verification, container, false);

        FindId();

        return  view;
    }

    private void FindId() {

        view.findViewById(R.id.submit_otp_button).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(view).navigate(R.id.action_otpVerification_to_profileVerification);
            }
        });

    }
}