package com.expert.healthkangaroodriver.phlebotomist_driver;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;

import android.provider.MediaStore;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.ExistingEmailPhoneMatchPhlebotomistModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.NewEmailPhoneCheckPhlebotomistModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.UpdateEmailPhlebotomistModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.UpdatePhonePhlebotomistModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.UpdateProfilePhlebotomistModel;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;

import java.io.ByteArrayOutputStream;
import java.io.File;

import in.aabhasjindal.otptextview.OtpTextView;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;


public class UpdateMyProfilePhlebotomistFragment extends Fragment {
    private View view;
    private ImageView img_back, img_profile_pic, img_add;
    private EditText edtxt_address;
    private TextView txt_email, txt_phone_number, txt_verify_phone, txt_verify_email;
    private Button btn_save;
    private Dialog dialogOtp, dialogEmailPhone, dialogNewOtp;
    private String imagePath, strAddress, strDriverId, strVenderID, image, phone, email, address;
    private RequestBody rb_address, rb_driverId, rb_venderId;
    private MultipartBody.Part rb_image;
    private ViewModelClass viewModel;
    private ProgressDialog progressDialog;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_my_profile_update_phlebotomist, container, false);


        progressDialog = new ProgressDialog(requireActivity());
        progressDialog.setMessage("Updating profile...");

        findIds();

        viewModel = new ViewModelClass();

        strDriverId = App.getSharedPref().getStringValue("DriverId");
        strVenderID = App.getSharedPref().getStringValue("VenderId");


        onVerifyTextClicked();
        setData();
        onClick();


        return view;
    }

    private void onVerifyTextClicked() {

        txt_verify_phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.setMessage("Loading.....");
                progressDialog.show();

                //old phone exist api hit

                viewModel.liveDataExistingEmailPhonePhlebotomist(requireActivity(), strVenderID, strDriverId, phone).observe(requireActivity(), new Observer<ExistingEmailPhoneMatchPhlebotomistModel>() {
                    @Override
                    public void onChanged(ExistingEmailPhoneMatchPhlebotomistModel existingEmailPhoneMatchModel) {
                        if (existingEmailPhoneMatchModel.getSuccess().equalsIgnoreCase("1")) {

                            progressDialog.dismiss();
                            Toast.makeText(requireActivity(), existingEmailPhoneMatchModel.getDetail(), Toast.LENGTH_LONG).show();


                            TextView txt_phone_ll = dialogOtp.findViewById(R.id.txt_phone_ll);
                            txt_phone_ll.setText(phone);

                            Button btn_submit_otp = dialogOtp.findViewById(R.id.btn_submit_otp);

                            btn_submit_otp.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    //otp match
                                    OtpTextView otp_view = dialogOtp.findViewById(R.id.otp_view);

                                    String otpStr = otp_view.getOTP();

                                    if (otpStr.equalsIgnoreCase("")) {
                                        Toast.makeText(requireActivity(), "Enter OTP", Toast.LENGTH_SHORT).show();
                                    } else if (!existingEmailPhoneMatchModel.getDetail().matches(otpStr)) {
                                        Toast.makeText(requireContext(), "Please,enter correct OTP.", Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(requireActivity(), "Otp Matched", Toast.LENGTH_SHORT).show();

                                        dialogOtp.dismiss();

                                        dialogEmailPhone = new Dialog(getContext());
                                        dialogEmailPhone.setContentView(R.layout.layout_email_phone_phlebotomist);
                                        dialogEmailPhone.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                                        dialogEmailPhone.setCanceledOnTouchOutside(true);

                                        LinearLayout ll_phone_submit_dialog = dialogEmailPhone.findViewById(R.id.ll_phone_submit_dialog);
                                        LinearLayout ll_email_submit_dialog = dialogEmailPhone.findViewById(R.id.ll_email_submit_dialog);

                                        ll_email_submit_dialog.setVisibility(View.GONE);
                                        ll_phone_submit_dialog.setVisibility(View.VISIBLE);

                                        EditText editxt_phone_dialog_submit = dialogEmailPhone.findViewById(R.id.editxt_phone_dialog_submit);


                                        Button btn_submit_email_phone_dialog = dialogEmailPhone.findViewById(R.id.btn_submit_email_phone_dialog);
                                        btn_submit_email_phone_dialog.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {

                                                //new phone api hit
                                                String strPhone = editxt_phone_dialog_submit.getText().toString().trim();

                                                if (strPhone.equalsIgnoreCase("")) {
                                                    editxt_phone_dialog_submit.setError("Enter Phone Number");
                                                } else if (strPhone.length() != 10) {
                                                    editxt_phone_dialog_submit.setError("Enter 10 digits Phone Number");
                                                } else {


                                                    viewModel.LiveDataNewEmailPhoneCheckPhlebotomist(requireActivity(), strVenderID, strDriverId, strPhone).observe(requireActivity(), new Observer<NewEmailPhoneCheckPhlebotomistModel>() {
                                                        @Override
                                                        public void onChanged(NewEmailPhoneCheckPhlebotomistModel newEmailPhoneCheckModel) {
                                                            if (newEmailPhoneCheckModel.getSuccess().equalsIgnoreCase("1")) {

                                                                Toast.makeText(requireActivity(), newEmailPhoneCheckModel.getDetail(), Toast.LENGTH_LONG).show();

                                                                dialogEmailPhone.dismiss();

                                                                dialogNewOtp = new Dialog(getContext());
                                                                dialogNewOtp.setContentView(R.layout.layout_otp_phlebotomist);
                                                                dialogNewOtp.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                                                                dialogNewOtp.setCanceledOnTouchOutside(true);


                                                                LinearLayout ll_phone_dialog = dialogNewOtp.findViewById(R.id.ll_phone_dialog);
                                                                LinearLayout ll_email_dialog = dialogNewOtp.findViewById(R.id.ll_email_dialog);

                                                                ll_phone_dialog.setVisibility(View.VISIBLE);
                                                                ll_email_dialog.setVisibility(View.GONE);

                                                                TextView txt_phone_ll = dialogNewOtp.findViewById(R.id.txt_phone_ll);
                                                                txt_phone_ll.setText(strPhone);


                                                                Button btn_submit_otp = dialogNewOtp.findViewById(R.id.btn_submit_otp);

                                                                btn_submit_otp.setOnClickListener(new View.OnClickListener() {
                                                                    @Override
                                                                    public void onClick(View v) {
                                                                        //new otp match and phone no. update api
                                                                        OtpTextView otp_view = dialogNewOtp.findViewById(R.id.otp_view);

                                                                        String otpStr = otp_view.getOTP();

                                                                        if (otpStr.equalsIgnoreCase("")) {
                                                                            Toast.makeText(requireActivity(), "Please,Enter OTP", Toast.LENGTH_SHORT).show();
                                                                        } else if (!newEmailPhoneCheckModel.getDetail().matches(otpStr)) {
                                                                            Toast.makeText(requireActivity(), "Enter Correct otp", Toast.LENGTH_SHORT).show();
                                                                        } else {

                                                                            viewModel.LiveDataUpdatePhonePhlebotomist(requireActivity(), strVenderID, strDriverId, strPhone).observe(requireActivity(), new Observer<UpdatePhonePhlebotomistModel>() {
                                                                                @Override
                                                                                public void onChanged(UpdatePhonePhlebotomistModel updatePhonePhlebotomistModel) {
                                                                                    if (updatePhonePhlebotomistModel.getSuccess().equalsIgnoreCase("1")) {

                                                                                        dialogNewOtp.dismiss();

                                                                                        App.getSingleton().setPhone(strPhone);
                                                                                        txt_phone_number.setText(strPhone);
                                                                                        Toast.makeText(requireContext(), updatePhonePhlebotomistModel.getMessage(), Toast.LENGTH_SHORT).show();
                                                                                    }
                                                                                }
                                                                            });

                                                                        }
                                                                    }
                                                                });

                                                                Window window = dialogNewOtp.getWindow();
                                                                window.setGravity(Gravity.CENTER);
                                                                dialogNewOtp.show();

                                                            } else {
                                                                Toast.makeText(requireContext(), newEmailPhoneCheckModel.getMessage(), Toast.LENGTH_SHORT).show();
                                                            }
                                                        }
                                                    });

                                                }

                                            }
                                        });

                                        Window window = dialogEmailPhone.getWindow();
                                        window.setGravity(Gravity.CENTER);
                                        dialogEmailPhone.show();
                                    }
                                }
                            });

                            Window window = dialogOtp.getWindow();
                            window.setGravity(Gravity.CENTER);
                            dialogOtp.show();
                        } else {
                            Toast.makeText(requireActivity(), existingEmailPhoneMatchModel.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });

            }
        });

        txt_verify_email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.setMessage("Loading.....");
                progressDialog.show();

                //old email match api hit

                viewModel = new ViewModelClass();
                viewModel.liveDataExistingEmailPhonePhlebotomist(requireActivity(), strVenderID, strDriverId, email).observe(requireActivity(), new Observer<ExistingEmailPhoneMatchPhlebotomistModel>() {
                    @Override
                    public void onChanged(ExistingEmailPhoneMatchPhlebotomistModel existingEmailPhoneMatchModel) {
                        if (existingEmailPhoneMatchModel.getSuccess().equalsIgnoreCase("1")) {

                            progressDialog.dismiss();

                            Toast.makeText(requireActivity(), existingEmailPhoneMatchModel.getDetail(), Toast.LENGTH_LONG).show();


                            dialogOtp = new Dialog(getContext());
                            dialogOtp.setContentView(R.layout.layout_otp_phlebotomist);
                            dialogOtp.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                            dialogOtp.setCanceledOnTouchOutside(true);


                            LinearLayout ll_phone_dialog = dialogOtp.findViewById(R.id.ll_phone_dialog);
                            LinearLayout ll_email_dialog = dialogOtp.findViewById(R.id.ll_email_dialog);

                            ll_phone_dialog.setVisibility(View.GONE);
                            ll_email_dialog.setVisibility(View.VISIBLE);

                            TextView txt_email_ll = dialogOtp.findViewById(R.id.txt_email_ll);
                            txt_email_ll.setText(email);


                            Button btn_submit_otp = dialogOtp.findViewById(R.id.btn_submit_otp);

                            btn_submit_otp.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {

                                    //otp match api hit
                                    OtpTextView otp_view = dialogOtp.findViewById(R.id.otp_view);

                                    String otpStr = otp_view.getOTP();

                                    if (otpStr.equalsIgnoreCase("")) {
                                        Toast.makeText(requireActivity(), "Enter OTP", Toast.LENGTH_SHORT).show();
                                    } else if (!existingEmailPhoneMatchModel.getDetail().equalsIgnoreCase(otpStr)) {
                                        Toast.makeText(requireActivity(), "Please,Enter correct Otp", Toast.LENGTH_SHORT).show();
                                    } else {

                                        dialogOtp.dismiss();

                                        dialogEmailPhone = new Dialog(getContext());
                                        dialogEmailPhone.setContentView(R.layout.layout_email_phone_phlebotomist);
                                        dialogEmailPhone.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                                        dialogEmailPhone.setCanceledOnTouchOutside(true);

                                        LinearLayout ll_phone_submit_dialog = dialogEmailPhone.findViewById(R.id.ll_phone_submit_dialog);
                                        LinearLayout ll_email_submit_dialog = dialogEmailPhone.findViewById(R.id.ll_email_submit_dialog);

                                        ll_email_submit_dialog.setVisibility(View.VISIBLE);
                                        ll_phone_submit_dialog.setVisibility(View.GONE);

                                        EditText editxt_email_dialog_submit = dialogEmailPhone.findViewById(R.id.editxt_email_dialog_submit);


                                        Button btn_submit_email_phone_dialog = dialogEmailPhone.findViewById(R.id.btn_submit_email_phone_dialog);
                                        btn_submit_email_phone_dialog.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {
                                                //new email api hit

                                                String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";
                                                String strEmail = editxt_email_dialog_submit.getText().toString();

                                                if (strEmail.equalsIgnoreCase("")) {
                                                    editxt_email_dialog_submit.setError("Enter Phone Number");
                                                } else if (!strEmail.matches(emailPattern)) {
                                                    editxt_email_dialog_submit.setError("Enter Correct Email formate ");
                                                } else {

                                                    viewModel.LiveDataNewEmailPhoneCheckPhlebotomist(requireActivity(), strVenderID, strDriverId, strEmail).observe(requireActivity(), new Observer<NewEmailPhoneCheckPhlebotomistModel>() {
                                                        @Override
                                                        public void onChanged(NewEmailPhoneCheckPhlebotomistModel newEmailPhoneCheckModel) {
                                                            if (newEmailPhoneCheckModel.getSuccess().equalsIgnoreCase("1")) {

                                                                Toast.makeText(requireActivity(), newEmailPhoneCheckModel.getDetail(), Toast.LENGTH_SHORT).show();

                                                                dialogEmailPhone.dismiss();

                                                                dialogNewOtp = new Dialog(getContext());
                                                                dialogNewOtp.setContentView(R.layout.layout_otp_phlebotomist);
                                                                dialogNewOtp.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                                                                dialogNewOtp.setCanceledOnTouchOutside(true);


                                                                LinearLayout ll_phone_dialog = dialogNewOtp.findViewById(R.id.ll_phone_dialog);
                                                                LinearLayout ll_email_dialog = dialogNewOtp.findViewById(R.id.ll_email_dialog);

                                                                ll_phone_dialog.setVisibility(View.GONE);
                                                                ll_email_dialog.setVisibility(View.VISIBLE);

                                                                TextView txt_email_ll = dialogNewOtp.findViewById(R.id.txt_email_ll);
                                                                txt_email_ll.setText(strEmail);


                                                                OtpTextView otp_view = dialogNewOtp.findViewById(R.id.otp_view);
                                                                Button btn_submit_otp = dialogNewOtp.findViewById(R.id.btn_submit_otp);

                                                                btn_submit_otp.setOnClickListener(new View.OnClickListener() {
                                                                    @Override
                                                                    public void onClick(View v) {
                                                                        //new otp match api and update email api hit

                                                                        OtpTextView otp_view = dialogNewOtp.findViewById(R.id.otp_view);

                                                                        String otpStr = otp_view.getOTP();

                                                                        if (otpStr.equalsIgnoreCase("")) {
                                                                            Toast.makeText(requireActivity(), "Please,Enter OTP", Toast.LENGTH_SHORT).show();
                                                                        } else if (!newEmailPhoneCheckModel.getDetail().matches(otpStr)) {
                                                                            Toast.makeText(requireActivity(), "Enter Correct otp", Toast.LENGTH_SHORT).show();
                                                                        } else {


                                                                            viewModel.liveDataUpdateEmailPhlebotomist(requireActivity(), strVenderID, strDriverId, strEmail).observe(requireActivity(), new Observer<UpdateEmailPhlebotomistModel>() {
                                                                                @Override
                                                                                public void onChanged(UpdateEmailPhlebotomistModel updateEmailPhlebotomistModel) {
                                                                                    if (updateEmailPhlebotomistModel.getSuccess().equalsIgnoreCase("1")) {

                                                                                        dialogNewOtp.dismiss();

                                                                                        App.getSingleton().setEmail(strEmail);
                                                                                        txt_email.setText(strEmail);
                                                                                        Toast.makeText(requireContext(), updateEmailPhlebotomistModel.getMessage(), Toast.LENGTH_SHORT).show();
                                                                                    }
                                                                                }
                                                                            });
                                                                        }
                                                                    }
                                                                });


                                                                Window window = dialogNewOtp.getWindow();
                                                                window.setGravity(Gravity.CENTER);
                                                                dialogNewOtp.show();


                                                            } else {
                                                                Toast.makeText(requireActivity(), newEmailPhoneCheckModel.getMessage(), Toast.LENGTH_SHORT).show();
                                                            }
                                                        }
                                                    });


                                                }

                                            }
                                        });

                                        Window window = dialogEmailPhone.getWindow();
                                        window.setGravity(Gravity.CENTER);
                                        dialogEmailPhone.show();

                                    }
                                }
                            });

                            Window window = dialogOtp.getWindow();
                            window.setGravity(Gravity.CENTER);
                            dialogOtp.show();

                        } else {
                            Toast.makeText(requireActivity(), existingEmailPhoneMatchModel.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });


            }
        });

    }

    private void setData() {
        image = App.getSingleton().getImage();
        phone = App.getSingleton().getPhone();
        email = App.getSingleton().getEmail();
        address = App.getSingleton().getAddress();

        Glide.with(view).load(image).into(img_profile_pic);
        txt_phone_number.setText(phone);
        txt_email.setText(email);
        edtxt_address.setText(address);
    }


    private void onClick() {

        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requireActivity().onBackPressed();
            }
        });

        img_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialogOtp = new Dialog(requireActivity());
                dialogOtp.setContentView(R.layout.layout_image_picker);
                dialogOtp.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
                dialogOtp.setCanceledOnTouchOutside(true);

                LinearLayout ll_camera = dialogOtp.findViewById(R.id.ll_camera);
                LinearLayout ll_gallery = dialogOtp.findViewById(R.id.ll_gallery);

                ll_camera.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent openCamera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        startActivityForResult(openCamera, 1);
                    }
                });

                ll_gallery.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent openGallery = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                        startActivityForResult(openGallery, 2);
                    }
                });

                Window window = dialogOtp.getWindow();
                window.setGravity(Gravity.CENTER);
                dialogOtp.show();

            }
        });

        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                progressDialog.show();

                strAddress = edtxt_address.getText().toString();

                if (imagePath == null && image == null) {
                    Toast.makeText(requireActivity(), "Please,Select Image", Toast.LENGTH_SHORT).show();
                } else if (strAddress.equalsIgnoreCase("")) {
                    edtxt_address.setError("Field can't be empty");
                } else {


                    viewModel = new ViewModelClass();

                    if (imagePath != null) {
                        File file = new File(imagePath);
                        final RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), file);
                        rb_image = MultipartBody.Part.createFormData("image", file.getName(), requestFile);
                    } else {
                        final RequestBody requestFile = RequestBody.create(MediaType.parse("image/*"), "");
                        rb_image = MultipartBody.Part.createFormData("image", "", requestFile);
                    }


                    rb_venderId = RequestBody.create(MediaType.parse("text/plain"), strVenderID);
                    rb_address = RequestBody.create(MediaType.parse("text/plain"), strAddress);
                    rb_driverId = RequestBody.create(MediaType.parse("text/plain"), strDriverId);


                    viewModel.liveDataUpdateProfilePhlebotomist(requireActivity(), rb_venderId, rb_address, rb_image, rb_driverId).observe(requireActivity(), new Observer<UpdateProfilePhlebotomistModel>() {
                        @Override
                        public void onChanged(UpdateProfilePhlebotomistModel updateProfilePhlebotomistModel) {
                            if (updateProfilePhlebotomistModel.getSuccess().equalsIgnoreCase("1")) {

                                progressDialog.dismiss();
                                App.getSingleton().setImage(updateProfilePhlebotomistModel.getDetails().getImage());
                                App.getSingleton().setPhone(updateProfilePhlebotomistModel.getDetails().getPhone());
                                App.getSingleton().setEmail(updateProfilePhlebotomistModel.getDetails().getEmail());
                                App.getSingleton().setAddress(updateProfilePhlebotomistModel.getDetails().getAddress());

                                requireActivity().onBackPressed();
                                Toast.makeText(requireActivity(), updateProfilePhlebotomistModel.getMessage(), Toast.LENGTH_SHORT).show();
                            } else {
                                progressDialog.dismiss();
                                Toast.makeText(requireActivity(), updateProfilePhlebotomistModel.getMessage(), Toast.LENGTH_SHORT).show();
                            }

                        }
                    });

                }

            }
        });

    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && data != null) {
            Bitmap photo = (Bitmap) data.getExtras().get("data");
            img_profile_pic.setImageBitmap(photo);

            Uri uri = getImageUri(requireContext(), photo);
            imagePath = getPathFromURI(uri);

            dialogOtp.dismiss();

        } else if (requestCode == 2 && null != data) {
            Uri selected = data.getData();
            Glide.with(this).load(selected).into(img_profile_pic);

            imagePath = getPathFromURI(selected);

            dialogOtp.dismiss();
        }
    }

    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    private String getPathFromURI(Uri selected) {

        String path;
        Cursor cursor = requireActivity().getContentResolver().query(selected, null, null, null, null);
        if (cursor == null)
            path = selected.getPath();
        else {
            cursor.moveToFirst();
            int index = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA);
            path = cursor.getString(index);
        }
        if (cursor != null) {
            cursor.close();
        }
        return path;
    }


    private void findIds() {

        img_back = view.findViewById(R.id.img_back);
        img_profile_pic = view.findViewById(R.id.img_profile_pic);
        img_add = view.findViewById(R.id.img_add);

        txt_phone_number = view.findViewById(R.id.txt_phone_number);
        txt_verify_phone = view.findViewById(R.id.txt_verify_phone);
        txt_email = view.findViewById(R.id.txt_email);
        txt_verify_email = view.findViewById(R.id.txt_verify_email);
        edtxt_address = view.findViewById(R.id.edtxt_address);

        btn_save = view.findViewById(R.id.btn_save);

    }


}