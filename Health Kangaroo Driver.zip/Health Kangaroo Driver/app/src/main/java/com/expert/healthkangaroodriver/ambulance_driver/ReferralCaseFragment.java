package com.expert.healthkangaroodriver.ambulance_driver;

import static com.expert.healthkangaroodriver.ambulance_driver.HomeAmbulanceDriverFragment.myLat;
import static com.expert.healthkangaroodriver.ambulance_driver.HomeAmbulanceDriverFragment.myLng;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.BookAmbulanceModal;
import com.expert.healthkangaroodriver.Model.ReferralCaseModal;
import com.expert.healthkangaroodriver.adapter_class.ambulance_adapter.ReferralDriversListAdapter;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class ReferralCaseFragment extends Fragment {
    View view;
    RecyclerView recyclerView;
    String strDriverId;
    DatabaseReference databaseReference;
    String userId, userName, patient_lat, patient_long, phone, relation, address, city;
    ImageView back_image;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_referrel_case, container, false);

        recyclerView = view.findViewById(R.id.recycler_view);
        back_image = view.findViewById(R.id.back_image);
        databaseReference = FirebaseDatabase.getInstance().getReference("ambulanceRequest");


        back_image.setOnClickListener(v -> {

            requireActivity().onBackPressed();

        });
        strDriverId = App.getSharedPref().getStringValue("DriverId");

        new ViewModelClass().referralCaseModalMutableLiveData(requireActivity(), strDriverId).observe(requireActivity(), new Observer<ReferralCaseModal>() {
            @Override
            public void onChanged(ReferralCaseModal referralCaseModal) {
                if (referralCaseModal.getSuccess().equalsIgnoreCase("1")) {
                    Toast.makeText(requireContext(), "" + referralCaseModal.getMessage(), Toast.LENGTH_SHORT).show();

                    ReferralDriversListAdapter adapter = new ReferralDriversListAdapter(requireContext(), referralCaseModal.getDetails(), new ReferralDriversListAdapter.Select() {
                        @Override
                        public void onClick(ReferralCaseModal.Detail detail) {

                            new ViewModelClass().bookAmbulanceModalMutableLiveData(requireActivity(), detail.getDriverId(), detail.getHospitalId(), detail.getBookingId(), "1").observe(requireActivity(), new Observer<BookAmbulanceModal>() {
                                @Override
                                public void onChanged(BookAmbulanceModal bookAmbulanceModal) {
                                    if (bookAmbulanceModal.getSuccess().equalsIgnoreCase("1")) {
                                        userName = detail.getUserName();
                                        patient_lat = detail.getLatitude();
                                        patient_long = detail.getLongitude();
                                        address = detail.getUserAddress();
                                        phone = detail.getNumber();
                                        userId = "19";

                                        Bundle bundle = new Bundle();
                                        bundle.putString("patient_lat", String.valueOf(patient_lat));
                                        bundle.putString("patient_long", String.valueOf(patient_long));
                                        bundle.putString("driverLat", String.valueOf(myLat));
                                        bundle.putString("driverLong", String.valueOf(myLng));
                                        bundle.putString("HospitalLatitude", String.valueOf(detail.getHospitalLatitude()));
                                        bundle.putString("HospitalLongitude", String.valueOf(detail.getHospitalLongitude()));
                                        bundle.putString("address", address);
                                        bundle.putString("phone", phone);
                                        bundle.putString("userName", detail.getUserName());
                                        bundle.putString("orderId", detail.getBookingId());
                                        bundle.putString("userid", "19");

                                        Navigation.findNavController(view).navigate(R.id.referralCaseMapFragment, bundle);

                                        Toast.makeText(requireActivity(), "" + bookAmbulanceModal.getMessage(), Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(requireActivity(), "" + bookAmbulanceModal.getMessage(), Toast.LENGTH_SHORT).show();

                                    }
                                }
                            });

                        }
                    }, detail -> {

                        ReferralDetailsFragment.detail = detail;

                        Navigation.findNavController(view).navigate(R.id.action_referralCaseFragment_to_referralDetailsFragment);
                    });

                    recyclerView.setAdapter(adapter);
                } else {
                    Toast.makeText(requireContext(), "" + referralCaseModal.getMessage(), Toast.LENGTH_SHORT).show();

                }
            }
        });
        return view;

    }

    private void sendRequest(String id) {

        Map map = new HashMap();
        map.put("name", userName);
        map.put("lat", patient_lat);
        map.put("log", patient_long);
        map.put("emergencyType", "referral case");
        map.put("address", address);
        map.put("phone", phone);
        map.put("driverId", strDriverId);
        map.put("relation", "Self");
        map.put("userId", userId);
        map.put("userImage", "");

        databaseReference.child(id).setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()) {

                    Toast.makeText(requireContext(), "Request sent to driver", Toast.LENGTH_SHORT).show();
                }

            }
        });
    }

}