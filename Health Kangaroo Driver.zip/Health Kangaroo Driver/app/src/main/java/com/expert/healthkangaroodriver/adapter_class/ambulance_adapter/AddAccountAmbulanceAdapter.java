package com.expert.healthkangaroodriver.adapter_class.ambulance_adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RadioButton;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.ambulance_model.AmbulanceDriverBankDetailsModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.GetPhlebotomistDriverBankDetailsModel;
import com.expert.healthkangaroodriver.adapter_class.phlebotomist_adapters.AddAccountPhlebotomistAdapter;

import java.util.List;


public class AddAccountAmbulanceAdapter extends RecyclerView.Adapter<AddAccountAmbulanceAdapter.ViewHolder> {

    private int lastSelectedPosition = -1;
    private int selectedItemDeletePosition = -1;
    Context context;
    private List<AmbulanceDriverBankDetailsModel.Detail> accountNumberList;
    SelectedAccountAmbulance accountSelected;
    DeleteSelectedAccountAmbulance deleteSelectedAccount;

    public interface SelectedAccountAmbulance {
        void selectedAccountNumber(String accountNumber);
    }

    public interface DeleteSelectedAccountAmbulance {
        void deleteAccountNumber(String accountNumber);
    }


    public AddAccountAmbulanceAdapter(Context context, List<AmbulanceDriverBankDetailsModel.Detail> accountNumberList, SelectedAccountAmbulance accountSelected, DeleteSelectedAccountAmbulance deleteSelectedAccount) {
        this.context = context;
        this.accountNumberList = accountNumberList;
        this.accountSelected = accountSelected;
        this.deleteSelectedAccount = deleteSelectedAccount;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_recycler_view_add_account, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.radio_button_account_number.setText(accountNumberList.get(position).getAccountNumber());

        holder.radio_button_account_number.setChecked(lastSelectedPosition == position);


    }

    @Override
    public int getItemCount() {
        return accountNumberList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        RadioButton radio_button_account_number;
        ImageView img_delete;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            radio_button_account_number = itemView.findViewById(R.id.radio_button_account_number);
            img_delete = itemView.findViewById(R.id.img_delete);

            radio_button_account_number.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    lastSelectedPosition = getAdapterPosition();
                    notifyDataSetChanged();

                    accountSelected.selectedAccountNumber(accountNumberList.get(lastSelectedPosition).getAccountNumber());

                }
            });

            img_delete.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    selectedItemDeletePosition = getAdapterPosition();
                    notifyDataSetChanged();

                    deleteSelectedAccount.deleteAccountNumber(accountNumberList.get(selectedItemDeletePosition).getAccountNumber());

                }
            });

        }
    }
}
