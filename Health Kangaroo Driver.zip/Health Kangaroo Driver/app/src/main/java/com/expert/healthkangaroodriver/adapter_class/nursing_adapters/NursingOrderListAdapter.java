package com.expert.healthkangaroodriver.adapter_class.nursing_adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.expert.healthkangaroodriver.Model.nurse_model.NurseOrderListModel;
import com.example.healthkangaroo.R;

import java.util.List;


public class NursingOrderListAdapter extends RecyclerView.Adapter<NursingOrderListAdapter.viewHolder> {
    Context context;
    private int latestIndex;
    private List<NurseOrderListModel.Detail> orderList;
    StartDeliveryPosition startDeliveryPosition;
    SelectNurse select;

    public interface SelectNurse {

        void details(NurseOrderListModel.Detail detail);
    }

    public NursingOrderListAdapter(Context context, List<NurseOrderListModel.Detail> orderList, StartDeliveryPosition startDeliveryPosition, SelectNurse select) {
        this.context = context;
        this.orderList = orderList;
        this.startDeliveryPosition = startDeliveryPosition;
        this.select = select;
    }


    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_order_list, parent, false);
        return new viewHolder(view);

    }


    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, @SuppressLint("RecyclerView") int position) {

        holder.txt_appointment_number.setText(orderList.get(position).getAppointmentId());
        holder.txt_patience_name.setText(orderList.get(position).getPatientName());
        holder.txt_patience_phone.setText(orderList.get(position).getPhone());
        holder.txt_patience_address.setText(orderList.get(position).getPatientAddress());

//        latestIndex = position;
//
//        if (latestIndex == 0) {
//            holder.pending_order_btn.setVisibility(View.GONE);

            holder.start_btn.setVisibility(View.VISIBLE);

            holder.start_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Bundle bundle = new Bundle();
//                    bundle.putString("Patience Image", orderList.get(position).getIpa;
                    bundle.putString("Patience Name", orderList.get(position).getPatientName());
                    bundle.putString("Patience Phone", orderList.get(position).getPhone());
                    bundle.putString("Patience Address", orderList.get(position).getPatientAddress());
                    bundle.putString("Patience Latitude", orderList.get(position).getLatitude());
                    bundle.putString("Patience Longitude", orderList.get(position).getLongitude());

                    startDeliveryPosition.startPosition(orderList.get(position).getAppointmentId(),orderList.get(position)
                            .getLatitude(),orderList.get(position).getLongitude(),orderList.get(position).getPatientAddress(),
                            orderList.get(position).getPhone());

                    select.details(orderList.get(position));


                }
            });
//
//        } else {
//            holder.pending_order_btn.setVisibility(View.VISIBLE);
//            holder.start_btn.setVisibility(View.GONE);
//
//            holder.pending_order_btn.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//
//
//                    Bundle bundle = new Bundle();
//                    bundle.putString("Patience Pic", orderList.get(position).getImage());
//                    bundle.putString("Patience Name", orderList.get(position).getPatientName());
//                    bundle.putString("Appointment id", orderList.get(position).getAppointmentId());
//                    bundle.putString("Patience Phone", orderList.get(position).getPhone());
//                    bundle.putString("Patience Age", orderList.get(position).getPatientAge());
//                    bundle.putString("Patience Gender", orderList.get(position).getPatientGender());
//                    bundle.putString("Patience DOB", orderList.get(position).getPatientDob());
//                    bundle.putString("Patience Appointment Date", orderList.get(position).getAppointmentDate());
//                    bundle.putString("Patience Language Spoken", orderList.get(position).getLanguageSpoken());
//                    bundle.putString("Patience Address", orderList.get(position).getAddress());
//
//
//                    Navigation.findNavController(v).navigate(R.id.action_mydeliveriesScreen_to_inprogressScreen,bundle);
//
//                }
//            });
//        }


    }

    @Override
    public int getItemCount() {
        return orderList.size();
    }

    public class viewHolder extends RecyclerView.ViewHolder {
        TextView txt_appointment_number, txt_patience_name, txt_patience_phone, txt_patience_address;
        Button start_btn, pending_order_btn;

        public viewHolder(@NonNull View itemView) {
            super(itemView);

            txt_appointment_number = itemView.findViewById(R.id.txt_appointment_number);
            txt_patience_name = itemView.findViewById(R.id.txt_patience_name);
            txt_patience_phone = itemView.findViewById(R.id.txt_patience_phone);
            txt_patience_address = itemView.findViewById(R.id.txt_patience_address);

            start_btn = itemView.findViewById(R.id.start_btn);
            pending_order_btn = itemView.findViewById(R.id.pending_order_btn);
        }
    }

    public interface StartDeliveryPosition{
        void startPosition(String appointmentNo,String patientLat,String patientLng,String patientAddress,String patientPhone);
    }

}
