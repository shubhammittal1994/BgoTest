package com.expert.healthkangaroodriver.AppClass;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPref {

    private final Context context;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor prefsEditor;


    public void saveString(String key, String value) {
        prefsEditor.putString(key, value);
        prefsEditor.commit();
    }

    public String getStringValue(String key) {
        return sharedPreferences.getString(key, "");
    }

    public void clearPreferences() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();

    }

    public SharedPref(Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences("Health Kangaroo Driver Part",Context.MODE_PRIVATE);
        prefsEditor = sharedPreferences.edit();
        prefsEditor.apply();
    }

}
