package com.expert.healthkangaroodriver.Model.nurse_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class OrderHistoryNurseModel {

    @SerializedName("success")
    @Expose
    private String success;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("details")
    @Expose
    private List<Detail> details = null;

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<Detail> getDetails() {
        return details;
    }

    public void setDetails(List<Detail> details) {
        this.details = details;
    }
    public class Detail {

        @SerializedName("id")
        @Expose
        private String id;
        @SerializedName("vendorId")
        @Expose
        private String vendorId;
        @SerializedName("nurseDriverId")
        @Expose
        private String nurseDriverId;
        @SerializedName("userId")
        @Expose
        private String userId;
        @SerializedName("appointmentId")
        @Expose
        private String appointmentId;
        @SerializedName("patient_name")
        @Expose
        private String patientName;
        @SerializedName("patient_service_price")
        @Expose
        private String patientServicePrice;
        @SerializedName("patient_gender")
        @Expose
        private String patientGender;
        @SerializedName("patient_dob")
        @Expose
        private String patientDob;
        @SerializedName("patient_age")
        @Expose
        private String patientAge;
        @SerializedName("patient_relation")
        @Expose
        private String patientRelation;
        @SerializedName("language_spoken")
        @Expose
        private String languageSpoken;
        @SerializedName("patient_address")
        @Expose
        private String patientAddress;
        @SerializedName("appointmentDate")
        @Expose
        private String appointmentDate;
        @SerializedName("appointmentSlot")
        @Expose
        private String appointmentSlot;
        @SerializedName("prescription_Image")
        @Expose
        private String prescriptionImage;
        @SerializedName("nurseAssignStatus")
        @Expose
        private String nurseAssignStatus;
        @SerializedName("created")
        @Expose
        private String created;
        @SerializedName("updated")
        @Expose
        private String updated;
        @SerializedName("latitude")
        @Expose
        private String latitude;
        @SerializedName("longitude")
        @Expose
        private String longitude;
        @SerializedName("phone")
        @Expose
        private String phone;
        @SerializedName("start_otp")
        @Expose
        private String startOtp;
        @SerializedName("start_otp_time")
        @Expose
        private String startOtpTime;
        @SerializedName("end_otp")
        @Expose
        private String endOtp;
        @SerializedName("end_otp_time")
        @Expose
        private String endOtpTime;
        @SerializedName("otp_diff_time")
        @Expose
        private String otpDiffTime;
        @SerializedName("delivery_Status")
        @Expose
        private String deliveryStatus;
        @SerializedName("deliver_date")
        @Expose
        private String deliverDate;
        @SerializedName("delivery_time")
        @Expose
        private String deliveryTime;
        @SerializedName("order_type")
        @Expose
        private String orderType;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getVendorId() {
            return vendorId;
        }

        public void setVendorId(String vendorId) {
            this.vendorId = vendorId;
        }

        public String getNurseDriverId() {
            return nurseDriverId;
        }

        public void setNurseDriverId(String nurseDriverId) {
            this.nurseDriverId = nurseDriverId;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String getAppointmentId() {
            return appointmentId;
        }

        public void setAppointmentId(String appointmentId) {
            this.appointmentId = appointmentId;
        }

        public String getPatientName() {
            return patientName;
        }

        public void setPatientName(String patientName) {
            this.patientName = patientName;
        }

        public String getPatientServicePrice() {
            return patientServicePrice;
        }

        public void setPatientServicePrice(String patientServicePrice) {
            this.patientServicePrice = patientServicePrice;
        }

        public String getPatientGender() {
            return patientGender;
        }

        public void setPatientGender(String patientGender) {
            this.patientGender = patientGender;
        }

        public String getPatientDob() {
            return patientDob;
        }

        public void setPatientDob(String patientDob) {
            this.patientDob = patientDob;
        }

        public String getPatientAge() {
            return patientAge;
        }

        public void setPatientAge(String patientAge) {
            this.patientAge = patientAge;
        }

        public String getPatientRelation() {
            return patientRelation;
        }

        public void setPatientRelation(String patientRelation) {
            this.patientRelation = patientRelation;
        }

        public String getLanguageSpoken() {
            return languageSpoken;
        }

        public void setLanguageSpoken(String languageSpoken) {
            this.languageSpoken = languageSpoken;
        }

        public String getPatientAddress() {
            return patientAddress;
        }

        public void setPatientAddress(String patientAddress) {
            this.patientAddress = patientAddress;
        }

        public String getAppointmentDate() {
            return appointmentDate;
        }

        public void setAppointmentDate(String appointmentDate) {
            this.appointmentDate = appointmentDate;
        }

        public String getAppointmentSlot() {
            return appointmentSlot;
        }

        public void setAppointmentSlot(String appointmentSlot) {
            this.appointmentSlot = appointmentSlot;
        }

        public String getPrescriptionImage() {
            return prescriptionImage;
        }

        public void setPrescriptionImage(String prescriptionImage) {
            this.prescriptionImage = prescriptionImage;
        }

        public String getNurseAssignStatus() {
            return nurseAssignStatus;
        }

        public void setNurseAssignStatus(String nurseAssignStatus) {
            this.nurseAssignStatus = nurseAssignStatus;
        }

        public String getCreated() {
            return created;
        }

        public void setCreated(String created) {
            this.created = created;
        }

        public String getUpdated() {
            return updated;
        }

        public void setUpdated(String updated) {
            this.updated = updated;
        }

        public String getLatitude() {
            return latitude;
        }

        public void setLatitude(String latitude) {
            this.latitude = latitude;
        }

        public String getLongitude() {
            return longitude;
        }

        public void setLongitude(String longitude) {
            this.longitude = longitude;
        }

        public String getPhone() {
            return phone;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public String getStartOtp() {
            return startOtp;
        }

        public void setStartOtp(String startOtp) {
            this.startOtp = startOtp;
        }

        public String getStartOtpTime() {
            return startOtpTime;
        }

        public void setStartOtpTime(String startOtpTime) {
            this.startOtpTime = startOtpTime;
        }

        public String getEndOtp() {
            return endOtp;
        }

        public void setEndOtp(String endOtp) {
            this.endOtp = endOtp;
        }

        public String getEndOtpTime() {
            return endOtpTime;
        }

        public void setEndOtpTime(String endOtpTime) {
            this.endOtpTime = endOtpTime;
        }

        public String getOtpDiffTime() {
            return otpDiffTime;
        }

        public void setOtpDiffTime(String otpDiffTime) {
            this.otpDiffTime = otpDiffTime;
        }

        public String getDeliveryStatus() {
            return deliveryStatus;
        }

        public void setDeliveryStatus(String deliveryStatus) {
            this.deliveryStatus = deliveryStatus;
        }

        public String getDeliverDate() {
            return deliverDate;
        }

        public void setDeliverDate(String deliverDate) {
            this.deliverDate = deliverDate;
        }

        public String getDeliveryTime() {
            return deliveryTime;
        }

        public void setDeliveryTime(String deliveryTime) {
            this.deliveryTime = deliveryTime;
        }

        public String getOrderType() {
            return orderType;
        }

        public void setOrderType(String orderType) {
            this.orderType = orderType;
        }

    }
}
