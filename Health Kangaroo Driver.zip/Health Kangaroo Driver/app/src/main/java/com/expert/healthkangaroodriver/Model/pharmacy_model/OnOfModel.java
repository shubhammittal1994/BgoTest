package com.expert.healthkangaroodriver.Model.pharmacy_model;

public class OnOfModel {

    private String state;

    public OnOfModel(String state) {
        this.state = state;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
