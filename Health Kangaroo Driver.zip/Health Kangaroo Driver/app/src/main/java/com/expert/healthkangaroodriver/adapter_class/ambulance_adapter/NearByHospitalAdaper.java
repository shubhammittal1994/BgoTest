package com.expert.healthkangaroodriver.adapter_class.ambulance_adapter;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.expert.healthkangaroodriver.Model.ambulance_model.NearByHospitalListModel;
import com.example.healthkangaroo.R;

import java.util.List;

public class NearByHospitalAdaper extends RecyclerView.Adapter<NearByHospitalAdaper.ViewHolder> {
    Context context;
    private List<NearByHospitalListModel.Detail> hospitalList;
    private int lastSelectedItem = -1;
    HospitalSelect hospitalSelect;

    public NearByHospitalAdaper(Context context, List<NearByHospitalListModel.Detail> hospitalList, HospitalSelect hospitalSelect) {
        this.context = context;
        this.hospitalList = hospitalList;
        this.hospitalSelect = hospitalSelect;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_recycler_view_near_by_hospital_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        Glide.with(context).load(hospitalList.get(position).getHospitalPhoto()).into(holder.imageView);
        holder.txt_name.setText(hospitalList.get(position).getHospitalName());
        holder.txt_address.setText(hospitalList.get(position).getAddress());
        holder.txt_distance.setText(hospitalList.get(position).getDistance());

        if (position==0)
        {
            holder.near_by.setText("Your Nearest Hospital");

        }else {
            holder.near_by.setText("Other Hospitals");

        }

        if (lastSelectedItem == position) {

            holder.linear_layout.setBackgroundColor(Color.parseColor("#D8D1D1"));
            hospitalSelect.selectedHospital(hospitalList.get(lastSelectedItem).getId(),hospitalList.get(lastSelectedItem).getLatitude(),hospitalList.get(lastSelectedItem).getLongitude(),hospitalList.get(lastSelectedItem).getHospitalPhoto(),hospitalList.get(lastSelectedItem).getHospitalName(),hospitalList.get(lastSelectedItem).getPhone(),hospitalList.get(lastSelectedItem).getAddress());

        }else {
            holder.linear_layout.setBackgroundColor(Color.parseColor("#D2FFE6"));

        }

    }


    public void filterList(List<NearByHospitalListModel.Detail> filterList)
    {
        hospitalList = filterList;
        notifyDataSetChanged();
    }

    @Override
    public int getItemCount() {
        return hospitalList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView txt_name, txt_address, txt_distance, near_by;
        LinearLayout linear_layout;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            linear_layout = itemView.findViewById(R.id.linear_layout);

            imageView = itemView.findViewById(R.id.imageView_hospital);
            txt_name = itemView.findViewById(R.id.txt_name);
            txt_address = itemView.findViewById(R.id.txt_address);
            txt_distance = itemView.findViewById(R.id.txt_distance);
            near_by = itemView.findViewById(R.id.near_by);

            linear_layout.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    lastSelectedItem = getAdapterPosition();
                    notifyDataSetChanged();
                }
            });

        }
    }


    public  interface HospitalSelect{
        void selectedHospital(String hosId,String latitude,String longitude,String hosImage,String hosName,String hosMobile,String hosAddress);
    }




}
