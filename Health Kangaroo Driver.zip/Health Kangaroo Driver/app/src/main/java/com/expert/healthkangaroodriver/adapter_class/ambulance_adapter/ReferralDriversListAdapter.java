package com.expert.healthkangaroodriver.adapter_class.ambulance_adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.ReferralCaseModal;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class ReferralDriversListAdapter extends RecyclerView.Adapter<ReferralDriversListAdapter.viewHolder> {

    Context context;
    List<ReferralCaseModal.Detail> list;
    Select select;
    AmbulaceDetails ambulaceDeatils;


    public interface AmbulaceDetails{

        void ambulaceDeatils(ReferralCaseModal.Detail detail);

    }
    public ReferralDriversListAdapter(Context context, List<ReferralCaseModal.Detail> list, Select select, AmbulaceDetails ambulaceDeatils) {
        this.context = context;
        this.list = list;
        this.select = select;
        this.ambulaceDeatils = ambulaceDeatils;
    }

    @NonNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.referral_case_list, parent, false);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position) {

        holder.driverName.setText("Case No. "+list.get(position).getBookingId());
        holder.vehicleNumber.setText("Patient Name: "+list.get(position).getUserName());
        String price = "Date:  "+list.get(position).getDate();
        holder.driverS_price.setText(price);
        holder.ambulance_type.setText("Time: "+list.get(position).getTime());
        holder.request_details.setOnClickListener(v -> {

            ambulaceDeatils.ambulaceDeatils(list.get(position));
        });

//        Glide.with(context).load(list.get(position).getAmbulancePhoto()).into(holder.driverImg);

        holder.request_txt.setOnClickListener(view -> {

            select.onClick(list.get(position));

        });

    }

    @Override
    public int getItemCount() {

        return (list!=null && list.size()!=0 ? list.size():0);

    }

    public class viewHolder extends RecyclerView.ViewHolder {

        TextView driverName,vehicleNumber,driver_distance,request_txt,driverS_price, ambulance_type, request_details,busy_driver;
        CircleImageView driverImg;
        public viewHolder(@NonNull View itemView) {

            super(itemView);

            driverName = itemView.findViewById(R.id.driverName);
            request_txt = itemView.findViewById(R.id.request_txt);
            vehicleNumber = itemView.findViewById(R.id.driverNumber);
            driver_distance = itemView.findViewById(R.id.driverS_distance);
            driverS_price = itemView.findViewById(R.id.driverS_price);
            ambulance_type = itemView.findViewById(R.id.ambulance_type);
            driverImg = itemView.findViewById(R.id.driverImg);
            request_details = itemView.findViewById(R.id.request_details);
            busy_driver = itemView.findViewById(R.id.busy_driver);

        }
    }

    public interface Select{

        void onClick(ReferralCaseModal.Detail detail);

    }

}
