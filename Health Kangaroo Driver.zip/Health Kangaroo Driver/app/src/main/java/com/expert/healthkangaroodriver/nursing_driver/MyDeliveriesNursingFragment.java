package com.expert.healthkangaroodriver.nursing_driver;


import android.app.ProgressDialog;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.NurseInformationFirebase.NurseDriverFireModel;
import com.expert.healthkangaroodriver.Model.nurse_model.NurseOrderListModel;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;
import com.expert.healthkangaroodriver.adapter_class.nursing_adapters.NursingOrderListAdapter;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;


public class MyDeliveriesNursingFragment extends Fragment {
    private View view;
    private ImageView back;
    private RecyclerView recycler_view_nurse_order_list;
    private String strDriverId, strVenderId, strVendorName;
    private ViewModelClass viewModel;
    private List<NurseOrderListModel.Detail> orderList = new ArrayList<>();
    public static String currentLat, currentLog;
    String address, city;
    String startOtp = "";
    String endOtp = "";
    String status = "0";
    String startTime = "";
    String endTime = "";
    String difference = "";
    ProgressDialog dialog;
    String orderId;

    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    DatabaseReference databaseReference = firebaseDatabase.getReference();
    DatabaseReference reference = FirebaseDatabase.getInstance().getReference("TrackNurseDriver");


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_nursing_my_deliveries, container, false);

        viewModel = new ViewModelClass();
        strDriverId = App.getSharedPref().getStringValue("DriverId");
        strVenderId = App.getSharedPref().getStringValue("VenderId");
        strVendorName = App.getSharedPref().getStringValue("vendor_name");



        Bundle bundle = getArguments();
        assert bundle != null;
        String myLatitude = bundle.getString("My Latitue");
        String myLongitude = bundle.getString("My Longitude");


        dialog = new ProgressDialog(requireActivity());
        dialog.setMessage("Loading Orders....");

        currentLat = myLatitude;
        currentLog = myLongitude;

        FindId();
        onClicks();
        setAdapter();


        return view;
    }

    private void setAdapter() {
        dialog.show();

        viewModel.liveDataNurseOrderList(requireActivity(), strDriverId, strVenderId).observe(requireActivity(), nurseOrderListModel -> {
            if (nurseOrderListModel.getSuccess().equalsIgnoreCase("1")) {
                dialog.dismiss();
                orderList = nurseOrderListModel.getDetails();
                NursingOrderListAdapter adapter = new NursingOrderListAdapter(requireActivity(), orderList, (appointmentNo, patientLat, patientLng, patientAddress, patientPhone) -> {

                    Geocoder geocoder;
                    List<Address> addresses;
                    geocoder = new Geocoder(requireActivity(), Locale.getDefault());

                    try {
                        addresses = geocoder.getFromLocation(Double.parseDouble(currentLat),
                                Double.parseDouble(currentLog), 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
                        address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                        city = addresses.get(0).getLocality();
                        String liveLocation = address + " " +city;

                        reference.child(appointmentNo).addValueEventListener(new ValueEventListener() {
                            @Override
                            public void onDataChange(@NonNull DataSnapshot snapshot) {

                                String status = snapshot.child("status").getValue().toString();
                                String otp = snapshot.child("startOtp").getValue().toString();
                                String startTime = snapshot.child("startTime").getValue().toString();

                                if (status.equals("1")) {
                                    if (otp != null) {

                                    Map map = new HashMap();
                                    map.put("status", "1");
                                    map.put("startOtp", otp);
                                    map.put("startTime", startTime);

                                    reference.child(appointmentNo).updateChildren(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                                        @Override
                                        public void onComplete(@NonNull Task<Void> task) {

                                        }
                                    });
                                }
                            }
                            }

                            @Override
                            public void onCancelled(@NonNull DatabaseError error) {

                            }
                        });

                        updateDriverInformationToFirebase(appointmentNo, patientAddress, liveLocation, startOtp,  endOtp, status,startTime, endTime, difference);



                    } catch (IOException e) {
                        e.printStackTrace();
                    }
      }, detail -> {

                    try {

                        MessageScreenNursingFragment.detail = detail;
                        StartDeliveryNursingFragment.detail = detail;
                        orderId = detail.getAppointmentId();

                    } catch (Exception e) {
                        e.printStackTrace();

                    }

                    Navigation.findNavController(view).navigate(R.id.mydeliveryStartScreen);
                });

                recycler_view_nurse_order_list.setAdapter(adapter);

            } else {

                dialog.dismiss();

                Toast.makeText(requireActivity(), nurseOrderListModel.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });

    }
    private void updateDriverInformationToFirebase(String orderId, String patientAddress,  String  liveLocation,String startOtp  ,String endOtp,String status, String startTime, String endTime, String difference ) {

        NurseDriverFireModel nurseDriverInformation = new NurseDriverFireModel(orderId, patientAddress,  liveLocation , strVendorName, startOtp, endOtp, status,  startTime, endTime, difference);

        databaseReference.child("TrackNurseDriver").child(orderId).setValue(nurseDriverInformation).addOnCompleteListener(task -> {

            if (task.isSuccessful()) {

                Toast.makeText(requireActivity(), "Success", Toast.LENGTH_SHORT).show();

            } else {

                Toast.makeText(requireContext(), "Something went wrong", Toast.LENGTH_SHORT).show();

            }

        });

    }
    private void onClicks() {

        back.setOnClickListener(v -> requireActivity().onBackPressed());

    }
    private void FindId() {
        recycler_view_nurse_order_list = view.findViewById(R.id.recycler_view_nurse_order_list);
        back = view.findViewById(R.id.back_image);
    }

}