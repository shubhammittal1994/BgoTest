package com.expert.healthkangaroodriver.phlebotomist_driver;

import android.app.ProgressDialog;
import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.NurseInformationFirebase.NurseDriverInformation;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.PhlebotomistDriverSampleCollectionModel;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.adapter_class.phlebotomist_adapters.PhlebotomistSampleCollectionAdapter;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SampleCollectionsPhlebotomistFragment extends Fragment {

    private View view;
    private RecyclerView recycler_view_phlebotomist_sample_list;
    private ImageView img_back;
    private ViewModelClass viewModel;
    private String strVenderId, strDriverId, strVendorName;
    private List<PhlebotomistDriverSampleCollectionModel.Detail> sampleList = new ArrayList<>();
    public static String currentLat, currentLog;
    private ProgressDialog dialog;
    FirebaseDatabase firebaseDatabase = FirebaseDatabase.getInstance();
    DatabaseReference databaseReference = firebaseDatabase.getReference();
    String address, city, otp = "";
    String orderId, patientAddress;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_sample_collections_phlebotomist, container, false);

        viewModel = new ViewModelClass();

        strDriverId = App.getSharedPref().getStringValue("DriverId");
        strVenderId = App.getSharedPref().getStringValue("VenderId");


        Bundle bundle = getArguments();
        String myLatitude = bundle.getString("My Latitue");
        String myLongitude = bundle.getString("My Longitude");

        dialog = new ProgressDialog(requireActivity());
        dialog.setMessage("Loading Samples....");

        currentLat = myLatitude;
        currentLog = myLongitude;

        FindId();
        onClick();
        setAdapter();


        return view;
    }

    private void setAdapter() {
        dialog.show();

        viewModel.liveDataPhlebotomistDriverSampleCollection(requireActivity(), strDriverId, strVenderId).observe(requireActivity(), new Observer<PhlebotomistDriverSampleCollectionModel>() {
            @Override
            public void onChanged(PhlebotomistDriverSampleCollectionModel phlebotomistDriverSampleCollectionModel) {
                if (phlebotomistDriverSampleCollectionModel.getSuccess().equalsIgnoreCase("True")) {
                    dialog.dismiss();
                    sampleList = phlebotomistDriverSampleCollectionModel.getDetails();

                    PhlebotomistSampleCollectionAdapter adapter = new PhlebotomistSampleCollectionAdapter(requireActivity(), sampleList, new PhlebotomistSampleCollectionAdapter.Select() {
                        @Override
                        public void details(PhlebotomistDriverSampleCollectionModel.Detail detail) {
                            StartMyDeliveryPhlebotomistFragment.detail = detail;
                            ChatMessagingStartScreenPhlebotomistFragment.detail = detail;
                            patientAddress = detail.getAddress();
                            orderId  = detail.getAppointmentId();


                            MessageListFragment.detail = detail;
                            Geocoder geocoder;
                            List<Address> addresses;
                            geocoder = new Geocoder(requireActivity(), Locale.getDefault());
                            try {
                                addresses = geocoder.getFromLocation(Double.parseDouble(currentLat), Double.parseDouble(currentLog), 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
                                address = addresses.get(0).getAddressLine(0); // If any additional address line present than only, check with max available address lines by getMaxAddressLineIndex()
                                city = addresses.get(0).getLocality();
                                String state = addresses.get(0).getAdminArea();

                                String liveLocation = address + " " +city;


                        updateDriverInformationToFirebase(orderId, patientAddress, liveLocation, otp);

                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }, new PhlebotomistSampleCollectionAdapter.StartDeliveryPositionLab() {
                        @Override
                        public void startPosition(String appointmentNo, String patientLat, String patientLng, String patientAddress, String patientPhone,String orderType) {

                            Navigation.findNavController(view).navigate(R.id.action_myDeliveries_to_myDeliveryStartScreenPhlebo);

                        }
                    });
                    recycler_view_phlebotomist_sample_list.setAdapter(adapter);
                } else {
                    dialog.dismiss();
                    Toast.makeText(requireActivity(), phlebotomistDriverSampleCollectionModel.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });

    }
    private void updateDriverInformationToFirebase(String orderId,  String patientAddress, String  liveLocation, String otp) {


         NurseDriverInformation labDriverInformation = new NurseDriverInformation(orderId, patientAddress, liveLocation,"vikas", otp);

        databaseReference.child("TrackPharmacyDriver").child(orderId).setValue(labDriverInformation).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if (task.isSuccessful()){

                    Toast.makeText(requireActivity(), "Success", Toast.LENGTH_SHORT).show();
                }else {

                    Toast.makeText(requireContext(), "Something went wrong", Toast.LENGTH_SHORT).show();

                }
            }
        });


    }
    private void onClick() {

        img_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requireActivity().onBackPressed();
            }
        });
    }

    private void FindId() {

        img_back = view.findViewById(R.id.img_back);
        recycler_view_phlebotomist_sample_list = view.findViewById(R.id.recycler_view_phlebotomist_sample_list);

    }

}