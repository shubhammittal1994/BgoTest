package com.expert.healthkangaroodriver.phlebotomist_driver;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.ImageView;

import com.example.healthkangaroo.R;

public class termAndConditionLabFragment extends Fragment {
    private View view;
    private WebView webView;
    private ImageView back_img;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view =  inflater.inflate(R.layout.fragment_term_and_condition_lab, container, false);

        webView = view.findViewById(R.id.webView_term_lab);
        back_img = view.findViewById(R.id.img_back_lab);



        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("https://www.jsonschema2pojo.org/");

        back_img.setOnClickListener(v -> {

            Navigation.findNavController(view).navigate(R.id.mapscreenDrawerLayout);

        });




        return view;
    }
}