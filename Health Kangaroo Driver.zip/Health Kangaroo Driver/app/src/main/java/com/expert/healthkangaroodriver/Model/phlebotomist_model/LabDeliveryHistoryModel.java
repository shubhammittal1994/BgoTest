package com.expert.healthkangaroodriver.Model.phlebotomist_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class LabDeliveryHistoryModel {

    @SerializedName("success")
    @Expose
    private String success;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("details")
    @Expose
    private List<Detail> details = null;

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public List<Detail> getDetails() {
        return details;
    }

    public void setDetails(List<Detail> details) {
        this.details = details;
    }
    public class Detail {

        @SerializedName("id")
        @Expose
        private String id;
        @SerializedName("vendorId")
        @Expose
        private String vendorId;
        @SerializedName("labDriverId")
        @Expose
        private String labDriverId;
        @SerializedName("userId")
        @Expose
        private String userId;
        @SerializedName("appointmentId")
        @Expose
        private String appointmentId;
        @SerializedName("fathername")
        @Expose
        private String fathername;
        @SerializedName("patient_name")
        @Expose
        private String patientName;
        @SerializedName("email")
        @Expose
        private String email;
        @SerializedName("address")
        @Expose
        private String address;
        @SerializedName("price")
        @Expose
        private String price;
        @SerializedName("age")
        @Expose
        private String age;
        @SerializedName("LabAssignStatus")
        @Expose
        private String labAssignStatus;
        @SerializedName("latitude")
        @Expose
        private String latitude;
        @SerializedName("longitude")
        @Expose
        private String longitude;
        @SerializedName("appointmentSlot")
        @Expose
        private String appointmentSlot;
        @SerializedName("phone")
        @Expose
        private String phone;
        @SerializedName("delivery_Status")
        @Expose
        private String deliveryStatus;
        @SerializedName("deliver_date")
        @Expose
        private String deliverDate;
        @SerializedName("delivery_time")
        @Expose
        private String deliveryTime;
        @SerializedName("order_type")
        @Expose
        private String orderType;
        @SerializedName("created")
        @Expose
        private String created;

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getVendorId() {
            return vendorId;
        }

        public void setVendorId(String vendorId) {
            this.vendorId = vendorId;
        }

        public String getLabDriverId() {
            return labDriverId;
        }

        public void setLabDriverId(String labDriverId) {
            this.labDriverId = labDriverId;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String getAppointmentId() {
            return appointmentId;
        }

        public void setAppointmentId(String appointmentId) {
            this.appointmentId = appointmentId;
        }

        public String getFathername() {
            return fathername;
        }

        public void setFathername(String fathername) {
            this.fathername = fathername;
        }

        public String getPatientName() {
            return patientName;
        }

        public void setPatientName(String patientName) {
            this.patientName = patientName;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getPrice() {
            return price;
        }

        public void setPrice(String price) {
            this.price = price;
        }

        public String getAge() {
            return age;
        }

        public void setAge(String age) {
            this.age = age;
        }

        public String getLabAssignStatus() {
            return labAssignStatus;
        }

        public void setLabAssignStatus(String labAssignStatus) {
            this.labAssignStatus = labAssignStatus;
        }

        public String getLatitude() {
            return latitude;
        }

        public void setLatitude(String latitude) {
            this.latitude = latitude;
        }

        public String getLongitude() {
            return longitude;
        }

        public void setLongitude(String longitude) {
            this.longitude = longitude;
        }

        public String getAppointmentSlot() {
            return appointmentSlot;
        }

        public void setAppointmentSlot(String appointmentSlot) {
            this.appointmentSlot = appointmentSlot;
        }

        public String getPhone() {
            return phone;
        }

        public void setPhone(String phone) {
            this.phone = phone;
        }

        public String getDeliveryStatus() {
            return deliveryStatus;
        }

        public void setDeliveryStatus(String deliveryStatus) {
            this.deliveryStatus = deliveryStatus;
        }

        public String getDeliverDate() {
            return deliverDate;
        }

        public void setDeliverDate(String deliverDate) {
            this.deliverDate = deliverDate;
        }

        public String getDeliveryTime() {
            return deliveryTime;
        }

        public void setDeliveryTime(String deliveryTime) {
            this.deliveryTime = deliveryTime;
        }

        public String getOrderType() {
            return orderType;
        }

        public void setOrderType(String orderType) {
            this.orderType = orderType;
        }

        public String getCreated() {
            return created;
        }

        public void setCreated(String created) {
            this.created = created;
        }

    }

}
