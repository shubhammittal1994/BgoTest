package com.expert.healthkangaroodriver.nursing_driver;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import android.os.Looper;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.nurse_model.LogOutModel;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.nurse_model.OnOffStatusNurseModel;
import com.expert.healthkangaroodriver.Model.nurse_model.OnlineOffLineNurseModel;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;
import com.expert.healthkangaroodriver.drivers_Login.MainStartingActivity;
import com.github.angads25.toggle.interfaces.OnToggledListener;
import com.github.angads25.toggle.model.ToggleableView;
import com.github.angads25.toggle.widget.LabeledSwitch;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.switchmaterial.SwitchMaterial;

import java.io.IOException;
import java.util.List;


public class HomeNursingFragment extends Fragment implements OnMapReadyCallback, GoogleApiClient.ConnectionCallbacks {

    private View view;
    private ImageView menu_image;
    private String mydata, strDriverId, strVenderId, userName;
    private TextView txtDriverName, txtOnline, txtOffline, txtAddress;
    private NavigationView navigationView;
    private GoogleMap mMap;
    private LabeledSwitch switch_before;
    private DrawerLayout drawerLayout;
    private Geocoder geocoder;
    private Address address;
    private LatLng latLng;
    private double lat = 0.00, log = 0.00;
    private final String[] perms = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.INTERNET};
    String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
    private final int permissionCode = 123;
    ImageView imgDriverNurse, imgLocationNursing;
    private SupportMapFragment mapFragment;
    private LocationRequest locationRequest;
    private GoogleApiClient googleApiClient;
    private ViewModelClass viewModel = new ViewModelClass();
    private LocationManager locationManager;
    private FusedLocationProviderClient fusedLocationProviderClient;
    private Location location;
    public static double myLat, myLng;
    private ImageView btn_call;
    AppCompatButton myOrder;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_nursing_home, container, false);


        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(requireContext());
        locationManager = (LocationManager) requireActivity().getSystemService(Context.LOCATION_SERVICE);


        mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.frgMapDriverNursing);

        if (ActivityCompat.checkSelfPermission(requireActivity(), ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireActivity(), ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(requireContext(), "permission Check", Toast.LENGTH_SHORT).show();
            ActivityCompat.requestPermissions(requireActivity(), permissions, 10);
        } else {

            getCurrentLocation();
        }

        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }


        mydata = App.getSharedPref().getStringValue("userid");

        strDriverId = App.getSharedPref().getStringValue("DriverId");
        strVenderId = App.getSharedPref().getStringValue("VenderId");
        userName = App.getSharedPref().getStringValue("Username");

        findIds();
        backPressed();
        navigationMenuHandler();
        onOffStatus();

        currentLocation();
        switchCondition();
        onClick();

        geocoder = new Geocoder(requireContext());
        txtDriverName.setText(App.getSharedPref().getStringValue("Name"));
        txtAddress.setText(App.getSharedPref().getStringValue("Address"));

        Glide.with(imgDriverNurse).load(App.getSharedPref().getStringValue("Image")).into(imgDriverNurse);


        return view;
    }

    private void onOffStatus() {
        viewModel.onOffStatusNurseModelLiveData(requireActivity(), strDriverId).observe(requireActivity(), new Observer<OnOffStatusNurseModel>() {
            @Override
            public void onChanged(OnOffStatusNurseModel onOffStatusNurseModel) {
                if (onOffStatusNurseModel.getSuccess().equalsIgnoreCase("1")){
                    if (onOffStatusNurseModel.getMessage().getOnOffStatus().equalsIgnoreCase("1"))
                    {
                        switch_before.setOn(true);
                        txtOffline.setVisibility(View.GONE);
                        txtOnline.setVisibility(View.VISIBLE);
                    }else {
                        switch_before.setOn(false);
                    }
                }
            }
        });

    }

    private void onClick() {

        btn_call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        myOrder.setOnClickListener(v -> {

                 Bundle bundle = new Bundle();
                bundle.putString("My Latitue", String.valueOf(lat));
                bundle.putString("My Longitude", String.valueOf(log));

                Navigation.findNavController(view).navigate(R.id.action_driverpartMapscreen_to_mydeliveriesScreen, bundle);

        });

    }

    private void switchCondition() {

        switch_before.setOnToggledListener(new OnToggledListener() {
            @Override
            public void onSwitched(ToggleableView toggleableView, boolean isOn) {
                if (switch_before.isOn()){
                    txtOffline.setVisibility(View.GONE);
                    txtOnline.setVisibility(View.VISIBLE);
                    hitApiOnLineStatus("online", strVenderId, strDriverId, lat, log);
                }else {
                    hitApiOnLineStatus("offline", strVenderId, strDriverId, lat, log);

                    txtOffline.setVisibility(View.VISIBLE);
                    txtOnline.setVisibility(View.GONE);
                    switch_before.setClickable(true);
                }
            }
        });

    }

    private void hitApiOnLineStatus(String type, String strVenderId, String strDriverId, double lat, double log) {

        viewModel.onlineOffLineNurseModelLiveData(requireActivity(), type, strVenderId, strDriverId, Double.toString(lat), Double.toString(log))
                .observe(requireActivity(), new Observer<OnlineOffLineNurseModel>() {
                    @Override
                    public void onChanged(OnlineOffLineNurseModel onlineOffLineNurseModel) {
                        if (onlineOffLineNurseModel.getSuccess().equalsIgnoreCase("1")){

                                Toast.makeText(requireContext(), onlineOffLineNurseModel.getMessage(), Toast.LENGTH_SHORT).show();

                        } else {
                            Toast.makeText(requireContext(), onlineOffLineNurseModel.getMessage(), Toast.LENGTH_SHORT).show();

                        }
                    }
                });
    }

    private void currentLocation() {

        imgLocationNursing.setOnClickListener(v -> {
                    if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                        requestPermissions(perms, permissionCode);
                        return;
                    }

                    CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 16);
                    mMap.animateCamera(cameraUpdate);
                }
        );

    }

    private void findIds() {

        btn_call = view.findViewById(R.id.btn_call);

        txtDriverName = view.findViewById(R.id.txtDriverName);
        txtOnline = view.findViewById(R.id.textOnline);
        txtAddress = view.findViewById(R.id.txt_patient_address);
        txtOffline = view.findViewById(R.id.textOffline);
        imgDriverNurse = view.findViewById(R.id.imgDriverNurse);
        imgLocationNursing = view.findViewById(R.id.imgLocationNursing);
        myOrder = view.findViewById(R.id.my_orders_nurse);

        switch_before = view.findViewById(R.id.swNurse);
    }

    private void navigationMenuHandler() {

        drawerLayout = view.findViewById(R.id.drawer_layout_nursing);
        navigationView = view.findViewById(R.id.navigation_drawer_nursing);
        menu_image = view.findViewById(R.id.img_menu);


        menu_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                drawerLayout.openDrawer(GravityCompat.START);
            }
        });

        View headerView = navigationView.getHeaderView(0);
        TextView drawerName = headerView.findViewById(R.id.txt_name_drawer);
        ImageView drawerImage = headerView.findViewById(R.id.img_profile_pic_drawer);

        drawerName.setText(App.getSharedPref().getStringValue("Name"));
        Glide.with(view).load(App.getSharedPref().getStringValue("Image")).into(drawerImage);

        Menu menuNav = navigationView.getMenu();

        MenuItem myprofile, mydeliveries, mywallet, about, termandconditions, report, logout;
        myprofile = menuNav.findItem(R.id.profile);
        mywallet = menuNav.findItem(R.id.wallet);
        about = menuNav.findItem(R.id.about);
        termandconditions = menuNav.findItem(R.id.tearms);
        report = menuNav.findItem(R.id.report);
        logout = menuNav.findItem(R.id.logout);
        mydeliveries = menuNav.findItem(R.id.history);

        about.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Navigation.findNavController(view).navigate(R.id.aboutFragment);

                return true;
            }
        });

        mydeliveries.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Navigation.findNavController(view).navigate(R.id.historyNurseOrderFragment);

                return true;
            }
        });

        termandconditions.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                Navigation.findNavController(view).navigate(R.id.termAndConditionFragment);

                return true;
            }
        });

        myprofile.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Navigation.findNavController(view).navigate(R.id.myprofileScreen);
                return true;
            }
        });

        mywallet.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Navigation.findNavController(view).navigate(R.id.action_driverpartMapscreen_to_walletScreen);
                return true;
            }
        });

//        mydeliveries.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
//            @Override
//            public boolean onMenuItemClick(MenuItem item) {
//                Bundle bundle = new Bundle();
//                bundle.putString("My Latitue", String.valueOf(lat));
//                bundle.putString("My Longitude", String.valueOf(log));
//
//                Navigation.findNavController(view).navigate(R.id.action_driverpartMapscreen_to_mydeliveriesScreen, bundle);
//                return true;
//
//            }
//        });
        report.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                final Dialog dialog = new Dialog(requireActivity());
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.call_layout);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

                ImageView call_btn = dialog.findViewById(R.id.call_btn_call);
                ImageView email_btn = dialog.findViewById(R.id.mail_btn);
                TextView call_txt = dialog.findViewById(R.id.call_txt);

                call_btn.setOnClickListener(v -> {

                    Intent intent = new Intent(Intent.ACTION_DIAL);
                    intent.setData(Uri.parse("tel:" +call_txt.getText().toString()));
                    startActivity(intent);

                });

                email_btn.setOnClickListener(v -> {
                    final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
                    emailIntent.setType("plain/text");
                    emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"Test123@gmail.com"});
                    emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject");
                    emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Text");
                    requireActivity().startActivity(Intent.createChooser(emailIntent, "Send mail..."));
                    dialog.dismiss();

                });

                dialog.show();

                return false;
            }
        });


        logout.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                AlertDialog.Builder alert = new AlertDialog.Builder(requireActivity());
                alert.setIcon(R.drawable.ic_warning).setTitle("Logout");
                alert.setMessage("Do you want to Logout?");

                alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        viewModel.logoutNurses(requireActivity(), App.getSharedPref().getStringValue("VenderId"), App.getSharedPref().getStringValue("DriverId")).observe(requireActivity(), new Observer<LogOutModel>() {
                            @Override
                            public void onChanged(LogOutModel logoutAmbulanceModel) {
                                if (logoutAmbulanceModel.getSuccess().equalsIgnoreCase("1")) {
                                    App.getSharedPref().clearPreferences();

                                    Intent intent = new Intent(requireActivity(), MainStartingActivity.class);
                                    requireActivity().startActivity(intent);

                                }
                                Toast.makeText(requireContext(), logoutAmbulanceModel.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });

                    }
                });
                alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                alert.show();


                return false;
            }
        });

    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        try {
            List<Address> addressList = geocoder.getFromLocation(App.getSingleton().getLat(), App.getSingleton().getLog(), 1);

            address = addressList.get(0);
            myLat = address.getLatitude();
            myLng = address.getLongitude();
            latLng = new LatLng(address.getLatitude(), address.getLongitude());

            if (ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(perms, permissionCode);
                return;
            }

            mMap.setMyLocationEnabled(true); // get your maps fragment
            // Extract My Location View from maps fragment
            mMap.getUiSettings().setMyLocationButtonEnabled(false);
            mMap.getMyLocation();
            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 16);
            mMap.animateCamera(cameraUpdate);

        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

        locationRequest = new LocationRequest();
        locationRequest.setInterval(2000);
        locationRequest.setFastestInterval(2000);

        locationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, locationRequest, (LocationListener) this);
        }
    }

    @Override
    public void onConnectionSuspended(int i) { }

    private void getCurrentLocation() {

        if (ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(requireActivity(), permissions, 10);
        }

        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {

            fusedLocationProviderClient.getLastLocation().addOnCompleteListener(new OnCompleteListener<Location>() {
                @Override
                public void onComplete(@NonNull Task<Location> task) {
                    location = task.getResult();

                    if (location != null) {

                        lat = location.getLatitude();
                        log = location.getLongitude();

                    } else {
                        LocationRequest locationRequest = new LocationRequest().setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY).setInterval(1000).setFastestInterval(1000).setNumUpdates(1);

                        LocationCallback locationCallback = new LocationCallback() {
                            @Override
                            public void onLocationResult(@NonNull LocationResult locationResult) {
                                super.onLocationResult(locationResult);

                                Location location1 = locationResult.getLastLocation();

                                lat = (long) location1.getLatitude();
                                log = (long) location1.getLongitude();

                            }
                        };

                        if (ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(requireActivity(), permissions, 10);
                        }

                        fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());

                    }


                }
            });


        } else {
         Toast.makeText(requireActivity(), "Turn on location", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS);
                startActivity(intent);
        }
    }

    private void backPressed() {

        view.setFocusableInTouchMode(true);

        view.requestFocus();

        view.setOnKeyListener(new View.OnKeyListener() {

            @Override
            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if (keyEvent.getAction() == KeyEvent.ACTION_DOWN) {

                    if (i == KeyEvent.KEYCODE_BACK) {

                        final Dialog dialog = new Dialog(requireActivity());
                        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        dialog.setCancelable(true);
                        dialog.setContentView(R.layout.exit_app_dialog);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

                        TextView yesBtn = dialog.findViewById(R.id.yesText);
                        TextView noBtn = dialog.findViewById(R.id.noText);

                        yesBtn.setOnClickListener(view1 -> {
                            requireActivity().finishAffinity();

                        });

                        noBtn.setOnClickListener(view1 -> {
                            dialog.dismiss();
                        });

                        dialog.show();

                        return true;

                    }
                }

                return false;
            }

        });
    }


}

