package com.expert.healthkangaroodriver.phlebotomist_driver;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.expert.healthkangaroodriver.Model.ChatModel.ChatModel;
import com.expert.healthkangaroodriver.Model.ChatModel.LastMessageChatModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.PhlebotomistDriverSampleCollectionModel;
import com.expert.healthkangaroodriver.adapter_class.pharmacy_adapters.ChatPharmacyUserAdapter;
import com.expert.healthkangaroodriver.adapter_class.phlebotomist_adapters.ChatAdapter;
import com.example.healthkangaroo.R;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;


public class ChatMessagingStartScreenPhlebotomistFragment extends Fragment {

    private View sView;
    private ImageView mBack;
    private ChatModel chatModelClass;
    private EditText edtMessage;
    private ImageView imgSend;
    private RecyclerView rcChat;
    private ChatPharmacyUserAdapter chatAdapter;
    String driverId, userId, orderId;
    private List<ChatModel> list = new ArrayList<>();
    public static PhlebotomistDriverSampleCollectionModel.Detail detail;

    private DatabaseReference reference = FirebaseDatabase.getInstance().getReference().child("ChatUserLabDriver");

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_chat_messaging_start_screen, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        sView = view;

        orderId = detail.getAppointmentId();

        findId();
        clickListener();
        senderReceiverIds();
        getMessagesFromFirebase();


    }

    private void senderReceiverIds() {
        driverId = detail.getLabDriverId();
        userId = detail.getUserId();
    }
    private void clickListener() {
        mBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Navigation.findNavController(v).navigate(R.id.action_chatMessagingStartScreen_to_myDeliveryStartScreenPhlebo);

            }
        });
        imgSend.setOnClickListener(v -> {

            if (edtMessage.getText().toString().isEmpty()) {
                Toast.makeText(requireContext(), "Can't Send Empty Message", Toast.LENGTH_SHORT).show();
            } else {
                sendMessage(edtMessage.getText().toString(), "0");
                getMessagesFromFirebase();
            }

        });


    }
    private void sendMessage(String message, String type) {

        orderId = detail.getAppointmentId();

        String currentDate = new SimpleDateFormat("dd-MM-yyyy", Locale.getDefault()).format(new Date());
        String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());

        String key = reference.push().getKey();

        chatModelClass = new ChatModel();
        chatModelClass.setMessage(message);
        chatModelClass.setDate(currentDate);
        chatModelClass.setTime(currentTime);
        chatModelClass.setType(type);
        chatModelClass.setKey(key);

        reference.child(driverId).child(orderId).child(key).setValue(chatModelClass).addOnSuccessListener(new OnSuccessListener<Void>() {
            @Override
            public void onSuccess(Void unused) {

                edtMessage.setText("");

                Toast.makeText(getActivity(), "Message send successfully.", Toast.LENGTH_SHORT).show();

            }
        }).addOnFailureListener(e -> {

        });

    }
    private void getMessagesFromFirebase() {
        list = new ArrayList<>();

        reference.child(driverId).child(orderId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    list.clear();
                    for (DataSnapshot dataSnapshot : snapshot.getChildren()) {

                        ChatModel driverChatModel = dataSnapshot.getValue(ChatModel.class);
                        list.add(driverChatModel);
                    }

                    setRecyclerView(list);

                } else {

                    Toast.makeText(requireContext(), "Not found", Toast.LENGTH_SHORT).show();

                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }
    private void setRecyclerView(List<ChatModel> list) {
        chatAdapter = new ChatPharmacyUserAdapter(requireActivity(), list);
        rcChat.setAdapter(chatAdapter);
        rcChat.smoothScrollToPosition(list.size());
        chatAdapter.notifyDataSetChanged();
    }
    private void findId() {
        rcChat = sView.findViewById(R.id.recycler_view_chat);
        mBack = sView.findViewById(R.id.img_back_chat);
        edtMessage = sView.findViewById(R.id.editxt_write_message);
        imgSend = sView.findViewById(R.id.send_msg);

    }
}