package com.expert.healthkangaroodriver.Model.ambulance_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PatientDetailsAmbulanceDriverModel {

    @SerializedName("success")
    @Expose
    private String success;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("details")
    @Expose
    private Details details;

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Details getDetails() {
        return details;
    }

    public void setDetails(Details details) {
        this.details = details;
    }
    public class Details {

        @SerializedName("patientConditionId")
        @Expose
        private String patientConditionId;
        @SerializedName("driverId")
        @Expose
        private String driverId;
        @SerializedName("hosId")
        @Expose
        private String hosId;
        @SerializedName("userId")
        @Expose
        private String userId;
        @SerializedName("patient_condition")
        @Expose
        private String patientCondition;
        @SerializedName("user_lat")
        @Expose
        private String userLat;
        @SerializedName("user_long")
        @Expose
        private String userLong;
        @SerializedName("hos_lat")
        @Expose
        private String hosLat;
        @SerializedName("hos_long")
        @Expose
        private String hosLong;
        @SerializedName("total_price")
        @Expose
        private String totalPrice;
        @SerializedName("driver_name")
        @Expose
        private String driverName;
        @SerializedName("Ambulance_ph")
        @Expose
        private String ambulancePh;
        @SerializedName("ambulance_number")
        @Expose
        private String ambulanceNumber;
        @SerializedName("ambulance_photo")
        @Expose
        private String ambulancePhoto;
        @SerializedName("ambulance_fixPrice")
        @Expose
        private String ambulanceFixPrice;
        @SerializedName("ambulance_perKmPrice")
        @Expose
        private String ambulancePerKmPrice;
        @SerializedName("hospitalName")
        @Expose
        private String hospitalName;
        @SerializedName("Hospital_Photo")
        @Expose
        private String hospitalPhoto;
        @SerializedName("Hospital_License")
        @Expose
        private String hospitalLicense;
        @SerializedName("username")
        @Expose
        private String username;
        @SerializedName("userImage")
        @Expose
        private String userImage;
        @SerializedName("gender")
        @Expose
        private String gender;
        @SerializedName("user_ph")
        @Expose
        private String userPh;
        @SerializedName("patient_no")
        @Expose
        private String patientNo;

        public String getPatientConditionId() {
            return patientConditionId;
        }

        public void setPatientConditionId(String patientConditionId) {
            this.patientConditionId = patientConditionId;
        }

        public String getDriverId() {
            return driverId;
        }

        public void setDriverId(String driverId) {
            this.driverId = driverId;
        }

        public String getHosId() {
            return hosId;
        }

        public void setHosId(String hosId) {
            this.hosId = hosId;
        }

        public String getUserId() {
            return userId;
        }

        public void setUserId(String userId) {
            this.userId = userId;
        }

        public String getPatientCondition() {
            return patientCondition;
        }

        public void setPatientCondition(String patientCondition) {
            this.patientCondition = patientCondition;
        }

        public String getUserLat() {
            return userLat;
        }

        public void setUserLat(String userLat) {
            this.userLat = userLat;
        }

        public String getUserLong() {
            return userLong;
        }

        public void setUserLong(String userLong) {
            this.userLong = userLong;
        }

        public String getHosLat() {
            return hosLat;
        }

        public void setHosLat(String hosLat) {
            this.hosLat = hosLat;
        }

        public String getHosLong() {
            return hosLong;
        }

        public void setHosLong(String hosLong) {
            this.hosLong = hosLong;
        }

        public String getTotalPrice() {
            return totalPrice;
        }

        public void setTotalPrice(String totalPrice) {
            this.totalPrice = totalPrice;
        }

        public String getDriverName() {
            return driverName;
        }

        public void setDriverName(String driverName) {
            this.driverName = driverName;
        }

        public String getAmbulancePh() {
            return ambulancePh;
        }

        public void setAmbulancePh(String ambulancePh) {
            this.ambulancePh = ambulancePh;
        }

        public String getAmbulanceNumber() {
            return ambulanceNumber;
        }

        public void setAmbulanceNumber(String ambulanceNumber) {
            this.ambulanceNumber = ambulanceNumber;
        }

        public String getAmbulancePhoto() {
            return ambulancePhoto;
        }

        public void setAmbulancePhoto(String ambulancePhoto) {
            this.ambulancePhoto = ambulancePhoto;
        }

        public String getAmbulanceFixPrice() {
            return ambulanceFixPrice;
        }

        public void setAmbulanceFixPrice(String ambulanceFixPrice) {
            this.ambulanceFixPrice = ambulanceFixPrice;
        }

        public String getAmbulancePerKmPrice() {
            return ambulancePerKmPrice;
        }

        public void setAmbulancePerKmPrice(String ambulancePerKmPrice) {
            this.ambulancePerKmPrice = ambulancePerKmPrice;
        }

        public String getHospitalName() {
            return hospitalName;
        }

        public void setHospitalName(String hospitalName) {
            this.hospitalName = hospitalName;
        }

        public String getHospitalPhoto() {
            return hospitalPhoto;
        }

        public void setHospitalPhoto(String hospitalPhoto) {
            this.hospitalPhoto = hospitalPhoto;
        }

        public String getHospitalLicense() {
            return hospitalLicense;
        }

        public void setHospitalLicense(String hospitalLicense) {
            this.hospitalLicense = hospitalLicense;
        }

        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getUserImage() {
            return userImage;
        }

        public void setUserImage(String userImage) {
            this.userImage = userImage;
        }

        public String getGender() {
            return gender;
        }

        public void setGender(String gender) {
            this.gender = gender;
        }

        public String getUserPh() {
            return userPh;
        }

        public void setUserPh(String userPh) {
            this.userPh = userPh;
        }

        public String getPatientNo() {
            return patientNo;
        }

        public void setPatientNo(String patientNo) {
            this.patientNo = patientNo;
        }

    }
}