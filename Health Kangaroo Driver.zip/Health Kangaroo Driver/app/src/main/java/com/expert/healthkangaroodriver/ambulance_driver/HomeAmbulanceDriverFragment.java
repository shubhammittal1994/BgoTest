package com.expert.healthkangaroodriver.ambulance_driver;

import static android.Manifest.permission.ACCESS_COARSE_LOCATION;
import static android.Manifest.permission.ACCESS_FINE_LOCATION;
import static android.content.Context.LOCATION_SERVICE;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.drawable.ColorDrawable;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.provider.Settings;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.widget.AppCompatButton;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;

import com.bumptech.glide.Glide;
import com.directions.route.AbstractRouting;
import com.directions.route.Route;
import com.directions.route.RouteException;
import com.directions.route.Routing;
import com.directions.route.RoutingListener;
import com.example.healthkangaroo.BuildConfig;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.NotificationCountModal;
import com.expert.healthkangaroodriver.Model.ReferralCountModal;
import com.expert.healthkangaroodriver.Model.ambulance_model.LogoutAmbulanceModel;
import com.expert.healthkangaroodriver.Model.ambulance_model.PatientInformation.PatientInformation;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;
import com.github.angads25.toggle.interfaces.OnToggledListener;
import com.github.angads25.toggle.model.ToggleableView;
import com.github.angads25.toggle.widget.LabeledSwitch;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.navigation.NavigationView;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import de.hdodenhof.circleimageview.CircleImageView;


public class HomeAmbulanceDriverFragment extends Fragment implements OnMapReadyCallback, RoutingListener, GoogleApiClient.ConnectionCallbacks, android.location.LocationListener {

    private static final String TAG = "";
    private View view;
    private CardView card_before_accept;
    private TextView txt_name_before, total_notification_count, referral_case_count, txt_address_before, txt_offline_before, txt_online_before, txt_patient_name, txt_patient_address;
    private Button btn_start_dialog;
    private LinearLayout ll_dialog;
    private LabeledSwitch switch_before;
    private ImageView menu_img, img_profile_pic_before, imgCurrentLocation, img_notify;
    private DrawerLayout drawerLayout;
    DatabaseReference reference = FirebaseDatabase.getInstance("https://healthkangaroouser-default-rtdb.firebaseio.com/").getReference();
    public static double myLat, myLng;
    private ProgressDialog progressDialog;
    private NavigationView side_nav_ambulance_driver;
    private ViewModelClass viewModel = new ViewModelClass();
    private String strDriverId, strHospitalID, userName;
    private Address address;
    int permissionCode = 123;
    private GoogleMap mMap;
    FusedLocationProviderClient fusedLocationProviderClient;
    LocationManager locationManager;
    LocationManager locationManage;
    private Location location;
    private Geocoder geocoder;
    private double lat = 0.00, log = 0.00;
    String[] permissions = {Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION};
    private LatLng latLng;
    private LocationRequest locationRequest;
    private GoogleApiClient googleApiClient;
    SupportMapFragment mapFragment;
    private AppCompatButton upload_details, upload_condition;
    private CircleImageView patience_profile_image;
    public static PatientInformation information;
    public static String type, username, phone, relation;
    LinearLayout referral_case;
    final int EARTH_RADIUS_KM = 6371;
    LatLng start, end;
    double hos_lat, hos_long;
    double lati;
    double lon;
    double speed = 0;
    double time = 0;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        view = inflater.inflate(R.layout.fragment_home_ambulance_driver, container, false);

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(requireContext());
        locationManager = (LocationManager) requireActivity().getSystemService(LOCATION_SERVICE);


        hos_lat = Double.parseDouble(App.getSharedPref().getStringValue("hos_lat"));
        hos_long = Double.parseDouble(App.getSharedPref().getStringValue("hos_long"));

        start = new LatLng(myLat, myLng);
        end = new LatLng(hos_lat, hos_long);


        if (ActivityCompat.checkSelfPermission(requireActivity(), ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireActivity(), ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            Toast.makeText(requireContext(), "permission Check", Toast.LENGTH_SHORT).show();

            ActivityCompat.requestPermissions(requireActivity(), permissions, 10);

        } else {

            getCurrentLocation();

        }
        mapFragment = (SupportMapFragment) getChildFragmentManager().findFragmentById(R.id.google_map_fragment);
        if (mapFragment != null) {

            mapFragment.getMapAsync(this);
        }
        progressDialog = new ProgressDialog(requireActivity());
        progressDialog.setMessage("Wait Your Location Is Fetching.....");
        findID();


        img_notify.setOnClickListener(v -> {

            Navigation.findNavController(v).navigate(R.id.ambulanceNotificationFragment);
        });
        geocoder = new Geocoder(requireContext());
        strDriverId = App.getSharedPref().getStringValue("DriverId");
        strHospitalID = App.getSharedPref().getStringValue("HospitalId");
        userName = App.getSharedPref().getStringValue("Username");
        receiveData();
        switchCondition();
        setData();
        navigationMenuHandler();
        Clicks();
        onOffStatus();
        backPressed();
        new ViewModelClass().referralCountModalMutableLiveData(requireActivity(),
                strDriverId).observe(requireActivity(), new Observer<ReferralCountModal>() {
            @Override
            public void onChanged(ReferralCountModal referralCountModal) {
                if (referralCountModal.getSuccess().equalsIgnoreCase("1")) {
                    referral_case_count.setText(String.valueOf(referralCountModal.getCounts()));
                }
            }
        });


        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        notificationCount();
        upDateLocation();
    }

    private void upDateLocation() {

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("driverCurrentLocation");


        Map map = new HashMap();
        map.put("latitude", myLat);
        map.put("longitude", myLng);
        map.put("driverId", strDriverId);
        map.put("hos_lat", App.getSharedPref().getStringValue("hos_lat"));
        map.put("hos_long", App.getSharedPref().getStringValue("hos_long"));
        map.put("distance", "");
        map.put("time", time);
        map.put("speed", speed);

        reference.child(strDriverId).setValue(map);

    }


    private void notificationCount() {
        new ViewModelClass().notificationCountModalMutableLiveData(requireActivity(), strDriverId).observe(requireActivity(), new Observer<NotificationCountModal>() {
            @Override
            public void onChanged(NotificationCountModal notificationCountModal) {
                if (notificationCountModal.getSuccess().equalsIgnoreCase("1")) {

                    total_notification_count.setText(notificationCountModal.getDetails() + "");
                } else {

                }
            }
        });
    }

    private void onOffStatus() {
        reference = FirebaseDatabase.getInstance().getReference("DoctorDriverStatus");
        reference.child(strDriverId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String type = snapshot.child("type").getValue().toString();

                    if (type.equalsIgnoreCase("online")) {
                        switch_before.setOn(true);
                        txt_offline_before.setVisibility(View.GONE);
                        txt_online_before.setVisibility(View.VISIBLE);

                    } else if (type.equalsIgnoreCase("offline")) {
                        switch_before.setOn(false);
                    }
                }

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    private void receiveData() {

        reference = FirebaseDatabase.getInstance().getReference("ambulanceRequest");


        reference.child(strDriverId).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {

                    String driverId = snapshot.child("driverId").getValue().toString();
                    String address = snapshot.child("address").getValue().toString();
                    String emergencyType = snapshot.child("emergencyType").getValue().toString();
                    String lat = snapshot.child("lat").getValue().toString();
                    String log = snapshot.child("log").getValue().toString();
                    String name = snapshot.child("name").getValue().toString();
                    String phone = snapshot.child("phone").getValue().toString();
                    String relation = snapshot.child("relation").getValue().toString();
                    String userId = snapshot.child("userId").getValue().toString();
                    String userImage = snapshot.child("userImage").getValue().toString();

                    openPopUpBox(driverId, address, emergencyType, lat, log, name, phone, relation, userId, userImage);
                } else {
                    Toast.makeText(requireContext(), "Request not found!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

    }

    private void openPopUpBox(String driverId, String address, String emergencyType,
                              String lat, String log, String name, String phone,
                              String relation, String userId, String userImage) {

        ll_dialog.setVisibility(View.VISIBLE);
        txt_patient_name.setText(name);
        txt_patient_address.setText(address);

        type = emergencyType;
        username = name;
        phone = phone;
        relation = relation;

        Glide.with(getContext()).load(userImage).placeholder(R.drawable.user).into(patience_profile_image);

        patience_profile_image.setOnClickListener(v -> {

            final Dialog dialog = new Dialog(requireActivity());
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(R.layout.zoom_image_layout);
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

            ImageView imageView = dialog.findViewById(R.id.full_image);

            Glide.with(getContext()).load(information.getUserImage()).into(imageView);

            dialog.show();

        });

        App.getSharedPref().saveString("PatienceName", name);
        App.getSharedPref().saveString("PatienceAddress", address);
        App.getSharedPref().saveString("PatienceMobile", phone);
        App.getSharedPref().saveString("RelationWithPatience", relation);
        App.getSharedPref().saveString("PatienceLatitude", "30.7333");
        App.getSharedPref().saveString("PatienceLongitude", "76.7794");
        App.getSharedPref().saveString("PatienceImage", userImage);
        App.getSharedPref().saveString("userID", userId);

        btn_start_dialog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Bundle bundle = new Bundle();
                bundle.putString("MyLat", String.valueOf(lat));
                bundle.putString("MyLog", String.valueOf(log));
                bundle.putString("driverLat", String.valueOf(myLat));
                bundle.putString("driverLong", String.valueOf(myLng));
                bundle.putString("address", address);
                bundle.putString("Page", "first");

                Navigation.findNavController(v).navigate(R.id.action_homeAmbulanceDriverFragment_to_startAmbulanceDriverFragment, bundle);
            }
        });

    }

    private void Clicks() {
        imgCurrentLocation.setOnClickListener(v -> {

            if (ActivityCompat.checkSelfPermission(requireContext(),
                    Manifest.permission.ACCESS_FINE_LOCATION) !=
                    PackageManager.PERMISSION_GRANTED && ActivityCompat.
                    checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED) {

                return;

            }

            CameraUpdate cameraUpdate = CameraUpdateFactory.newLatLngZoom(latLng, 18);

            upDateLocation();

            mMap.animateCamera(cameraUpdate);
        });


        upload_details.setOnClickListener(v -> {


            Navigation.findNavController(v).navigate(R.id.uploadPatienceDetailsAmbulanceDriverFragment);
        });

        referral_case.setOnClickListener(v -> {

            Navigation.findNavController(v).navigate(R.id.referralCaseFragment);
        });

    }

    private void switchCondition() {

        switch_before.setOnToggledListener(new OnToggledListener() {
            @Override
            public void onSwitched(ToggleableView toggleableView, boolean isOn) {
                if (switch_before.isOn()) {

                    hitApiOnLineStatus("online", App.getSharedPref().getStringValue("HospitalId"), App.getSharedPref().getStringValue("DriverId"), lat, log);
                    hitDriverStatus("online", App.getSharedPref().getStringValue("DriverId"));

                    txt_offline_before.setVisibility(View.GONE);
                    switch_before.setBackgroundResource(R.drawable.bg_accept_btn);
                    txt_online_before.setVisibility(View.VISIBLE);

                } else {
                    hitApiOnLineStatus("offline", App.getSharedPref().getStringValue("HospitalId"), App.getSharedPref().getStringValue("DriverId"), lat, log);
                    hitDriverStatus("offline", App.getSharedPref().getStringValue("DriverId"));

                    txt_offline_before.setVisibility(View.VISIBLE);
                    txt_online_before.setVisibility(View.GONE);
                    switch_before.setBackgroundResource(R.drawable.bg_reject_btn);
                    ll_dialog.setVisibility(View.GONE);

                }
            }
        });

    }

    private void hitDriverStatus(String type, String driverId) {
        reference = FirebaseDatabase.getInstance().getReference("DoctorDriverStatus");

        Map map = new HashMap();
        map.put("DoctorId", driverId);
        map.put("type", type);

        reference.child(driverId).setValue(map);

    }

    private void hitApiOnLineStatus(String type, String hospital_id, String driverId, double lat, double log) {

        viewModel.statusAmbulanceDriver(requireActivity(), type, hospital_id, driverId, Double.toString(lat), Double.toString(log)).observe(requireActivity(), ambulanceDriverStatusModel -> {

            if (ambulanceDriverStatusModel.getSuccess().equalsIgnoreCase("1")) {
                if (switch_before.isOn()) {

                    try {
                        receiveData();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } else {
                ll_dialog.setVisibility(View.GONE);
            }
        });

    }

    private void setData() {
        txt_name_before.setText(App.getSingleton().getName());
        txt_address_before.setText(App.getSingleton().getAddress());
        Glide.with(view).load(App.getSharedPref().getStringValue("Image")).into(img_profile_pic_before);

    }

    private void navigationMenuHandler() {

        drawerLayout = view.findViewById(R.id.drawer_layout);
        side_nav_ambulance_driver = view.findViewById(R.id.side_nav_ambulance_driver);


        menu_img = view.findViewById(R.id.img_menu);
        menu_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });


        View headerView = side_nav_ambulance_driver.getHeaderView(0);
        TextView drawerName = headerView.findViewById(R.id.txt_name_drawer);
        ImageView drawerImage = headerView.findViewById(R.id.img_profile_picDriver);

        drawerName.setText(App.getSingleton().getName());
        Glide.with(view).load(App.getSharedPref().getStringValue("Image")).into(drawerImage);


        Menu menuNav = side_nav_ambulance_driver.getMenu();
        MenuItem item_my_profile, item_upload_patience_details, item_service_history, share_app, item_referral_case, item_my_wallet, item_about, item_terms_conditions, item_report, item_logout;

        item_my_profile = menuNav.findItem(R.id.item_my_profile);
        item_upload_patience_details = menuNav.findItem(R.id.item_upload_patience_details);
        item_service_history = menuNav.findItem(R.id.item_service_history);
        item_my_wallet = menuNav.findItem(R.id.item_my_wallet);
        item_referral_case = menuNav.findItem(R.id.item_referral_case);
        item_about = menuNav.findItem(R.id.item_about);
        item_terms_conditions = menuNav.findItem(R.id.item_terms_conditions);
        item_report = menuNav.findItem(R.id.item_report);
        item_logout = menuNav.findItem(R.id.item_logout);
        share_app = menuNav.findItem(R.id.share_app);


        item_my_profile.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                Navigation.findNavController(view).navigate(R.id.action_homeAmbulanceDriverFragment_to_myProfileAmbulanceDriverFragment2);
                return false;
            }
        });
        share_app.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                try {
                    Intent shareIntent = new Intent(Intent.ACTION_SEND);
                    shareIntent.setType("text/plain");
                    shareIntent.putExtra(Intent.EXTRA_SUBJECT, "Health kangaroo driver");
                    String shareMessage = "\nLet me recommend you this application\n\n";
                    shareMessage = shareMessage + "https://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID + "\n\n";
                    shareIntent.putExtra(Intent.EXTRA_TEXT, shareMessage);
                    startActivity(Intent.createChooser(shareIntent, "choose one"));
                } catch (Exception e) {
                    //e.toString();
                }
                return false;
            }
        });

        item_referral_case.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Navigation.findNavController(view).navigate(R.id.referralCaseFragment);
                return false;
            }
        });

        item_upload_patience_details.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Navigation.findNavController(view).navigate(R.id.action_homeAmbulanceDriverFragment_to_uploadPatienceDetailsAmbulanceDriverFragment);
                return false;
            }
        });

        item_service_history.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Navigation.findNavController(view).navigate(R.id.action_homeAmbulanceDriverFragment_to_orderDetailsFragment);

                return false;
            }
        });

        item_my_wallet.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Navigation.findNavController(view).navigate(R.id.action_homeAmbulanceDriverFragment_to_myWalletAmbulanceDriverFragment);
                return false;
            }
        });

        item_about.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Navigation.findNavController(view).navigate(R.id.action_homeAmbulanceDriverFragment_to_aboutAmbulanceDriverFragment);
                return false;
            }
        });

        item_terms_conditions.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                Navigation.findNavController(view).navigate(R.id.action_homeAmbulanceDriverFragment_to_termsAndConditionAmbulanceDriverFragment);
                return false;
            }
        });

        item_report.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                final Dialog dialog = new Dialog(requireActivity());
                dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                dialog.setContentView(R.layout.call_layout);
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

                ImageView call_btn = dialog.findViewById(R.id.call_btn_call);
                ImageView email_btn = dialog.findViewById(R.id.mail_btn);
                TextView call_txt = dialog.findViewById(R.id.call_txt);

                call_btn.setOnClickListener(v -> {

                    Intent callIntent = new Intent(Intent.ACTION_CALL);
                    callIntent.setData(Uri.parse("tel:" + call_txt.getText().toString()));
                    startActivity(callIntent);
                    dialog.dismiss();

                });

                email_btn.setOnClickListener(v -> {
                    final Intent emailIntent = new Intent(android.content.Intent.ACTION_SEND);
                    emailIntent.setType("plain/text");
                    emailIntent.putExtra(android.content.Intent.EXTRA_EMAIL, new String[]{"Test123@gmail.com"});
                    emailIntent.putExtra(android.content.Intent.EXTRA_SUBJECT, "Subject");
                    emailIntent.putExtra(android.content.Intent.EXTRA_TEXT, "Text");
                    requireActivity().startActivity(Intent.createChooser(emailIntent, "Send mail..."));
                    dialog.dismiss();

                });

                dialog.show();


                return false;
            }
        });

        item_logout.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {

                AlertDialog.Builder alert = new AlertDialog.Builder(requireActivity());
                alert.setIcon(R.drawable.ic_warning).setTitle("Logout");
                alert.setMessage("Do you want to Logout?");

                alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        viewModel.LiveDataLogoutAmbulance(requireActivity(), strHospitalID, strDriverId).observe(requireActivity(), new Observer<LogoutAmbulanceModel>() {
                            @Override
                            public void onChanged(LogoutAmbulanceModel logoutAmbulanceModel) {
                                if (logoutAmbulanceModel.getSuccess().equalsIgnoreCase("1")) {
                                    App.getSharedPref().clearPreferences();

                                    Navigation.findNavController(view).navigate(R.id.loginScreenFragment);

                                    Toast.makeText(requireContext(), logoutAmbulanceModel.getMessage(), Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(requireContext(), logoutAmbulanceModel.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                    }
                });

                alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                alert.show();


                return false;
            }
        });


    }

    private void findID() {
        ll_dialog = view.findViewById(R.id.ll_dialog);
        btn_start_dialog = view.findViewById(R.id.btn_start_dialog);
        patience_profile_image = view.findViewById(R.id.patience_profile_image);
        upload_details = view.findViewById(R.id.upload_details);
        referral_case = view.findViewById(R.id.referral_case);
        referral_case_count = view.findViewById(R.id.referral_case_count);
        img_notify = view.findViewById(R.id.img_notify);
        total_notification_count = view.findViewById(R.id.total_notification_count);

        card_before_accept = view.findViewById(R.id.card_before_accept);

        imgCurrentLocation = view.findViewById(R.id.imgCurrentLocation);
        menu_img = view.findViewById(R.id.img_menu);

        txt_name_before = view.findViewById(R.id.txt_name_before);
        txt_address_before = view.findViewById(R.id.txt_address_before);
        img_profile_pic_before = view.findViewById(R.id.img_profile_pic_before);

        switch_before = view.findViewById(R.id.swAmbulance);
        txt_offline_before = view.findViewById(R.id.textOffline_ambulance);
        txt_online_before = view.findViewById(R.id.textOnline_ambulance);

        txt_patient_name = view.findViewById(R.id.txt_patient_name);
        txt_patient_address = view.findViewById(R.id.txt_patient_address);
        upload_condition = view.findViewById(R.id.upload_condition);


    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;

        try {

            List<Address> addressList = geocoder.getFromLocation(App.getSingleton().getLat(), App.getSingleton().getLog(), 1);

            address = addressList.get(0);
            myLat = address.getLatitude();
            myLng = address.getLongitude();
            latLng = new LatLng(address.getLatitude(), address.getLongitude());

            if (ContextCompat.checkSelfPermission(requireActivity(), android.Manifest.permission.ACCESS_FINE_LOCATION) ==
                    PackageManager.PERMISSION_GRANTED &&
                    ContextCompat.checkSelfPermission(requireActivity(), android.Manifest.permission.ACCESS_COARSE_LOCATION) ==
                            PackageManager.PERMISSION_GRANTED) {
                googleMap.setMyLocationEnabled(true);
                googleMap.getUiSettings().setMyLocationButtonEnabled(true);
            } else {
                ActivityCompat.requestPermissions(requireActivity(), new String[]{
                                Manifest.permission.ACCESS_FINE_LOCATION,
                                Manifest.permission.ACCESS_COARSE_LOCATION},
                        permissionCode);

            }
            mMap.setMyLocationEnabled(true); // get your maps fragment
            mMap.getUiSettings().setMyLocationButtonEnabled(false);
            mMap.getMyLocation();
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 18));


        } catch (IOException e) {
            e.printStackTrace();
        }


    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {

        locationRequest = new LocationRequest();
        locationRequest.setInterval(2000);
        locationRequest.setFastestInterval(2000);

        locationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
        if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, locationRequest, (LocationListener) this);
        }

    }


    @Override
    public void onConnectionSuspended(int i) {
    }

    private void getCurrentLocation() {

        if (ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(requireActivity(),
                        Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(requireActivity(), permissions, 10);
        }

        if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) || locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {


            fusedLocationProviderClient.getLastLocation().addOnCompleteListener(new OnCompleteListener<Location>() {
                @Override
                public void onComplete(@NonNull Task<Location> task) {
                    location = task.getResult();

                    if (location != null) {
                        progressDialog.dismiss();
                        lat = location.getLatitude();
                        log = location.getLongitude();


                    } else {
                        progressDialog.show();
                        LocationRequest locationRequest = new LocationRequest().setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY).setInterval(1000).setFastestInterval(1000).setNumUpdates(1);

                        LocationCallback locationCallback = new LocationCallback() {
                            @Override
                            public void onLocationResult(@NonNull LocationResult locationResult) {
                                super.onLocationResult(locationResult);

                                Location location1 = locationResult.getLastLocation();

                                lat = (long) location1.getLongitude();
                                log = (long) location1.getLongitude();

                                App.getSingleton().setLat(lat);
                                App.getSingleton().setLog(log);

                            }
                        };

                        if (ActivityCompat.checkSelfPermission(requireActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireActivity(),
                                Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(requireActivity(), permissions, 10);

                        }
                        fusedLocationProviderClient.requestLocationUpdates(locationRequest, locationCallback, Looper.myLooper());

                    }


                }
            });


        } else {

            Toast.makeText(requireActivity(), "Turn on location", Toast.LENGTH_LONG).show();
            startActivityForResult(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS), 1);

        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 10) {

            if (ActivityCompat.checkSelfPermission(requireActivity(), ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(requireActivity(), ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(requireContext(), "permission Check", Toast.LENGTH_SHORT).show();
                ActivityCompat.requestPermissions(requireActivity(), permissions, 10);
            } else {
                getCurrentLocation();

            }

        }

    }

    private void backPressed() {
        view.setFocusableInTouchMode(true);
        view.requestFocus();
        view.setOnKeyListener(new View.OnKeyListener() {
            @Override

            public boolean onKey(View view, int i, KeyEvent keyEvent) {
                if (keyEvent.getAction() == KeyEvent.ACTION_DOWN) {

                    if (i == KeyEvent.KEYCODE_BACK) {

                        final Dialog dialog = new Dialog(requireActivity());
                        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
                        dialog.setCancelable(true);
                        dialog.setContentView(R.layout.exit_app_dialog);
                        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));

                        TextView yesBtn = dialog.findViewById(R.id.yesText);
                        TextView noBtn = dialog.findViewById(R.id.noText);

                        yesBtn.setOnClickListener(view1 -> {

                            requireActivity().finishAffinity();

                        });

                        noBtn.setOnClickListener(view1 -> {
                            dialog.dismiss();
                        });


                        dialog.show();

                        return true;

                    }
                }

                return false;
            }

        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == 1) {
            switch (requestCode) {
                case 1:
                    break;
            }
        }
    }

    public void Findroutes(LatLng Start, LatLng End) {

        if (Start == null || End == null) {
            Toast.makeText(requireActivity(), "Unable to get location", Toast.LENGTH_LONG).show();
        } else {

            Routing routing = new Routing.Builder()
                    .travelMode(AbstractRouting.TravelMode.DRIVING)
                    .withListener(this)
                    .alternativeRoutes(true)
                    .waypoints(Start, End)
                    .key(getContext().getString(R.string.api_map_key))  //also define your api key here.
                    .build();
            routing.execute();

        }
    }

    @Override
    public void onLocationChanged(Location location) {

        if (location == null) {
            // if you can't get speed because reasons :)
            // Toast.makeText(requireContext(), "00 km/h", Toast.LENGTH_SHORT).show();
            Findroutes(start, end);

        } else {
            //int speed=(int) ((location.getSpeed()) is the standard which returns meters per second. In this example i converted it to kilometers per hour
            Findroutes(start, end);

            int speed = (int) ((location.getSpeed() * 3600) / 1000);

            //   Toast.makeText(requireContext(), "" + speed + " km/h", Toast.LENGTH_SHORT).show();
        }


        try {
            // Get the location manager

            LocationManager locationManager = (LocationManager)
                    getActivity().getSystemService(LOCATION_SERVICE);
            Criteria criteria = new Criteria();
            String bestProvider = locationManager.getBestProvider(criteria, false);
            if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION)
                    != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

                return;
            }
            Location lastKnownLocation = locationManager.getLastKnownLocation(bestProvider);

            try {
                lati = lastKnownLocation.getLatitude();
                lon = lastKnownLocation.getLongitude();
                speed = (int) ((location.getSpeed() * 3600) / 1000);
                time = lastKnownLocation.getTime();

            } catch (NullPointerException e) {
                lati = -1.0;
                lon = -1.0;
            }


            upDateLocation();
        //  Toast.makeText(requireContext(), "time " + time, Toast.LENGTH_SHORT).show();

//            mTxt_lat.setText("" + lat);
//            mTxt_speed.setText("" + speed);



        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void onRoutingFailure(RouteException e) {

    }

    @Override
    public void onRoutingStart() {

    }

    @Override
    public void onRoutingSuccess(ArrayList<Route> arrayList, int i) {

    }

    @Override
    public void onRoutingCancelled() {

    }
}