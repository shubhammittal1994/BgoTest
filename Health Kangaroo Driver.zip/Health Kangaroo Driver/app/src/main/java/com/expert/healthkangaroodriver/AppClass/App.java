package com.expert.healthkangaroodriver.AppClass;

import android.app.Application;
import android.content.Context;

public class App  extends Application {

    public static Singleton singleton;
    public static SharedPref sharedPref;

    Context context;


    public static Singleton getSingleton() {
        return singleton;
    }

    public static SharedPref getSharedPref() {
        return sharedPref;
    }

    @Override
    public void onCreate() {
        super.onCreate();
        singleton=new Singleton();
        context = getApplicationContext();
        sharedPref = new SharedPref(context);
    }

}
