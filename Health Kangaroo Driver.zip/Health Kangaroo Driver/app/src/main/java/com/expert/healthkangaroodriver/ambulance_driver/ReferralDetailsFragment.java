package com.expert.healthkangaroodriver.ambulance_driver;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.healthkangaroo.R;
import com.example.healthkangaroo.databinding.FragmentReferralDetailsBinding;
import com.expert.healthkangaroodriver.Model.ReferralCaseModal;


public class ReferralDetailsFragment extends Fragment {

    FragmentReferralDetailsBinding binding;
    public static ReferralCaseModal.Detail detail;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        binding  = FragmentReferralDetailsBinding.inflate(inflater, container, false);

        binding.drivername.setText(detail.getBookingId());
        binding.driverName1.setText(detail.getUserName());
        binding.number.setText(detail.getNumber());
        binding.address.setText(detail.getUserAddress());
        binding.ambulanceNumber.setText(detail.getHospitalName());
        binding.ambulanceFixPrice.setText(detail.getFatherName());
        binding.ambulancePerKmPrice.setText(detail.getDate()+"-" +detail.getTime());

        return binding.getRoot();

    }
}