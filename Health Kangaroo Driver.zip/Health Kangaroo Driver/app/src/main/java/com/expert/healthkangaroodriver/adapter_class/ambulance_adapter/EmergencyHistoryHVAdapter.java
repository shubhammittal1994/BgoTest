package com.expert.healthkangaroodriver.adapter_class.ambulance_adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.EmergencyHistoryModel;
import com.expert.healthkangaroodriver.Model.ambulance_model.AmbulanceHistoryModel;

import java.util.List;

public class EmergencyHistoryHVAdapter extends RecyclerView.Adapter<EmergencyHistoryHVAdapter.viewHolder> {
    private final Context requireContext;
    private List<AmbulanceHistoryModel.Detail> list;
    private final CliQ cliQ;

    public EmergencyHistoryHVAdapter(Context requireContext, List<AmbulanceHistoryModel.Detail> list, CliQ cliQ) {
        this.requireContext = requireContext;
        this.list = list;
        this.cliQ = cliQ;
    }

    @NonNull
    @org.jetbrains.annotations.NotNull
    @Override
    public viewHolder onCreateViewHolder(@NonNull @org.jetbrains.annotations.NotNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_emergency_patient_history_hv, parent, false);
        return new viewHolder(view);

    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull viewHolder holder, int position) {

        holder.txtDate.setText("Date : " + list.get(position).getCreated());
        holder.txtCaseNum.setText("Case No : " + list.get(position).getPatientId());
        holder.txtPatientAddress.setText(list.get(position).getPatientAddress());
        Glide.with(requireContext).load(list.get(position).getDischargeHistoryImage()).placeholder(R.drawable.user).into(holder.imgPatient);
        holder.relativeLayoutEmergency.setOnClickListener(v -> cliQ.onCLiQ(list.get(position)));

        if (list.get(position).getCaseType().equalsIgnoreCase("0"))
        {
            holder.case_type.setText("Medical Emergency");

        }else {
            holder.case_type.setText("Accidental Emergency");

        }

    }

    @Override
    public int getItemCount() {

        return list.size();
    }

    public static class viewHolder extends RecyclerView.ViewHolder {
        private final RelativeLayout relativeLayoutEmergency;
        private final ImageView imgPatient;
        private final TextView  txtDate, txtCaseNum , txtPatientAddress, case_type;

        public viewHolder(@NonNull @org.jetbrains.annotations.NotNull View itemView) {
            super(itemView);

            relativeLayoutEmergency = itemView.findViewById(R.id.rl_layout_history_emergency);
            txtCaseNum = itemView.findViewById(R.id.emergency_case_no);
            txtDate = itemView.findViewById(R.id.emergency_date);
            imgPatient = itemView.findViewById(R.id.emergency_img_patient_id);
            txtPatientAddress = itemView.findViewById(R.id.emergency_address);
            case_type = itemView.findViewById(R.id.case_type);

        }
    }

    public interface CliQ {

        void onCLiQ(AmbulanceHistoryModel.Detail list);

    }
}

