package com.expert.healthkangaroodriver.phlebotomist_driver;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.AddPhlebotomistDriverWithdrawlDetailsModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.DeletePhlebotomistAccountDetailsModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.GetPhlebotomistDriverBankDetailsModel;
import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.adapter_class.phlebotomist_adapters.AddAccountPhlebotomistAdapter;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;

import java.util.ArrayList;
import java.util.List;


public class WithdrawPhlebotomistFragment extends Fragment {

    private View view;
    private ImageView back_image;
    private EditText editxt_amount;
    private Button btn_add_account, btn_withdraw;
    private RecyclerView recycler_view_add_account;
    private ViewModelClass viewModel;
    private String strDriverId, strVenderId;
    private List<GetPhlebotomistDriverBankDetailsModel.Detail> accountNumberList;
    private String accountNum;
    private AddAccountPhlebotomistAdapter adapter;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_phlebotomist_withdraw, container, false);


        viewModel = new ViewModelClass();
        accountNumberList = new ArrayList<>();

        strDriverId = App.getSharedPref().getStringValue("DriverId");
        strVenderId = App.getSharedPref().getStringValue("VenderId");

        FindId();
        setAdapter();
        onClick();


        return view;
    }


    private void onClick() {

        back_image.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requireActivity().onBackPressed();
            }
        });

        btn_add_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Navigation.findNavController(v).navigate(R.id.action_chooseBankAccount2_to_addBank);
            }
        });

        btn_withdraw.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                amountWithdraw();
            }
        });


    }

    private void amountWithdraw() {

        String strAmount = editxt_amount.getText().toString();

        if (strAmount.equalsIgnoreCase("")) {

            Toast.makeText(requireActivity(), "Enter Amount", Toast.LENGTH_SHORT).show();

        } else if (accountNum != null && accountNum.equalsIgnoreCase("")) {

            Toast.makeText(requireActivity(), "Please,Select your Account", Toast.LENGTH_SHORT).show();

        } else {

            viewModel.liveDataAddPhlebotomistDriverWithdrawlDetails(requireActivity(), strDriverId, strVenderId, strAmount, accountNum).observe(requireActivity(), new Observer<AddPhlebotomistDriverWithdrawlDetailsModel>() {
                @Override
                public void onChanged(AddPhlebotomistDriverWithdrawlDetailsModel addPhlebotomistDriverWithdrawlDetailsModel) {
                    if (addPhlebotomistDriverWithdrawlDetailsModel.getSuccess().equalsIgnoreCase("1")) {

                        requireActivity().onBackPressed();

                    } else {

                        Toast.makeText(requireContext(), "You don't have sufficient balance", Toast.LENGTH_SHORT).show();

                    }
                }
            });

        }

    }

    private void setAdapter() {

        viewModel.LiveDataGetPhlebotomistDriverBankDetails(requireActivity(), strDriverId, strVenderId).observe(requireActivity(), new Observer<GetPhlebotomistDriverBankDetailsModel>() {
            @Override
            public void onChanged(GetPhlebotomistDriverBankDetailsModel getPhlebotomistDriverBankDetailsModel) {
                if (getPhlebotomistDriverBankDetailsModel.getSuccess().equalsIgnoreCase("1")) {
                    accountNumberList = getPhlebotomistDriverBankDetailsModel.getDetails();
                    Toast.makeText(requireContext(), getPhlebotomistDriverBankDetailsModel.getMessage(), Toast.LENGTH_SHORT).show();

                    adapter = new AddAccountPhlebotomistAdapter(requireActivity(), accountNumberList, new AddAccountPhlebotomistAdapter.SelectedAccount() {
                        @Override
                        public void selectedAccountNumber(String accountNumber) {
                            accountNum = accountNumber;
                        }
                    }, new AddAccountPhlebotomistAdapter.DeleteSelectedAccount() {
                        @Override
                        public void deleteAccountNumber(String accountNumber) {
                            accountNum = accountNumber;

                            AlertDialog.Builder alert = new AlertDialog.Builder(requireActivity());
                            alert.setTitle("Delete Account").setIcon(R.drawable.ic_delete);
                            alert.setMessage("Do you want to delete this account?");
                            alert.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                    viewModel.liveDataDeletePhlebotomistAccountDetails(requireActivity(), strDriverId, strVenderId, accountNum).observe(requireActivity(), new Observer<DeletePhlebotomistAccountDetailsModel>() {
                                        @Override
                                        public void onChanged(DeletePhlebotomistAccountDetailsModel deletePhlebotomistAccountDetailsModel) {
                                            if (deletePhlebotomistAccountDetailsModel.getSuccess().equalsIgnoreCase("1")) {
                                                requireActivity().onBackPressed();
                                            } else {
                                                Toast.makeText(requireActivity(), deletePhlebotomistAccountDetailsModel.getMessage(), Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    });

                                }
                            });

                            alert.setNegativeButton("No", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {

                                }
                            });
                            alert.show();

                        }
                    });
                    recycler_view_add_account.setAdapter(adapter);
                } else {
                    Toast.makeText(requireContext(), getPhlebotomistDriverBankDetailsModel.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    private void FindId() {

        back_image = view.findViewById(R.id.back_image);
        btn_add_account = view.findViewById(R.id.btn_add_account);
        btn_withdraw = view.findViewById(R.id.btn_withdraw);
        editxt_amount = view.findViewById(R.id.editxt_amount);

        recycler_view_add_account = view.findViewById(R.id.recycler_view_add_account);

    }
}