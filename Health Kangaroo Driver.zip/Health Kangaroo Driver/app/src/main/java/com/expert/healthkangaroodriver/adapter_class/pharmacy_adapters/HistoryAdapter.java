package com.expert.healthkangaroodriver.adapter_class.pharmacy_adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.pharmacy_model.HistoryOrderPharmacyModel;

import java.util.List;

public class HistoryAdapter extends RecyclerView.Adapter<HistoryAdapter.ViewHolder> {
    private Context context;
    private List<HistoryOrderPharmacyModel.Detail> list;
    HistoryPosition historyPosition;

    public interface HistoryPosition {
        void details(HistoryOrderPharmacyModel.Detail detail);
    }

    public HistoryAdapter(Context context, List<HistoryOrderPharmacyModel.Detail> list, HistoryPosition historyPosition) {
        this.context = context;
        this.list = list;
        this.historyPosition = historyPosition;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_order__history_list, parent, false);
        return new HistoryAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.txt_appointment_number.setText(list.get(position).getOrderId());
        holder.txt_patience_name.setText(list.get(position).getName());
        holder.txt_patience_phone.setText(list.get(position).getPhone());
        holder.txt_patience_address.setText(list.get(position).getAddress());
        holder.date.setText(list.get(position).getDeliverDate());
        holder.time.setText(list.get(position).getDeliveryTime());

        if (list.get(position).getRefundStatus().equalsIgnoreCase("1")) {
            holder.refund_status.setText("Order Refunded");
        } else {
            holder.refund_status.setText("Order Completed");

        }

        holder.start_btn.setVisibility(View.GONE);

        holder.itemView.setOnClickListener(v -> {

            historyPosition.details(list.get(position));

        });

    }

    @Override
    public int getItemCount() {
        return list.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView txt_appointment_number, txt_patience_name, refund_status, txt_patience_phone, txt_patience_address, date, time;
        Button start_btn, pending_order_btn;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txt_appointment_number = itemView.findViewById(R.id.txt_appointment_number);
            txt_patience_name = itemView.findViewById(R.id.txt_patience_name);
            txt_patience_phone = itemView.findViewById(R.id.txt_patience_phone);
            txt_patience_address = itemView.findViewById(R.id.txt_patience_address);
            date = itemView.findViewById(R.id.date_history);
            time = itemView.findViewById(R.id.time_history);
            start_btn = itemView.findViewById(R.id.start_btn);
            pending_order_btn = itemView.findViewById(R.id.pending_order_btn);
            refund_status = itemView.findViewById(R.id.refund_status);
        }
    }
}
