package com.expert.healthkangaroodriver.ambulance_driver;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.healthkangaroo.R;

public class PaymentActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);
    }
}