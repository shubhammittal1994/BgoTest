package com.expert.healthkangaroodriver.phlebotomist_driver;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.healthkangaroo.R;

public class PendingSampleCollectionsPhlebotomistFragment extends Fragment {
    private View view;
    private ImageView back, patience_profile_image;
    private TextView txt_patience_name, txt_appointment_number, txt_patience_phone, txt_patience_age,
            txt_patience_father_name, txt_patience_email, txt_patience_order_amt, txt_patience_address;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.fragment_pending_sample_collecctions_phlebotomist, container, false);


        findId();
        onClick();
        setDetails();

        return view;
    }


    private void onClick() {

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getActivity().onBackPressed();
            }
        });

    }

    private void setDetails() {

        Bundle bundle = this.getArguments();

        String name = bundle.getString("Name");
        String orderId = bundle.getString("orderId");
        String image = bundle.getString("Image");
        String phone = bundle.getString("Phone");
        String age = bundle.getString("Age");
        String address = bundle.getString("Address");
        String fatherName = bundle.getString("father");
        String price = bundle.getString("email");
        String email = bundle.getString("price");

        txt_patience_name.setText(name);
        txt_appointment_number.setText(orderId);
        txt_patience_phone.setText(phone);
        txt_patience_age.setText(age);
        txt_patience_address.setText(address);
        txt_patience_father_name.setText(fatherName);
        txt_patience_email.setText(email);
        txt_patience_order_amt.setText(price);

    }


    private void findId() {

        back = view.findViewById(R.id.back_image);
        patience_profile_image = view.findViewById(R.id.patience_profile_image);

        txt_appointment_number = view.findViewById(R.id.txt_appointment_number);
        txt_patience_name = view.findViewById(R.id.txt_patience_name_lab);
        txt_patience_phone = view.findViewById(R.id.txt_patience_phone);
        txt_patience_age = view.findViewById(R.id.txt_patience_age);
        txt_patience_father_name= view.findViewById(R.id.txt_patience_father_name);
        txt_patience_email = view.findViewById(R.id.txt_patience_email);
        txt_patience_order_amt = view.findViewById(R.id.txt_order_price);
        txt_patience_address = view.findViewById(R.id.txt_patience_address);

    }

}