package com.expert.healthkangaroodriver.Model.phlebotomist_model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
public class OnOffStatusLabDriverModel {

    @SerializedName("success")
    @Expose
    private String success;
    @SerializedName("message")
    @Expose
    private Message message;

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public Message getMessage() {
        return message;
    }

    public void setMessage(Message message) {
        this.message = message;
    }
    public class Message {

        @SerializedName("on_off_status")
        @Expose
        private String onOffStatus;
        @SerializedName("id")
        @Expose
        private String id;

        public String getOnOffStatus() {
            return onOffStatus;
        }

        public void setOnOffStatus(String onOffStatus) {
            this.onOffStatus = onOffStatus;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

    }
}
