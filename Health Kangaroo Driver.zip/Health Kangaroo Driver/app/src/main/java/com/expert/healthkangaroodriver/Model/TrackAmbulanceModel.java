package com.expert.healthkangaroodriver.Model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class TrackAmbulanceModel {

    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("success")
    @Expose
    private String success;
    @SerializedName("details")
    @Expose
    private List<Detail> details = null;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSuccess() {
        return success;
    }

    public void setSuccess(String success) {
        this.success = success;
    }

    public List<Detail> getDetails() {
        return details;
    }

    public void setDetails(List<Detail> details) {
        this.details = details;
    }
    public class Detail {

        @SerializedName("uniqueDriverId")
        @Expose
        private String uniqueDriverId;
        @SerializedName("id")
        @Expose
        private String id;
        @SerializedName("hospital_id")
        @Expose
        private String hospitalId;
        @SerializedName("driver_id")
        @Expose
        private String driverId;
        @SerializedName("email")
        @Expose
        private String email;
        @SerializedName("password")
        @Expose
        private String password;
        @SerializedName("ambulance_type")
        @Expose
        private String ambulanceType;
        @SerializedName("driver_name")
        @Expose
        private String driverName;
        @SerializedName("department")
        @Expose
        private String department;
        @SerializedName("official_number")
        @Expose
        private String officialNumber;
        @SerializedName("ambulance_number")
        @Expose
        private String ambulanceNumber;
        @SerializedName("ambulance_photo")
        @Expose
        private String ambulancePhoto;
        @SerializedName("address")
        @Expose
        private String address;
        @SerializedName("dob")
        @Expose
        private String dob;
        @SerializedName("reg_id")
        @Expose
        private String regId;
        @SerializedName("device_type")
        @Expose
        private String deviceType;
        @SerializedName("latitude")
        @Expose
        private String latitude;
        @SerializedName("longitude")
        @Expose
        private String longitude;
        @SerializedName("created")
        @Expose
        private String created;
        @SerializedName("updated")
        @Expose
        private String updated;
        @SerializedName("approve_status")
        @Expose
        private String approveStatus;
        @SerializedName("ride_status")
        @Expose
        private String rideStatus;
        @SerializedName("status")
        @Expose
        private String status;
        @SerializedName("amount")
        @Expose
        private String amount;
        @SerializedName("active_status")
        @Expose
        private String activeStatus;
        @SerializedName("type")
        @Expose
        private String type;
        @SerializedName("per_km_price")
        @Expose
        private String perKmPrice;

        public String getUniqueDriverId() {
            return uniqueDriverId;
        }

        public void setUniqueDriverId(String uniqueDriverId) {
            this.uniqueDriverId = uniqueDriverId;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getHospitalId() {
            return hospitalId;
        }

        public void setHospitalId(String hospitalId) {
            this.hospitalId = hospitalId;
        }

        public String getDriverId() {
            return driverId;
        }

        public void setDriverId(String driverId) {
            this.driverId = driverId;
        }

        public String getEmail() {
            return email;
        }

        public void setEmail(String email) {
            this.email = email;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getAmbulanceType() {
            return ambulanceType;
        }

        public void setAmbulanceType(String ambulanceType) {
            this.ambulanceType = ambulanceType;
        }

        public String getDriverName() {
            return driverName;
        }

        public void setDriverName(String driverName) {
            this.driverName = driverName;
        }

        public String getDepartment() {
            return department;
        }

        public void setDepartment(String department) {
            this.department = department;
        }

        public String getOfficialNumber() {
            return officialNumber;
        }

        public void setOfficialNumber(String officialNumber) {
            this.officialNumber = officialNumber;
        }

        public String getAmbulanceNumber() {
            return ambulanceNumber;
        }

        public void setAmbulanceNumber(String ambulanceNumber) {
            this.ambulanceNumber = ambulanceNumber;
        }

        public String getAmbulancePhoto() {
            return ambulancePhoto;
        }

        public void setAmbulancePhoto(String ambulancePhoto) {
            this.ambulancePhoto = ambulancePhoto;
        }

        public String getAddress() {
            return address;
        }

        public void setAddress(String address) {
            this.address = address;
        }

        public String getDob() {
            return dob;
        }

        public void setDob(String dob) {
            this.dob = dob;
        }

        public String getRegId() {
            return regId;
        }

        public void setRegId(String regId) {
            this.regId = regId;
        }

        public String getDeviceType() {
            return deviceType;
        }

        public void setDeviceType(String deviceType) {
            this.deviceType = deviceType;
        }

        public String getLatitude() {
            return latitude;
        }

        public void setLatitude(String latitude) {
            this.latitude = latitude;
        }

        public String getLongitude() {
            return longitude;
        }

        public void setLongitude(String longitude) {
            this.longitude = longitude;
        }

        public String getCreated() {
            return created;
        }

        public void setCreated(String created) {
            this.created = created;
        }

        public String getUpdated() {
            return updated;
        }

        public void setUpdated(String updated) {
            this.updated = updated;
        }

        public String getApproveStatus() {
            return approveStatus;
        }

        public void setApproveStatus(String approveStatus) {
            this.approveStatus = approveStatus;
        }

        public String getRideStatus() {
            return rideStatus;
        }

        public void setRideStatus(String rideStatus) {
            this.rideStatus = rideStatus;
        }

        public String getStatus() {
            return status;
        }

        public void setStatus(String status) {
            this.status = status;
        }

        public String getAmount() {
            return amount;
        }

        public void setAmount(String amount) {
            this.amount = amount;
        }

        public String getActiveStatus() {
            return activeStatus;
        }

        public void setActiveStatus(String activeStatus) {
            this.activeStatus = activeStatus;
        }

        public String getType() {
            return type;
        }

        public void setType(String type) {
            this.type = type;
        }

        public String getPerKmPrice() {
            return perKmPrice;
        }

        public void setPerKmPrice(String perKmPrice) {
            this.perKmPrice = perKmPrice;
        }

    }
}

