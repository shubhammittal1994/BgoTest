package com.expert.healthkangaroodriver.ambulance_driver;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.AmbulanceNotificationModal;

import java.util.List;


public class Notifications_list_adapter extends RecyclerView.Adapter<Notifications_list_adapter.ViewHolder> {

    private List<AmbulanceNotificationModal.Detail> notifications_list;
    private NotificationInterface notificationInterface;
    private Context context;

    public interface NotificationInterface {

        void removeNotificationCallBack(AmbulanceNotificationModal.Detail detail);

    }

    public Notifications_list_adapter(List<AmbulanceNotificationModal.Detail> notifications_list, NotificationInterface notificationInterface, Context context) {
        this.notifications_list = notifications_list;
        this.notificationInterface = notificationInterface;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.notification_lay, parent, false);

        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {

        holder.img_remove.setOnClickListener(view -> {

            notificationInterface.removeNotificationCallBack(notifications_list.get(position));
            int newPosition = holder.getAdapterPosition();
            notifications_list.remove(newPosition);
            notifyItemRemoved(newPosition);
            notifyItemRangeChanged(newPosition, notifications_list.size());


        });

        holder.txt_notification_title.setText(notifications_list.get(position).getTitle());
        holder.txt_about_notification.setText(notifications_list.get(position).getMessage());
        holder.date_time_notification.setText("Date & Time: "+ notifications_list.get(position).getCreated());

    }

    @Override
    public int getItemCount() {

        return (notifications_list != null && notifications_list.size() != 0 ? notifications_list.size() : 0);

    }

    public static class ViewHolder extends RecyclerView.ViewHolder {

        private ImageView img_remove;
        private TextView txt_notification_title,txt_about_notification, date_time_notification;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            img_remove = itemView.findViewById(R.id.img_remove);
            txt_notification_title = itemView.findViewById(R.id.txt_notification_title);
            txt_about_notification = itemView.findViewById(R.id.txt_about_notification);
            date_time_notification = itemView.findViewById(R.id.date_time_notification);

        }
    }
}
