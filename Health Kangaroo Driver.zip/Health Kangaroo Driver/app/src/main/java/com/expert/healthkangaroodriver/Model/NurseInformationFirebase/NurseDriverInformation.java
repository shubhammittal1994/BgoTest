package com.expert.healthkangaroodriver.Model.NurseInformationFirebase;

public class NurseDriverInformation {

    String  appointmentNo, patientAddress;
    String liveLocation;
    String vendorName;
    String otp;


    public NurseDriverInformation(String appointmentNo, String patientAddress, String liveLocation, String vendorName, String otp) {
        this.appointmentNo = appointmentNo;
        this.patientAddress = patientAddress;
        this.liveLocation = liveLocation;
        this.vendorName = vendorName;
        this.otp = otp;
    }


    public NurseDriverInformation() {
    }

    public String getOtp() {
        return otp;
    }

    public void setOtp(String otp) {
        this.otp = otp;
    }

    public String getAppointmentNo() {
        return appointmentNo;
    }

    public void setAppointmentNo(String appointmentNo) {
        this.appointmentNo = appointmentNo;
    }

    public String getPatientAddress() {
        return patientAddress;
    }

    public void setPatientAddress(String patientAddress) {
        this.patientAddress = patientAddress;
    }

    public String getLiveLocation() {
        return liveLocation;
    }

    public void setLiveLocation(String liveLocation) {
        this.liveLocation = liveLocation;
    }

    public String getVendorName() {
        return vendorName;
    }

    public void setVendorName(String vendorName) {
        this.vendorName = vendorName;
    }
}
