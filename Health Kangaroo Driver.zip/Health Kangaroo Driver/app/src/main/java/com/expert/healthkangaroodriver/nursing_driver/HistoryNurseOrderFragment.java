package com.expert.healthkangaroodriver.nursing_driver;

import android.app.ProgressDialog;
import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.AppClass.App;
import com.expert.healthkangaroodriver.Model.nurse_model.OrderHistoryNurseModel;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.LabDeliveryHistoryModel;
import com.expert.healthkangaroodriver.adapter_class.nursing_adapters.HistoryNurseAdapter;
import com.expert.healthkangaroodriver.adapter_class.phlebotomist_adapters.HistoryLabAdapter;
import com.expert.healthkangaroodriver.retrofits.ViewModelClass;

import java.util.ArrayList;
import java.util.List;


public class HistoryNurseOrderFragment extends Fragment {
    private View view;
    private RecyclerView historyRecycler;
    private ImageView img_back;
    private String strVenderId, strDriverId;
    private ViewModelClass viewModel;
    private List<OrderHistoryNurseModel.Detail> sampleList = new ArrayList<>();
    private ProgressDialog dialog;
    private TextView total_orders;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view =  inflater.inflate(R.layout.fragment_histoty_nurse_order, container, false);

        strDriverId = App.getSharedPref().getStringValue("DriverId");
        strVenderId = App.getSharedPref().getStringValue("VenderId");



        dialog = new ProgressDialog(requireActivity());
        dialog.setMessage("Loading.....");

        FindId();
        onClick();
        setAdapter();


        return view;
    }

    private void setAdapter() {
        dialog.show();

        new ViewModelClass().orderHistoryNurseModelLiveData(requireActivity(), strVenderId, strDriverId).observe(requireActivity(), new Observer<OrderHistoryNurseModel>() {
            @Override
            public void onChanged(OrderHistoryNurseModel labDeliveryHistoryModel) {
                dialog.dismiss();
                if (labDeliveryHistoryModel.getSuccess().equalsIgnoreCase("True")){
                    dialog.dismiss();
                    Toast.makeText(requireActivity(), labDeliveryHistoryModel.getMessage(), Toast.LENGTH_SHORT).show();

                    sampleList = labDeliveryHistoryModel.getDetails();
                    HistoryNurseAdapter historyAdapter = new HistoryNurseAdapter(requireActivity(), sampleList, new HistoryNurseAdapter.HistoryPosition() {
                        @Override
                        public void details(OrderHistoryNurseModel.Detail detail) {

                        }
                    });

                    historyRecycler.setAdapter(historyAdapter);
                    total_orders.setText(" "+sampleList.size());

                }  else if (labDeliveryHistoryModel.getSuccess().equalsIgnoreCase("False")){

                    dialog.dismiss();

                    Toast.makeText(requireActivity(), labDeliveryHistoryModel.getMessage(), Toast.LENGTH_SHORT).show();

       //             not_found.setVisibility(View.VISIBLE);

                }
            }
        });
    }

    private void FindId() {

        img_back=view.findViewById(R.id.img_back);
        historyRecycler=view.findViewById(R.id.recycler_pharmacy_history_nurse);
        total_orders = view.findViewById(R.id.total_orders);
    }
    private void onClick() {

        img_back.setOnClickListener(v -> requireActivity().onBackPressed());

    }
}