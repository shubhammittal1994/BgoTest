package com.expert.healthkangaroodriver.nursing_driver;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.healthkangaroo.R;


public class NursingDriverActivity extends AppCompatActivity {



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_nursing);




    }





}
