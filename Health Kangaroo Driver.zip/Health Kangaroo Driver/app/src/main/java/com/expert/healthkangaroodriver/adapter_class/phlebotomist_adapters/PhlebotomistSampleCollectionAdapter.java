package com.expert.healthkangaroodriver.adapter_class.phlebotomist_adapters;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;

import com.example.healthkangaroo.R;
import com.expert.healthkangaroodriver.Model.phlebotomist_model.PhlebotomistDriverSampleCollectionModel;

import java.util.List;


public class PhlebotomistSampleCollectionAdapter extends RecyclerView.Adapter<PhlebotomistSampleCollectionAdapter.ViewHolder> {
    Context context;
    private final List<PhlebotomistDriverSampleCollectionModel.Detail> sampleList;
    Select select;
    StartDeliveryPositionLab startDeliveryPosition;

    private int latestIndex;

    public interface Select {
        void details(PhlebotomistDriverSampleCollectionModel.Detail detail);
    }

    public PhlebotomistSampleCollectionAdapter(Context context, List<PhlebotomistDriverSampleCollectionModel.Detail> sampleList, Select select, StartDeliveryPositionLab startDeliveryPosition) {
        this.context = context;
        this.sampleList = sampleList;
        this.select = select;
        this.startDeliveryPosition = startDeliveryPosition;
    }

    @NonNull
    @Override
    public PhlebotomistSampleCollectionAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.layout_order_list, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull PhlebotomistSampleCollectionAdapter.ViewHolder holder, @SuppressLint("RecyclerView") int position) {

        holder.txt_appointment_number.setText(sampleList.get(position).getAppointmentId());
        holder.txt_patience_name.setText(sampleList.get(position).getPatientName());
        holder.txt_patience_phone.setText(sampleList.get(position).getPhone());
        holder.txt_patience_address.setText(sampleList.get(position).getAddress());

        latestIndex = position;

        if (latestIndex == 0) {
            holder.pending_order_btn.setVisibility(View.GONE);
            holder.start_btn.setVisibility(View.VISIBLE);

            holder.start_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    Bundle bundle = new Bundle();
//                    bundle.putString("Patience Image", sampleList.get(position).getImage());
                    bundle.putString("Patience Name", sampleList.get(position).getPatientName());
                    bundle.putString("Patience Phone", sampleList.get(position).getPhone());
                    bundle.putString("Patience Address", sampleList.get(position).getAddress());
                    bundle.putString("Patience Latitude", sampleList.get(position).getLatitude());
                    bundle.putString("Patience Longitude", sampleList.get(position).getLongitude());

                    startDeliveryPosition.startPosition(sampleList.get(position).getAppointmentId(), sampleList.get(position)
                                    .getLatitude(), sampleList.get(position).getLongitude(),
                            sampleList.get(position).getAddress(), sampleList.get(position).getPhone(),sampleList.get(position).getOrderType());

                    select.details(sampleList.get(position));
                }
            });

        } else {
            holder.pending_order_btn.setVisibility(View.VISIBLE);
            holder.start_btn.setVisibility(View.GONE);

            holder.pending_order_btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    Bundle bundle = new Bundle();
                    bundle.putString("Name", sampleList.get(position).getPatientName());
                    bundle.putString("Phone", sampleList.get(position).getPhone());
                    bundle.putString("Address", sampleList.get(position).getAddress());
                    bundle.putString("Age", sampleList.get(position).getAge());
                    bundle.putString("orderId", sampleList.get(position).getAppointmentId());
                    bundle.putString("father", sampleList.get(position).getFathername());
                    bundle.putString("email", sampleList.get(position).getEmail());
                    bundle.putString("price", sampleList.get(position).getPrice());

                    Navigation.findNavController(v).navigate(R.id.action_myDeliveries_to_pendingOrderDetailsPhlebotomistFragment, bundle);
                }
            });
        }


    }

    @Override
    public int getItemCount() {
        return sampleList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final TextView txt_appointment_number, txt_patience_name, txt_patience_phone, txt_patience_address;
        private final Button start_btn, pending_order_btn;


        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            txt_appointment_number = itemView.findViewById(R.id.txt_appointment_number);
            txt_patience_name = itemView.findViewById(R.id.txt_patience_name);
            txt_patience_phone = itemView.findViewById(R.id.txt_patience_phone);
            txt_patience_address = itemView.findViewById(R.id.txt_patience_address);

            start_btn = itemView.findViewById(R.id.start_btn);
            pending_order_btn = itemView.findViewById(R.id.pending_order_btn);
        }
    }

    public interface StartDeliveryPositionLab {
        void startPosition(String appointmentNo, String patientLat, String patientLng, String patientAddress, String patientPhone,String orderType);
    }
}
