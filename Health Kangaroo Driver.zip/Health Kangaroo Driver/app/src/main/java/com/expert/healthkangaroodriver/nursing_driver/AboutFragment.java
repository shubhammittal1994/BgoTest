package com.expert.healthkangaroodriver.nursing_driver;

import android.os.Bundle;

import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.ImageView;

import com.example.healthkangaroo.R;

public class AboutFragment extends Fragment {
    private WebView webView;
    private View view;
    private ImageView back_img;


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view =  inflater.inflate(R.layout.fragment_about, container, false);

        webView = view.findViewById(R.id.webView);
        back_img = view.findViewById(R.id.img_back_about);

        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl("https://www.jsonschema2pojo.org/");

        back_img.setOnClickListener(v -> {
            Navigation.findNavController(view).navigate(R.id.driverpartMapscreen);
        });




        return view;
    }
}