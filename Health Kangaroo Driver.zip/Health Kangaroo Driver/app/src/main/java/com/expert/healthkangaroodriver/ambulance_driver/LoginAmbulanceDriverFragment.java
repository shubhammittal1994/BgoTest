package com.expert.healthkangaroodriver.ambulance_driver;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.healthkangaroo.R;

public class LoginAmbulanceDriverFragment extends Fragment {
    private View view;
    private EditText editext_email_hv, editext_password_hv;
    private TextView txt_forgot_password;
    private ImageView ic_eye_id;
    private Button btn_login_hv;
    private int count =0;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate( R.layout.fragment_login_ambulance_driver, container, false );



        findID();
        onClicks();




        //show n hide pswd functionality
        ic_eye_id.setOnClickListener( v -> {
            if (count % 2 == 0) {
                editext_password_hv.setTransformationMethod( HideReturnsTransformationMethod.getInstance() );
                ic_eye_id.setImageResource( R.drawable.ic_hide_password );

            } else {
                editext_password_hv.setTransformationMethod( PasswordTransformationMethod.getInstance() );
                ic_eye_id.setImageResource( R.drawable.ic_baseline_remove_red_eye_24 );
            }
            count++;
        } );



        return view;
    }

    private void onClicks() {

        btn_login_hv.setOnClickListener( new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                Navigation.findNavController( v ).navigate( R.id.action_loginAmbulanceDriverFragment_to_homeAmbulanceDriverFragment);
            }
        } );
    }

    private void findID() {

        editext_email_hv = view.findViewById( R.id.editext_email_hv );
        editext_password_hv = view.findViewById( R.id.editext_password_hv );
        ic_eye_id = view.findViewById( R.id.ic_eye_id );
        txt_forgot_password = view.findViewById( R.id.txt_forgot_password );
        btn_login_hv = view.findViewById( R.id.btn_login_hv );
    }
}